"use client";
import { Chip, Icon } from "./ui";
import { ListShell } from "./ListShell";
import { Thumb } from "./ImagePicker";
import { coverOf } from "./Selectors";
import { fmtDate, fmtDateTime, inr, num } from "@/lib/format";

type Img = { thumb: string; isCover: boolean };
const byText = (f: (x: never) => string) => f;
void byText;
const uniq = (a: (string | null | undefined)[]) => [...new Set(a.filter(Boolean) as string[])].sort();
const time = (d: string | Date) => new Date(d).getTime();

type Vehicle = { id: number; name: string; plate: string; type: string; purchaseYear: number | null; images: Img[] };
type Odo = { id: number; vehicleName: string; plate: string; driverName: string | null; at: string; startKm: number; stopKm: number; km: number; totalKm: number; status: string };
type Fuel = { id: number; vehicleName: string; plate: string; at: string; fuelType: string; litres: number; odometer: number; amount: number | null; mileage: number | null; estimated: boolean; prevMileage: number | null; distance: number | null; images: Img[] };
type Damage = { id: number; vehicleName: string; plate: string; at: string; amount: number; description: string | null; location: string | null; drivers: { id: number; name: string }[]; images: Img[] };
type Tire = { id: number; code: string; images: Img[]; currentVehicle: string | null; lastVehicle: string | null; status: string; trailCount: number; damageCount: number };
type Repair = { id: number; vehicleName: string; plate: string; at: string; kind: string; amount: number; place: string | null; description: string | null; images: Img[] };
type Driver = { id: number; name: string; monthlySalary: number; phone: string | null; images: Img[] };

export function ModuleList({ module }: { module: string }) {
  switch (module) {
    case "vehicles":
      return (
        <ListShell<Vehicle>
          title="Vehicles" resource="vehicles" base="/vehicles" noun="Vehicle"
          emptyText="Your garage is quiet. Add your first vehicle."
          searchText={(v) => `${v.name} ${v.plate} ${v.type}`}
          sorts={[
            { key: "name", label: "Name A–Z", fn: (a, b) => a.name.localeCompare(b.name) },
            { key: "year", label: "Newest purchase", fn: (a, b) => (b.purchaseYear ?? 0) - (a.purchaseYear ?? 0) },
            { key: "plate", label: "Plate", fn: (a, b) => a.plate.localeCompare(b.plate) },
          ]}
          filters={[{ key: "type", label: "Type", options: (r) => uniq(r.map((x) => x.type)), match: (r, v) => r.type === v }]}
          href={(v) => `/vehicles/${v.id}`}
          card={(v) => (
            <div className="flex items-center gap-4">
              <Thumb src={coverOf(v.images)} size={76} />
              <div className="min-w-0">
                <div className="serif truncate text-2xl font-semibold leading-tight">{v.name}</div>
                <div className="mt-0.5 text-sm tracking-wider text-muted">{v.plate}</div>
                <div className="mt-2 flex items-center gap-2">
                  <Chip>{v.type}</Chip>
                  {v.purchaseYear && <span className="text-xs text-muted">Since {v.purchaseYear}</span>}
                </div>
              </div>
            </div>
          )}
        />
      );
    case "odometer":
      return (
        <ListShell<Odo>
          title="Odometer" resource="odometer" base="/odometer" noun="Trip"
          emptyText="No trips logged yet. Record today's first reading."
          searchText={(o) => `${o.vehicleName} ${o.plate} ${o.driverName ?? ""}`}
          dateOf={(o) => o.at}
          sorts={[
            { key: "new", label: "Newest first", fn: (a, b) => time(b.at) - time(a.at) },
            { key: "old", label: "Oldest first", fn: (a, b) => time(a.at) - time(b.at) },
            { key: "km", label: "Most km", fn: (a, b) => b.km - a.km },
          ]}
          filters={[{ key: "v", label: "Vehicle", options: (r) => uniq(r.map((x) => x.vehicleName)), match: (r, v) => r.vehicleName === v }]}
          href={(o) => `/odometer/${o.id}/edit`}
          card={(o) => (
            <div className="flex items-center justify-between gap-3">
              <div className="min-w-0">
                <div className="truncate font-semibold">{o.vehicleName}</div>
                <div className="text-xs text-muted">{fmtDateTime(o.at)}</div>
                <div className="mt-1 text-sm text-muted">
                  {num(o.startKm, 1)} → {num(o.stopKm, 1)} km · {o.driverName ?? "No driver"}
                </div>
              </div>
              <div className="text-right">
                <div className="serif text-3xl font-semibold text-primary">{num(o.km, 1)}</div>
                <div className="text-xs text-muted">km</div>
                {o.status === "Gap" && <Chip tone="warn">Gap</Chip>}
              </div>
            </div>
          )}
        />
      );
    case "fuel":
      return (
        <ListShell<Fuel>
          title="Fuel Refills" resource="fuel" base="/fuel" noun="Refill"
          emptyText="No refills yet. Log your first fill-up."
          searchText={(f) => `${f.vehicleName} ${f.plate} ${f.fuelType}`}
          dateOf={(f) => f.at}
          sorts={[
            { key: "new", label: "Newest first", fn: (a, b) => time(b.at) - time(a.at) },
            { key: "l", label: "Most litres", fn: (a, b) => b.litres - a.litres },
            { key: "m", label: "Best mileage", fn: (a, b) => (b.mileage ?? 0) - (a.mileage ?? 0) },
          ]}
          filters={[
            { key: "v", label: "Vehicle", options: (r) => uniq(r.map((x) => x.vehicleName)), match: (r, v) => r.vehicleName === v },
            { key: "t", label: "Fuel type", options: () => ["Diesel", "Petrol"], match: (r, v) => r.fuelType === v },
          ]}
          href={(f) => `/fuel/${f.id}/edit`}
          card={(f) => (
            <div className="flex items-center justify-between gap-3">
              <div className="min-w-0">
                <div className="truncate font-semibold">{f.vehicleName}</div>
                <div className="text-xs text-muted">{fmtDateTime(f.at)}</div>
                <div className="mt-1.5 flex flex-wrap items-center gap-2">
                  <Chip tone={f.fuelType === "Diesel" ? "sage" : "gold"}>{f.fuelType}</Chip>
                  <span className="text-sm">{num(f.litres, 2)} L</span>
                  {f.amount !== null && <span className="text-sm text-muted">{inr(f.amount)}</span>}
                </div>
              </div>
              <div className="text-right">
                {f.mileage ? (
                  <>
                    <div className="serif flex items-center justify-end gap-1 text-3xl font-semibold text-primary">
                      {f.prevMileage !== null && <Icon name={f.mileage >= f.prevMileage ? "up" : "down"} size={16} className={f.mileage >= f.prevMileage ? "text-ok" : "text-err"} />}
                      {f.mileage.toFixed(2)}
                    </div>
                    <div className="text-xs text-muted">km/L{f.estimated ? " · est." : ""}</div>
                  </>
                ) : (
                  <div className="text-xs text-muted">First refill</div>
                )}
              </div>
            </div>
          )}
        />
      );
    case "damages":
      return (
        <ListShell<Damage>
          title="Damages" resource="damages" base="/damages" noun="Damage"
          emptyText="No damages recorded. Long may it last."
          searchText={(d) => `${d.vehicleName} ${d.plate} ${d.description ?? ""} ${d.location ?? ""} ${d.drivers.map((x) => x.name).join(" ")}`}
          dateOf={(d) => d.at}
          sorts={[
            { key: "new", label: "Newest first", fn: (a, b) => time(b.at) - time(a.at) },
            { key: "amt", label: "Highest cost", fn: (a, b) => b.amount - a.amount },
          ]}
          filters={[{ key: "v", label: "Vehicle", options: (r) => uniq(r.map((x) => x.vehicleName)), match: (r, v) => r.vehicleName === v }]}
          href={(d) => `/damages/${d.id}/edit`}
          card={(d) => (
            <div className="flex gap-3">
              <Thumb src={coverOf(d.images)} size={68} />
              <div className="min-w-0 flex-1">
                <div className="flex items-start justify-between gap-2">
                  <div className="truncate font-semibold">{d.vehicleName}</div>
                  <div className="serif text-xl font-semibold text-err">{inr(d.amount)}</div>
                </div>
                <div className="text-xs text-muted">{fmtDateTime(d.at)}</div>
                {d.description && <div className="mt-1 truncate text-sm text-muted">{d.description}</div>}
                <div className="mt-1.5 flex flex-wrap gap-1.5">
                  {d.drivers.map((x) => (
                    <Chip key={x.id} tone="clay">{x.name}</Chip>
                  ))}
                </div>
              </div>
            </div>
          )}
        />
      );
    case "tires":
      return (
        <ListShell<Tire>
          title="Tires" resource="tires" base="/tires" noun="Tire"
          emptyText="No tires tracked yet. Add a tire code to begin its trail."
          searchText={(t) => `${t.code} ${t.currentVehicle ?? ""} ${t.lastVehicle ?? ""}`}
          sorts={[
            { key: "code", label: "Code", fn: (a, b) => a.code.localeCompare(b.code) },
            { key: "status", label: "Status", fn: (a, b) => a.status.localeCompare(b.status) },
          ]}
          filters={[{ key: "s", label: "Status", options: () => ["Active", "Damaged"], match: (r, v) => r.status === v }]}
          href={(t) => `/tires/${t.id}/edit`}
          card={(t) => (
            <div className="flex items-center gap-4">
              <Thumb src={coverOf(t.images)} size={64} />
              <div className="min-w-0 flex-1">
                <div className="serif text-2xl font-semibold">{t.code}</div>
                <div className="truncate text-sm text-muted">
                  {t.currentVehicle ? `Fitted to ${t.currentVehicle}` : t.lastVehicle ? `Last on ${t.lastVehicle}` : "Not fitted"}
                </div>
                <div className="text-xs text-muted">{t.trailCount} fitment{t.trailCount === 1 ? "" : "s"}</div>
              </div>
              <Chip tone={t.status === "Damaged" ? "err" : "ok"}>{t.status}</Chip>
            </div>
          )}
        />
      );
    case "repairs":
      return (
        <ListShell<Repair>
          title="Repairs & Parts" resource="repairs" base="/repairs" noun="Entry"
          emptyText="No repairs or new parts logged yet."
          searchText={(r) => `${r.vehicleName} ${r.plate} ${r.place ?? ""} ${r.description ?? ""}`}
          dateOf={(r) => r.at}
          sorts={[
            { key: "new", label: "Newest first", fn: (a, b) => time(b.at) - time(a.at) },
            { key: "amt", label: "Highest amount", fn: (a, b) => b.amount - a.amount },
          ]}
          filters={[
            { key: "v", label: "Vehicle", options: (r) => uniq(r.map((x) => x.vehicleName)), match: (r, v) => r.vehicleName === v },
            { key: "k", label: "Type", options: () => ["Repair", "New Part"], match: (r, v) => (v === "Repair" ? r.kind === "repair" : r.kind === "part") },
          ]}
          href={(r) => `/repairs/${r.id}/edit`}
          card={(r) => (
            <div className="flex items-center justify-between gap-3">
              <div className="min-w-0">
                <Chip tone={r.kind === "part" ? "sage" : "clay"}>{r.kind === "part" ? "New Part" : "Repair"}</Chip>
                <div className="mt-1.5 truncate font-semibold">{r.vehicleName}</div>
                <div className="truncate text-sm text-muted">{[r.place, r.description].filter(Boolean).join(" · ") || fmtDate(r.at)}</div>
                <div className="text-xs text-muted">{fmtDateTime(r.at)}</div>
              </div>
              <div className="serif text-2xl font-semibold">{inr(r.amount)}</div>
            </div>
          )}
        />
      );
    case "drivers":
      return (
        <ListShell<Driver>
          title="Drivers" resource="drivers" base="/drivers" noun="Driver"
          emptyText="No drivers yet. Add the people behind the wheel."
          searchText={(d) => `${d.name} ${d.phone ?? ""}`}
          sorts={[
            { key: "name", label: "Name A–Z", fn: (a, b) => a.name.localeCompare(b.name) },
            { key: "sal", label: "Highest salary", fn: (a, b) => b.monthlySalary - a.monthlySalary },
          ]}
          href={(d) => `/drivers/${d.id}`}
          card={(d) => (
            <div className="flex items-center gap-4">
              <Thumb src={coverOf(d.images)} size={60} round />
              <div className="min-w-0">
                <div className="serif truncate text-2xl font-semibold">{d.name}</div>
                <div className="text-sm text-muted">{inr(d.monthlySalary)} / month</div>
                {d.phone && <div className="text-xs text-muted">{d.phone}</div>}
              </div>
            </div>
          )}
        />
      );
  }
  return null;
}
