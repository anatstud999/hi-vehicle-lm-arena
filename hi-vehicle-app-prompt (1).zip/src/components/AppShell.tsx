"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { ReactNode, useEffect, useState } from "react";
import { cn } from "@/lib/format";
import { Icon } from "./ui";
import { haptic } from "@/lib/client";

const NAV = [
  { href: "/", label: "Home", icon: "home" },
  { href: "/vehicles", label: "Vehicles", icon: "bus" },
  { href: "/drivers", label: "Drivers", icon: "users" },
  { href: "/reports", label: "Reports", icon: "chart" },
  { href: "/settings", label: "Settings", icon: "settings" },
];
const QUICK = [
  { href: "/odometer/new", label: "Odometer", icon: "gauge" },
  { href: "/fuel/new", label: "Fuel", icon: "fuel" },
  { href: "/damages/new", label: "Damage", icon: "alert" },
  { href: "/repairs/new", label: "Repair / Part", icon: "wrench" },
  { href: "/tires/new", label: "Tire", icon: "tire" },
];

export function Wordmark({ className }: { className?: string }) {
  return (
    <span className={cn("serif text-[22px] font-bold tracking-[0.18em] text-primary", className)}>
      HI <span className="text-gold">VEHICLE</span>
    </span>
  );
}

function SyncBadge() {
  const [online, setOnline] = useState(true);
  useEffect(() => {
    const set = () => setOnline(navigator.onLine);
    set();
    window.addEventListener("online", set);
    window.addEventListener("offline", set);
    return () => {
      window.removeEventListener("online", set);
      window.removeEventListener("offline", set);
    };
  }, []);
  return (
    <span className={cn("inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-semibold", online ? "bg-pc text-primary" : "bg-[color-mix(in_srgb,var(--warn)_25%,transparent)] text-warn")}>
      <span className={cn("h-2 w-2 rounded-full", online ? "bg-ok" : "pulse-dot bg-warn")} />
      {online ? "Synced" : "Offline"}
    </span>
  );
}

export function AppShell({ children }: { children: ReactNode }) {
  const path = usePathname();
  const [dial, setDial] = useState(false);
  useEffect(() => setDial(false), [path]);
  const isForm = /\/(new|edit|pay)(\/|$)/.test(path);
  const active = (href: string) => (href === "/" ? path === "/" : path.startsWith(href));

  return (
    <div className="relative z-10 min-h-dvh">
      <header className="no-print sticky top-0 z-30 border-b border-line bg-bg/85 backdrop-blur">
        <div className="mx-auto flex h-14 max-w-3xl items-center justify-between px-4">
          <Link href="/" aria-label="HI VEHICLE home">
            <Wordmark />
          </Link>
          <SyncBadge />
        </div>
      </header>
      <main className={cn("mx-auto max-w-3xl px-4 pt-5", isForm ? "pb-6" : "pb-32")}>{children}</main>

      {!isForm && (
        <>
          {dial && <div className="fade fixed inset-0 z-40 bg-black/35" onClick={() => setDial(false)} />}
          <nav className="no-print fixed inset-x-0 bottom-0 z-50 border-t border-line bg-surface/95 pb-[env(safe-area-inset-bottom)] backdrop-blur" aria-label="Main">
            <div className="mx-auto grid max-w-3xl grid-cols-6 items-end px-1">
              {NAV.slice(0, 2).map((n) => (
                <NavItem key={n.href} {...n} on={active(n.href)} />
              ))}
              <div className="relative flex justify-center">
                {dial && (
                  <div className="absolute bottom-[78px] left-1/2 flex w-52 -translate-x-1/2 flex-col gap-2">
                    {QUICK.map((q, i) => (
                      <Link
                        key={q.href}
                        href={q.href}
                        className="rise card flex items-center gap-3 px-4 py-2.5 font-semibold text-ink"
                        style={{ ["--i" as string]: QUICK.length - i }}
                      >
                        <span className="flex h-9 w-9 items-center justify-center rounded-full bg-pc text-primary">
                          <Icon name={q.icon} size={18} />
                        </span>
                        {q.label}
                      </Link>
                    ))}
                  </div>
                )}
                <button
                  aria-label={dial ? "Close quick add" : "Quick add"}
                  aria-expanded={dial}
                  onClick={() => {
                    haptic();
                    setDial((d) => !d);
                  }}
                  className="-mt-5 mb-2 flex h-14 w-14 items-center justify-center rounded-full bg-primary text-onp shadow-lg ring-4 ring-bg transition-transform duration-300"
                  style={{ transform: dial ? "rotate(45deg)" : "none" }}
                >
                  <Icon name="plus" size={28} />
                </button>
              </div>
              {NAV.slice(2).map((n) => (
                <NavItem key={n.href} {...n} on={active(n.href)} />
              ))}
            </div>
          </nav>
        </>
      )}
    </div>
  );
}

function NavItem({ href, label, icon, on }: { href: string; label: string; icon: string; on: boolean }) {
  return (
    <Link href={href} className={cn("relative flex min-h-[60px] flex-col items-center justify-center gap-0.5 text-[11px] font-semibold transition-colors", on ? "text-primary" : "text-muted")} aria-current={on ? "page" : undefined}>
      <Icon name={icon} size={22} />
      {label}
      <span className={cn("absolute top-0 h-[3px] rounded-full bg-gold transition-all duration-300", on ? "w-8" : "w-0")} />
    </Link>
  );
}
