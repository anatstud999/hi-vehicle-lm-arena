"use client";
import Link from "next/link";
import { ReactNode, useMemo, useState } from "react";
import { api, useFetch } from "@/lib/client";
import { cn, istDay } from "@/lib/format";
import { ConfirmDialog, EmptyState, ErrorBox, Icon, IconButton, PageTitle, Skeleton, useToast } from "./ui";

export type SortOpt<T> = { key: string; label: string; fn: (a: T, b: T) => number };
export type FilterDef<T> = { key: string; label: string; options: (rows: T[]) => string[]; match: (r: T, v: string) => boolean };

type Props<T extends { id: number }> = {
  title: string;
  sub?: string;
  resource: string; // e.g. "fuel"
  base: string; // route prefix, e.g. "/fuel"
  emptyText: string;
  searchText: (r: T) => string;
  sorts: SortOpt<T>[];
  filters?: FilterDef<T>[];
  dateOf?: (r: T) => string | Date;
  card: (r: T) => ReactNode;
  href: (r: T) => string;
  noun: string;
};

export function ListShell<T extends { id: number }>({ title, sub, resource, base, emptyText, searchText, sorts, filters = [], dateOf, card, href, noun }: Props<T>) {
  const { data, error, loading, reload } = useFetch<T[]>(`/api/${resource}`);
  const toast = useToast();
  const [q, setQ] = useState("");
  const [sortKey, setSortKey] = useState(sorts[0].key);
  const [fv, setFv] = useState<Record<string, string>>({});
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [hidden, setHidden] = useState<Set<number>>(new Set());
  const [confirm, setConfirm] = useState<T | null>(null);
  const [showFilters, setShowFilters] = useState(false);

  const rows = useMemo(() => {
    let r = (data ?? []).filter((x) => !hidden.has(x.id));
    if (q.trim()) r = r.filter((x) => searchText(x).toLowerCase().includes(q.trim().toLowerCase()));
    for (const f of filters) if (fv[f.key]) r = r.filter((x) => f.match(x, fv[f.key]));
    if (dateOf && (from || to)) r = r.filter((x) => (!from || istDay(dateOf(x)) >= from) && (!to || istDay(dateOf(x)) <= to));
    const s = sorts.find((o) => o.key === sortKey) ?? sorts[0];
    return [...r].sort(s.fn);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [data, q, sortKey, fv, from, to, hidden]);

  function remove(r: T) {
    setConfirm(null);
    setHidden((h) => new Set(h).add(r.id));
    toast.undoable(
      `${noun} deleted`,
      async () => {
        try {
          await api(`/api/${resource}/${r.id}`, { method: "DELETE" });
        } catch (e) {
          toast.show((e as Error).message, "err");
        }
        reload();
        setHidden((h) => {
          const n = new Set(h);
          n.delete(r.id);
          return n;
        });
      },
      () => setHidden((h) => {
        const n = new Set(h);
        n.delete(r.id);
        return n;
      }),
    );
  }

  const active = Object.values(fv).filter(Boolean).length + (from || to ? 1 : 0);

  return (
    <div>
      <PageTitle title={title} sub={sub ?? (data ? `${data.length} ${data.length === 1 ? "record" : "records"}` : undefined)} />
      <div className="mb-4 flex gap-2">
        <div className="relative flex-1">
          <Icon name="search" size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-muted" />
          <input className="input pl-11" placeholder={`Search ${title.toLowerCase()}`} value={q} onChange={(e) => setQ(e.target.value)} aria-label="Search" />
        </div>
        <div className="relative">
          <select aria-label="Sort" className="input h-12 w-12 cursor-pointer appearance-none !px-0 text-transparent" value={sortKey} onChange={(e) => setSortKey(e.target.value)}>
            {sorts.map((s) => (
              <option key={s.key} value={s.key} className="text-ink">
                {s.label}
              </option>
            ))}
          </select>
          <Icon name="sort" size={20} className="pointer-events-none absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 text-primary" />
        </div>
        {(filters.length > 0 || dateOf) && (
          <button type="button" aria-label="Filters" onClick={() => setShowFilters((s) => !s)} className={cn("input relative flex h-12 w-12 items-center justify-center !px-0", showFilters && "!border-primary")}>
            <Icon name="filter" size={20} className="text-primary" />
            {active > 0 && <span className="absolute -right-1 -top-1 flex h-5 w-5 items-center justify-center rounded-full bg-gold text-[11px] font-bold text-white">{active}</span>}
          </button>
        )}
      </div>
      {showFilters && (
        <div className="card rise mb-4 grid grid-cols-2 gap-3 p-4">
          {filters.map((f) => (
            <label key={f.key} className="block text-[13px] font-semibold text-muted">
              {f.label}
              <select className="input mt-1" value={fv[f.key] ?? ""} onChange={(e) => setFv({ ...fv, [f.key]: e.target.value })}>
                <option value="">All</option>
                {f.options(data ?? []).map((o) => (
                  <option key={o}>{o}</option>
                ))}
              </select>
            </label>
          ))}
          {dateOf && (
            <>
              <label className="block text-[13px] font-semibold text-muted">
                From
                <input type="date" className="input mt-1" value={from} onChange={(e) => setFrom(e.target.value)} />
              </label>
              <label className="block text-[13px] font-semibold text-muted">
                To
                <input type="date" className="input mt-1" value={to} onChange={(e) => setTo(e.target.value)} />
              </label>
            </>
          )}
          {active > 0 && (
            <button className="btn btn-ghost col-span-2" onClick={() => { setFv({}); setFrom(""); setTo(""); }}>
              Clear filters
            </button>
          )}
        </div>
      )}

      {loading && !data && <Skeleton />}
      {error && <ErrorBox message={error} retry={reload} />}
      {data && !rows.length && (
        <EmptyState
          text={data.length ? "Nothing matches your search." : emptyText}
          action={!data.length && <Link href={`${base}/new`} className="btn btn-primary"><Icon name="plus" size={18} /> Add {noun.toLowerCase()}</Link>}
        />
      )}
      <div className="space-y-3">
        {rows.map((r, i) => (
          <div key={r.id} className="rise relative" style={{ ["--i" as string]: Math.min(i, 10) }}>
            <Link href={href(r)} className="card block p-4 pr-14 transition active:scale-[0.99]">
              {card(r)}
            </Link>
            <div className="absolute right-1 top-1">
              <IconButton icon="trash" label={`Delete ${noun}`} size={18} className="!h-11 !w-11" onClick={() => setConfirm(r)} />
            </div>
          </div>
        ))}
      </div>

      <Link href={`${base}/new`} aria-label={`Add ${noun}`} className="no-print fixed bottom-24 right-5 z-30 flex h-14 w-14 items-center justify-center rounded-full bg-primary text-onp shadow-xl transition active:scale-95">
        <Icon name="plus" size={26} />
      </Link>
      <ConfirmDialog open={!!confirm} title={`Delete this ${noun.toLowerCase()}?`} message="You can undo for a few seconds afterwards." onCancel={() => setConfirm(null)} onConfirm={() => confirm && remove(confirm)} />
    </div>
  );
}
