"use client";
import { useMemo, useState } from "react";
import { api, useFetch } from "@/lib/client";
import { cn, inr } from "@/lib/format";
import { BottomSheet, Chip, Icon } from "./ui";
import { Field, MoneyField, TextField } from "./fields";
import { Thumb } from "./ImagePicker";

type Img = { thumb: string; isCover: boolean };
export type VehicleLite = { id: number; name: string; plate: string; type: string; purchaseYear: number | null; images: Img[] };
export type DriverLite = { id: number; name: string; monthlySalary: number; images: Img[] };
export const coverOf = (imgs?: Img[]) => (imgs?.find((i) => i.isCover) ?? imgs?.[0])?.thumb ?? null;

function SearchBox({ value, onChange, placeholder }: { value: string; onChange: (v: string) => void; placeholder: string }) {
  return (
    <div className="relative mb-3">
      <Icon name="search" size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-muted" />
      <input className="input pl-11" placeholder={placeholder} value={value} onChange={(e) => onChange(e.target.value)} autoFocus />
    </div>
  );
}

export function VehicleSelector({ value, onChange, error, label = "Vehicle" }: { value: number | null; onChange: (id: number, v: VehicleLite) => void; error?: string | null; label?: string }) {
  const { data, loading } = useFetch<VehicleLite[]>("/api/vehicles");
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState("");
  const selected = data?.find((v) => v.id === value);
  const list = useMemo(() => (data ?? []).filter((v) => `${v.name} ${v.plate}`.toLowerCase().includes(q.toLowerCase())), [data, q]);
  return (
    <Field label={label} error={error}>
      <button type="button" onClick={() => setOpen(true)} className={cn("input flex !min-h-[60px] items-center gap-3 text-left", error && "invalid")}>
        {selected ? (
          <>
            <Thumb src={coverOf(selected.images)} size={40} />
            <span className="min-w-0 flex-1">
              <span className="block truncate font-semibold">{selected.name}</span>
              <span className="block text-xs text-muted">{selected.plate}</span>
            </span>
          </>
        ) : (
          <span className="flex-1 text-muted">{loading ? "Loading…" : "Choose a vehicle"}</span>
        )}
        <Icon name="chevD" size={18} className="text-muted" />
      </button>
      <BottomSheet open={open} onClose={() => setOpen(false)} title="Choose vehicle">
        <SearchBox value={q} onChange={setQ} placeholder="Search name or plate" />
        {!list.length && <p className="py-8 text-center text-muted">{data?.length ? "No vehicle matches." : "Add a vehicle first from the Vehicles tab."}</p>}
        <div className="space-y-2 pb-2">
          {list.map((v) => (
            <button
              type="button"
              key={v.id}
              onClick={() => {
                onChange(v.id, v);
                setOpen(false);
                setQ("");
              }}
              className={cn("flex w-full items-center gap-3 rounded-2xl border p-2.5 text-left transition", v.id === value ? "border-primary bg-pc" : "border-line")}
            >
              <Thumb src={coverOf(v.images)} size={48} />
              <span className="flex-1">
                <span className="block font-semibold">{v.name}</span>
                <span className="text-xs text-muted">{v.plate}</span>
              </span>
              <Chip>{v.type}</Chip>
            </button>
          ))}
        </div>
      </BottomSheet>
    </Field>
  );
}

function QuickAddDriver({ onAdded }: { onAdded: (id: number) => void }) {
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [salary, setSalary] = useState("");
  const [err, setErr] = useState<string | null>(null);
  if (!open)
    return (
      <button type="button" className="btn btn-soft mb-3 w-full" onClick={() => setOpen(true)}>
        <Icon name="plus" size={18} /> Add new driver
      </button>
    );
  return (
    <div className="mb-3 space-y-3 rounded-2xl border border-line p-3">
      <TextField label="Driver name" value={name} onChange={setName} error={err} />
      <MoneyField label="Monthly salary" value={salary} onChange={setSalary} />
      <div className="flex gap-2">
        <button type="button" className="btn btn-ghost flex-1" onClick={() => setOpen(false)}>
          Cancel
        </button>
        <button
          type="button"
          className="btn btn-primary flex-1"
          onClick={async () => {
            try {
              const r = await api<{ id: number }>("/api/drivers", { body: { name, monthlySalary: salary } });
              setOpen(false);
              setName("");
              setSalary("");
              onAdded(r.id);
            } catch (e) {
              setErr((e as Error).message);
            }
          }}
        >
          Add
        </button>
      </div>
    </div>
  );
}

function DriverRow({ d, selected, onClick, multi }: { d: DriverLite; selected: boolean; onClick: () => void; multi?: boolean }) {
  return (
    <button type="button" onClick={onClick} className={cn("flex w-full items-center gap-3 rounded-2xl border p-2.5 text-left transition", selected ? "border-primary bg-pc" : "border-line")}>
      <Thumb src={coverOf(d.images)} size={44} round />
      <span className="flex-1">
        <span className="block font-semibold">{d.name}</span>
        <span className="text-xs text-muted">{inr(d.monthlySalary)} / month</span>
      </span>
      {multi && <span className={cn("flex h-6 w-6 items-center justify-center rounded-full border", selected ? "border-primary bg-primary text-onp" : "border-line")}>{selected && <Icon name="check" size={14} />}</span>}
    </button>
  );
}

export function DriverSelector({ value, onChange, label = "Driver", error }: { value: number | null; onChange: (id: number | null) => void; label?: string; error?: string | null }) {
  const { data, reload } = useFetch<DriverLite[]>("/api/drivers");
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState("");
  const selected = data?.find((d) => d.id === value);
  const list = (data ?? []).filter((d) => d.name.toLowerCase().includes(q.toLowerCase()));
  return (
    <Field label={label} error={error}>
      <button type="button" onClick={() => setOpen(true)} className="input flex !min-h-[56px] items-center gap-3 text-left">
        {selected ? (
          <>
            <Thumb src={coverOf(selected.images)} size={34} round />
            <span className="flex-1 font-semibold">{selected.name}</span>
          </>
        ) : (
          <span className="flex-1 text-muted">Choose a driver</span>
        )}
        <Icon name="chevD" size={18} className="text-muted" />
      </button>
      <BottomSheet open={open} onClose={() => setOpen(false)} title="Choose driver">
        <QuickAddDriver
          onAdded={(id) => {
            reload();
            onChange(id);
            setOpen(false);
          }}
        />
        <SearchBox value={q} onChange={setQ} placeholder="Search drivers" />
        <div className="space-y-2 pb-2">
          {value && (
            <button type="button" className="w-full py-2 text-sm text-muted underline" onClick={() => { onChange(null); setOpen(false); }}>
              Clear selection
            </button>
          )}
          {list.map((d) => (
            <DriverRow key={d.id} d={d} selected={d.id === value} onClick={() => { onChange(d.id); setOpen(false); }} />
          ))}
        </div>
      </BottomSheet>
    </Field>
  );
}

export function DriverMultiSelector({ value, onChange, label = "Drivers involved" }: { value: number[]; onChange: (ids: number[]) => void; label?: string }) {
  const { data, reload } = useFetch<DriverLite[]>("/api/drivers");
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState("");
  const list = (data ?? []).filter((d) => d.name.toLowerCase().includes(q.toLowerCase()));
  const toggle = (id: number) => onChange(value.includes(id) ? value.filter((x) => x !== id) : [...value, id]);
  return (
    <Field label={label}>
      <button type="button" onClick={() => setOpen(true)} className="input flex !min-h-[56px] flex-wrap items-center gap-2 text-left">
        {value.length ? (
          <span className="flex flex-1 flex-wrap gap-1.5">
            {value.map((id) => (
              <Chip key={id}>{data?.find((d) => d.id === id)?.name ?? "…"}</Chip>
            ))}
          </span>
        ) : (
          <span className="flex-1 text-muted">Select one or more drivers</span>
        )}
        <Icon name="chevD" size={18} className="text-muted" />
      </button>
      <BottomSheet open={open} onClose={() => setOpen(false)} title="Drivers involved">
        <QuickAddDriver
          onAdded={(id) => {
            reload();
            onChange([...value, id]);
          }}
        />
        <SearchBox value={q} onChange={setQ} placeholder="Search drivers" />
        <div className="space-y-2 pb-2">
          {list.map((d) => (
            <DriverRow key={d.id} d={d} multi selected={value.includes(d.id)} onClick={() => toggle(d.id)} />
          ))}
        </div>
        <button type="button" className="btn btn-primary mt-3 w-full" onClick={() => setOpen(false)}>
          Done ({value.length})
        </button>
      </BottomSheet>
    </Field>
  );
}
