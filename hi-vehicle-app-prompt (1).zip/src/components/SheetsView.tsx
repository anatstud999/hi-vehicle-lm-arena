"use client";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { api, haptic } from "@/lib/client";
import { cn, inr, istDay, num } from "@/lib/format";
import { ConfirmDialog, EmptyState, ErrorBox, Icon, IconButton, Segmented, Skeleton, useToast } from "./ui";
import { Field, TextField } from "./fields";
import { PasteImport } from "./PasteImport";

type Lock = { configured: boolean; unlocked: boolean; hint: string | null };
type Col = { key: string; label: string; type: "text" | "int" | "dec" | "money" };
type Cell = string | number | null;
type Row = { id: number; v: Record<string, Cell>; s?: Record<string, string | number> };
type Sheet = { key: string; title: string; columns: Col[]; rows: Row[]; vehicleOptions: string[]; importFields: { key: string; label: string; required: boolean }[] };
const KEYS = [
  { value: "odometer", label: "Odometer" },
  { value: "fuel", label: "Fuel" },
  { value: "repairs", label: "Repairs" },
  { value: "damages", label: "Damages" },
] as const;
type SheetKey = (typeof KEYS)[number]["value"];

export function SheetsView() {
  const [lock, setLock] = useState<Lock | null>(null);
  const refresh = useCallback(() => api<Lock>("/api/lock").then(setLock).catch(() => setLock({ configured: false, unlocked: false, hint: null })), []);
  useEffect(() => {
    void refresh();
  }, [refresh]);

  // Auto-lock: after 2 minutes in the background; keep the session alive while active
  const hiddenAt = useRef<number | null>(null);
  useEffect(() => {
    if (!lock?.unlocked) return;
    const vis = () => {
      if (document.hidden) hiddenAt.current = Date.now();
      else if (hiddenAt.current && Date.now() - hiddenAt.current > 120000) {
        void api("/api/lock", { body: { action: "lock" } }).then(refresh);
      } else void api("/api/lock", { body: { action: "keepalive" } }).catch(refresh);
    };
    document.addEventListener("visibilitychange", vis);
    const ping = setInterval(() => !document.hidden && api("/api/lock", { body: { action: "keepalive" } }).catch(refresh), 45000);
    return () => {
      document.removeEventListener("visibilitychange", vis);
      clearInterval(ping);
    };
  }, [lock?.unlocked, refresh]);

  if (!lock) return <Skeleton rows={2} />;
  if (!lock.configured) return <Setup onDone={refresh} />;
  if (!lock.unlocked) return <Unlock hint={lock.hint} onDone={refresh} />;
  return <Sheets onLock={async () => { await api("/api/lock", { body: { action: "lock" } }); void refresh(); }} onExpired={refresh} />;
}

/* ───────── lock screens ───────── */
function LockArt({ open }: { open?: boolean }) {
  return (
    <svg width="96" height="96" viewBox="0 0 96 96" fill="none" stroke="var(--primary)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="pop">
      <circle cx="48" cy="48" r="44" stroke="var(--accent)" strokeWidth="1.5" style={{ ["--len" as string]: 280 }} className="draw" />
      <rect x="28" y="44" width="40" height="30" rx="7" fill="var(--surface)" />
      <path d={open ? "M36 44V34a12 12 0 0122-4" : "M36 44V34a12 12 0 0124 0v10"} className="transition-all duration-500" />
      <circle cx="48" cy="58" r="3" fill="var(--accent)" stroke="none" />
    </svg>
  );
}

function Setup({ onDone }: { onDone: () => void }) {
  const [pw, setPw] = useState("");
  const [cf, setCf] = useState("");
  const [hint, setHint] = useState("");
  const [err, setErr] = useState<string | null>(null);
  return (
    <div className="mx-auto max-w-md space-y-4 pt-4 text-center">
      <div className="flex justify-center"><LockArt /></div>
      <h1 className="text-3xl font-semibold">Protect your Data Sheets</h1>
      <p className="text-sm text-muted">Create a master password. Only a salted hash is stored — we can't read it back.</p>
      <div className="card space-y-4 p-5 text-left">
        <TextField label="Master password" type="password" value={pw} onChange={setPw} />
        <TextField label="Confirm password" type="password" value={cf} onChange={setCf} />
        <TextField label="Hint (optional)" value={hint} onChange={setHint} />
        {err && <p className="text-sm text-err">{err}</p>}
        <button className="btn btn-primary w-full" onClick={async () => {
          try { await api("/api/lock", { body: { action: "setup", password: pw, confirm: cf, hint } }); onDone(); } catch (e) { setErr((e as Error).message); }
        }}>Create password</button>
      </div>
    </div>
  );
}

function Unlock({ hint, onDone }: { hint: string | null; onDone: () => void }) {
  const [pw, setPw] = useState("");
  const [err, setErr] = useState<string | null>(null);
  const [shake, setShake] = useState(false);
  const [opening, setOpening] = useState(false);
  const [forgot, setForgot] = useState(false);
  const [showHint, setShowHint] = useState(false);
  const [owner, setOwner] = useState(false);
  const [np, setNp] = useState("");
  const [nc, setNc] = useState("");
  async function submit() {
    try {
      if (forgot) await api("/api/lock", { body: { action: "reset", next: np, confirm: nc, confirmOwner: owner } });
      else await api("/api/lock", { body: { action: "unlock", password: pw } });
      setOpening(true);
      haptic(20);
      setTimeout(onDone, 650);
    } catch (e) {
      setErr((e as Error).message);
      setShake(true);
      setTimeout(() => setShake(false), 500);
    }
  }
  return (
    <div className="mx-auto max-w-md space-y-4 pt-4 text-center">
      <div className="flex justify-center"><LockArt open={opening} /></div>
      <h1 className="text-3xl font-semibold">{forgot ? "Reset master password" : "Data Sheets are locked"}</h1>
      <div className={cn("card space-y-4 p-5 text-left", shake && "border-err")} style={shake ? { transform: "translateX(6px)" } : undefined}>
        {!forgot ? (
          <>
            <TextField label="Master password" type="password" value={pw} onChange={setPw} error={err} />
            {hint && (showHint ? <p className="text-sm text-muted">Hint: {hint}</p> : <button className="text-sm text-primary underline" onClick={() => setShowHint(true)}>Show hint</button>)}
          </>
        ) : (
          <>
            <p className="text-sm text-muted">Your data is kept — only the password changes. Web builds can't re-authenticate with Google, so please confirm you own this account.</p>
            <label className="flex items-center gap-3 text-sm"><input type="checkbox" className="h-5 w-5 accent-[var(--primary)]" checked={owner} onChange={(e) => setOwner(e.target.checked)} /> I am the owner of this account</label>
            <TextField label="New password" type="password" value={np} onChange={setNp} />
            <TextField label="Confirm new password" type="password" value={nc} onChange={setNc} error={err} />
          </>
        )}
        <button className="btn btn-primary w-full" onClick={submit}><Icon name="unlock" size={18} /> {forgot ? "Reset & unlock" : "Unlock"}</button>
        <button className="w-full text-center text-sm text-muted underline" onClick={() => { setForgot(!forgot); setErr(null); }}>{forgot ? "Back to unlock" : "Forgot password?"}</button>
      </div>
    </div>
  );
}

/* ───────── sheets ───────── */
const EDIT: Record<string, string> = { odometer: "odometer", fuel: "fuel", repairs: "repairs", damages: "damages" };

function display(c: Col, v: Cell): string {
  if (v === null || v === "" || v === undefined) return "";
  if (c.type === "money") return inr(Number(v));
  if (c.type === "dec" || c.type === "int") return num(Number(v), 2);
  return String(v);
}
const plain = (v: Cell) => (v === null || v === undefined ? "" : String(v).replace(/[\t\n\r]+/g, " "));

function Sheets({ onLock, onExpired }: { onLock: () => void; onExpired: () => void }) {
  const router = useRouter();
  const toast = useToast();
  const [key, setKey] = useState<SheetKey>("odometer");
  const [data, setData] = useState<Sheet | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [sort, setSort] = useState<{ k: string; dir: 1 | -1 } | null>(null);
  const [q, setQ] = useState("");
  const [veh, setVeh] = useState("");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [sel, setSel] = useState<Set<number>>(new Set());
  const [cellMode, setCellMode] = useState(false);
  const [paste, setPaste] = useState(false);
  const [confirmDel, setConfirmDel] = useState(false);
  const [showFilters, setShowFilters] = useState(false);
  const press = useRef<ReturnType<typeof setTimeout> | null>(null);
  const longPressed = useRef(false);

  const load = useCallback(() => {
    setData(null);
    setError(null);
    api<Sheet>(`/api/sheets/${key}`).then(setData).catch((e: Error) => {
      if (/locked/i.test(e.message)) onExpired();
      else setError(e.message);
    });
  }, [key, onExpired]);
  useEffect(() => {
    load();
    setSel(new Set());
    setSort(null);
    setVeh("");
  }, [load]);

  const rows = useMemo(() => {
    if (!data) return [];
    let r = data.rows;
    if (q.trim()) r = r.filter((x) => Object.values(x.v).join(" ").toLowerCase().includes(q.trim().toLowerCase()));
    if (veh) r = r.filter((x) => x.v.vehicle === veh);
    if (from || to) r = r.filter((x) => { const d = x.s?.date ? istDay(Number(x.s.date)) : ""; return (!from || d >= from) && (!to || d <= to); });
    if (sort) {
      const k = sort.k;
      r = [...r].sort((a, b) => {
        const av = a.s?.[k] ?? a.v[k];
        const bv = b.s?.[k] ?? b.v[k];
        if (av === null || av === "") return 1;
        if (bv === null || bv === "") return -1;
        if (typeof av === "number" && typeof bv === "number") return (av - bv) * sort.dir;
        return String(av).localeCompare(String(bv), undefined, { numeric: true }) * sort.dir;
      });
    }
    return r;
  }, [data, q, veh, from, to, sort]);

  const tsv = (list: Row[], withHeader = true) => {
    const cols = data!.columns;
    const lines = list.map((r) => cols.map((c) => plain(r.v[c.key])).join("\t"));
    return (withHeader ? [cols.map((c) => c.label).join("\t"), ...lines] : lines).join("\n");
  };
  const copy = async (text: string, msg: string) => {
    try {
      await navigator.clipboard.writeText(text);
      toast.show(msg);
    } catch {
      toast.show("Couldn't access the clipboard", "err");
    }
  };
  const selRows = rows.filter((r) => sel.has(r.id));

  function exportCsv() {
    const cols = data!.columns;
    const esc = (s: string) => (/[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s);
    const csv = [cols.map((c) => esc(c.label)).join(","), ...rows.map((r) => cols.map((c) => esc(plain(r.v[c.key]))).join(","))].join("\n");
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([csv], { type: "text/csv" }));
    a.download = `hi-vehicle-${key}-${istDay(new Date())}.csv`;
    a.click();
  }

  const rowDown = (id: number) => {
    longPressed.current = false;
    press.current = setTimeout(() => {
      longPressed.current = true;
      haptic(20);
      setSel((s) => new Set(s).add(id));
    }, 450);
  };
  const rowCancel = () => press.current && clearTimeout(press.current);
  const rowClick = (id: number) => {
    if (longPressed.current) return;
    if (sel.size) setSel((s) => { const n = new Set(s); if (n.has(id)) n.delete(id); else n.add(id); return n; });
    else router.push(`/${EDIT[key]}/${id}/edit`);
  };

  async function deleteSelected() {
    setConfirmDel(false);
    try {
      await api(`/api/sheets/${key}`, { method: "DELETE", body: { ids: [...sel] } });
      toast.show(`${sel.size} row${sel.size > 1 ? "s" : ""} deleted`);
      setSel(new Set());
      load();
    } catch (e) {
      toast.show((e as Error).message, "err");
    }
  }

  return (
    <div>
      <div className="mb-4 flex items-start justify-between">
        <div>
          <h1 className="text-[34px] font-semibold leading-none">Data Sheets</h1>
          <div className="gold-rule mt-3" />
        </div>
        <button className="btn btn-soft !min-h-10 !px-4" onClick={onLock}><Icon name="lock" size={16} /> Lock</button>
      </div>
      <Segmented<SheetKey> value={key} onChange={setKey} options={KEYS.map((k) => ({ value: k.value, label: k.label }))} />

      <div className="mt-4 flex gap-2">
        <div className="relative flex-1">
          <Icon name="search" size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-muted" />
          <input className="input pl-11" placeholder="Search rows" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Search rows" />
        </div>
        <IconButton icon="filter" label="Filters" onClick={() => setShowFilters((s) => !s)} className={cn("border border-line", (veh || from || to) && "!border-gold text-primary")} />
      </div>
      {showFilters && data && (
        <div className="card rise mt-3 grid grid-cols-2 gap-3 p-4">
          <Field label="Vehicle" className="col-span-2">
            <select className="input" value={veh} onChange={(e) => setVeh(e.target.value)}>
              <option value="">All vehicles</option>
              {data.vehicleOptions.map((v) => <option key={v}>{v}</option>)}
            </select>
          </Field>
          <Field label="From"><input type="date" className="input" value={from} onChange={(e) => setFrom(e.target.value)} /></Field>
          <Field label="To"><input type="date" className="input" value={to} onChange={(e) => setTo(e.target.value)} /></Field>
        </div>
      )}

      <div className="mt-3 flex flex-wrap gap-2">
        <button className="btn btn-soft !min-h-10 !px-3.5 text-sm" disabled={!data} onClick={() => copy(tsv(rows), `Copied ${rows.length} rows — paste into Excel or Sheets`)}><Icon name="copy" size={16} /> Copy all</button>
        <button className="btn btn-soft !min-h-10 !px-3.5 text-sm" disabled={!data} onClick={() => setPaste(true)}><Icon name="upload" size={16} /> Paste data</button>
        <button className="btn btn-ghost !min-h-10 !px-3.5 text-sm" disabled={!data} onClick={exportCsv}><Icon name="download" size={16} /> CSV</button>
        <button className={cn("btn !min-h-10 !px-3.5 text-sm", cellMode ? "btn-primary" : "btn-ghost")} onClick={() => setCellMode((c) => !c)} aria-pressed={cellMode}>Cell copy</button>
      </div>

      {sel.size > 0 && (
        <div className="pop mt-3 flex items-center gap-2 rounded-2xl bg-primary px-4 py-2 text-onp">
          <span className="flex-1 text-sm font-semibold">{sel.size} selected</span>
          <button className="rounded-full px-3 py-2 text-sm font-semibold" onClick={() => copy(tsv(selRows, false), `Copied ${sel.size} rows`)}>Copy</button>
          <button className="rounded-full px-3 py-2 text-sm font-semibold" onClick={() => setConfirmDel(true)}>Delete</button>
          <IconButton icon="close" label="Clear selection" onClick={() => setSel(new Set())} className="!text-onp" />
        </div>
      )}
      <p className="mt-2 text-xs text-muted">Tap a row to edit · long-press to select{cellMode ? " · tap a cell to copy it" : ""}</p>

      <div className="mt-2">
        {error && <ErrorBox message={error} retry={load} />}
        {!data && !error && <Skeleton rows={4} />}
        {data && !rows.length && <EmptyState text={data.rows.length ? "No rows match these filters." : "This sheet is empty. Paste rows from a spreadsheet to fill it."} />}
        {data && rows.length > 0 && (
          <div className="card max-h-[62vh] overflow-auto">
            <table className="sheet-table w-full border-separate border-spacing-0">
              <thead>
                <tr>
                  {data.columns.map((c) => (
                    <th key={c.key} className="cursor-pointer select-none" onClick={() => setSort((s) => (s?.k === c.key ? (s.dir === 1 ? { k: c.key, dir: -1 } : null) : { k: c.key, dir: 1 }))} aria-sort={sort?.k === c.key ? (sort.dir === 1 ? "ascending" : "descending") : "none"}>
                      {c.label} {sort?.k === c.key && <span className="text-gold">{sort.dir === 1 ? "▲" : "▼"}</span>}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {rows.map((r) => (
                  <tr key={r.id} className={cn("cursor-pointer", sel.has(r.id) && "sel")} onPointerDown={() => rowDown(r.id)} onPointerUp={rowCancel} onPointerLeave={rowCancel} onPointerMove={rowCancel} onClick={() => rowClick(r.id)}>
                    {data.columns.map((c) => (
                      <td
                        key={c.key}
                        className={cn("tabular", c.type !== "text" && "text-right")}
                        onClick={(e) => {
                          if (cellMode) {
                            e.stopPropagation();
                            void copy(plain(r.v[c.key]), "Cell copied");
                          }
                        }}
                      >
                        {display(c, r.v[c.key])}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
        {data && <p className="mt-2 text-xs text-muted">{rows.length} of {data.rows.length} rows</p>}
      </div>

      {paste && data && <PasteImport sheet={key} title={data.title} fields={data.importFields} onClose={() => setPaste(false)} onDone={() => { setPaste(false); load(); }} />}
      <ConfirmDialog open={confirmDel} title={`Delete ${sel.size} row${sel.size > 1 ? "s" : ""}?`} message="This permanently removes the selected records." onCancel={() => setConfirmDel(false)} onConfirm={deleteSelected} />
    </div>
  );
}
