"use client";
import { createContext, ReactNode, useCallback, useContext, useEffect, useRef, useState } from "react";
import { Icon, IconButton } from "./ui";

export type ViewImg = { id?: number; data?: string; thumb: string; title?: string | null };
type Ctx = { open: (list: ViewImg[], index?: number) => void };
const ViewerContext = createContext<Ctx>({ open: () => {} });
export const useViewer = () => useContext(ViewerContext);

const srcOf = (i: ViewImg) => (i.id ? `/api/images/${i.id}` : (i.data ?? i.thumb));

export function ViewerProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<{ list: ViewImg[]; index: number } | null>(null);
  const open = useCallback<Ctx["open"]>((list, index = 0) => list.length && setState({ list, index }), []);
  return (
    <ViewerContext.Provider value={{ open }}>
      {children}
      {state && <Viewer list={state.list} start={state.index} onClose={() => setState(null)} />}
    </ViewerContext.Provider>
  );
}

function Viewer({ list, start, onClose }: { list: ViewImg[]; start: number; onClose: () => void }) {
  const [index, setIndex] = useState(start);
  const [t, setT] = useState({ s: 1, x: 0, y: 0 });
  const [loaded, setLoaded] = useState(false);
  const pointers = useRef(new Map<number, { x: number; y: number }>());
  const gesture = useRef({ dist: 0, s: 1, x: 0, y: 0, lastTap: 0, moved: 0, startX: 0 });
  const img = list[index];

  const go = useCallback(
    (d: number) => {
      setIndex((i) => Math.min(list.length - 1, Math.max(0, i + d)));
      setT({ s: 1, x: 0, y: 0 });
      setLoaded(false);
    },
    [list.length],
  );

  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
      if (e.key === "ArrowRight") go(1);
      if (e.key === "ArrowLeft") go(-1);
    };
    window.addEventListener("keydown", h);
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", h);
      document.body.style.overflow = "";
    };
  }, [go, onClose]);

  const down = (e: React.PointerEvent) => {
    (e.target as Element).setPointerCapture(e.pointerId);
    pointers.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
    const g = gesture.current;
    g.moved = 0;
    g.startX = e.clientX;
    if (pointers.current.size === 2) {
      const [a, b] = [...pointers.current.values()];
      g.dist = Math.hypot(a.x - b.x, a.y - b.y);
      g.s = t.s;
    }
  };
  const move = (e: React.PointerEvent) => {
    const p = pointers.current.get(e.pointerId);
    if (!p) return;
    const g = gesture.current;
    const dx = e.clientX - p.x;
    const dy = e.clientY - p.y;
    pointers.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
    g.moved += Math.abs(dx) + Math.abs(dy);
    if (pointers.current.size === 2) {
      const [a, b] = [...pointers.current.values()];
      const d = Math.hypot(a.x - b.x, a.y - b.y);
      setT((c) => ({ ...c, s: Math.min(6, Math.max(1, g.s * (d / (g.dist || d)))) }));
    } else if (t.s > 1) {
      setT((c) => ({ ...c, x: c.x + dx, y: c.y + dy }));
    }
  };
  const up = (e: React.PointerEvent) => {
    const g = gesture.current;
    pointers.current.delete(e.pointerId);
    if (pointers.current.size > 0) return;
    if (g.moved < 8) {
      const now = Date.now();
      if (now - g.lastTap < 300) setT((c) => (c.s > 1 ? { s: 1, x: 0, y: 0 } : { s: 2.5, x: 0, y: 0 }));
      g.lastTap = now;
    } else if (t.s <= 1) {
      const dx = e.clientX - g.startX;
      if (dx < -60) go(1);
      else if (dx > 60) go(-1);
    }
    if (t.s <= 1.02) setT({ s: 1, x: 0, y: 0 });
  };

  async function share() {
    try {
      const blob = await (await fetch(srcOf(img))).blob();
      const file = new File([blob], `${img.title || "image"}.jpg`, { type: blob.type });
      if (navigator.canShare?.({ files: [file] })) await navigator.share({ files: [file], title: img.title ?? "HI VEHICLE" });
      else if (navigator.share) await navigator.share({ title: img.title ?? "HI VEHICLE", url: location.origin + srcOf(img) });
    } catch {
      /* user cancelled */
    }
  }

  return (
    <div className="fade fixed inset-0 z-[100] flex flex-col bg-black/95 text-white" role="dialog" aria-modal="true" aria-label="Image viewer">
      <div className="flex items-center justify-between px-3 py-2">
        <span className="px-3 text-sm text-white/70">
          {index + 1} / {list.length}
        </span>
        <div className="flex">
          <IconButton icon="share" label="Share" onClick={share} className="!text-white/80" />
          <a href={srcOf(img)} download={`${img.title || "image"}.jpg`} aria-label="Save image" className="inline-flex h-12 w-12 items-center justify-center rounded-full text-white/80">
            <Icon name="download" />
          </a>
          <IconButton icon="close" label="Close" onClick={onClose} className="!text-white/80" />
        </div>
      </div>
      <div
        className="relative flex-1 touch-none select-none overflow-hidden"
        onPointerDown={down}
        onPointerMove={move}
        onPointerUp={up}
        onPointerCancel={up}
        onWheel={(e) => setT((c) => ({ ...c, s: Math.min(6, Math.max(1, c.s - e.deltaY * 0.002)) }))}
      >
        <div className="pop absolute inset-0 flex items-center justify-center" style={{ transform: `translate(${t.x}px, ${t.y}px) scale(${t.s})`, transition: pointers.current.size ? "none" : "transform .25s" }}>
          {/* thumbnail shows instantly while the full-resolution original loads */}
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={img.thumb} alt="" draggable={false} className="absolute max-h-full max-w-full object-contain blur-[2px]" />
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img key={srcOf(img)} src={srcOf(img)} alt={img.title ?? "Image"} draggable={false} onLoad={() => setLoaded(true)} className="relative max-h-full max-w-full object-contain transition-opacity duration-300" style={{ opacity: loaded ? 1 : 0 }} />
        </div>
        {index > 0 && <IconButton icon="chevL" label="Previous" onClick={() => go(-1)} className="absolute left-2 top-1/2 !bg-black/40 !text-white" />}
        {index < list.length - 1 && <IconButton icon="chevR" label="Next" onClick={() => go(1)} className="absolute right-2 top-1/2 !bg-black/40 !text-white" />}
      </div>
      <div className="min-h-14 px-6 py-4 text-center">
        <span className="serif text-xl">{img.title || ""}</span>
      </div>
    </div>
  );
}
