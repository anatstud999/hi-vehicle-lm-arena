"use client";
import { ReactNode, useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { cn, inr, num } from "@/lib/format";
import { ConfirmDialog, Icon, IconButton, SuccessCheck } from "./ui";
import { haptic } from "@/lib/client";

export function Field({ label, error, hint, children, className }: { label?: string; error?: string | null; hint?: ReactNode; children: ReactNode; className?: string }) {
  return (
    <label className={cn("block", className)}>
      {label && <span className="mb-1.5 block text-[13px] font-semibold text-muted">{label}</span>}
      {children}
      {error ? <span className="mt-1 block text-[13px] text-err">{error}</span> : hint ? <span className="mt-1 block text-[13px] text-muted">{hint}</span> : null}
    </label>
  );
}

type P = { label?: string; value: string; onChange: (v: string) => void; error?: string | null; placeholder?: string; hint?: ReactNode; className?: string };

export function TextField({ label, value, onChange, error, placeholder, hint, className, upper, type = "text" }: P & { upper?: boolean; type?: string }) {
  return (
    <Field label={label} error={error} hint={hint} className={className}>
      <input className={cn("input", error && "invalid")} type={type} value={value} placeholder={placeholder} onChange={(e) => onChange(upper ? e.target.value.toUpperCase() : e.target.value)} />
    </Field>
  );
}

export function TextArea({ label, value, onChange, placeholder, rows = 3, className }: P & { rows?: number }) {
  return (
    <Field label={label} className={className}>
      <textarea className="input" rows={rows} value={value} placeholder={placeholder} onChange={(e) => onChange(e.target.value)} />
    </Field>
  );
}

const cleanNum = (s: string) => s.replace(/[^0-9.]/g, "").replace(/(\..*)\./g, "$1");

export function MoneyField({ label = "Amount", value, onChange, error, hint, className }: P) {
  const n = Number(value);
  return (
    <Field label={label} error={error} className={className} hint={hint ?? (value && Number.isFinite(n) ? inr(n) : undefined)}>
      <div className="relative">
        <span className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 font-semibold text-gold">₹</span>
        <input className={cn("input pl-9", error && "invalid")} inputMode="decimal" value={value} onChange={(e) => onChange(cleanNum(e.target.value))} placeholder="0" />
      </div>
    </Field>
  );
}

export function OdoField({ label, value, onChange, error, hint, className, suffix = "km" }: P & { suffix?: string }) {
  return (
    <Field label={label} error={error} hint={hint} className={className}>
      <div className="relative">
        <input className={cn("input pr-14", error && "invalid")} inputMode="decimal" value={value} onChange={(e) => onChange(cleanNum(e.target.value))} placeholder="0" />
        <span className="pointer-events-none absolute right-4 top-1/2 -translate-y-1/2 text-sm text-muted">{suffix}</span>
      </div>
    </Field>
  );
}

export function DateTimeField({ label = "Date & time", value, onChange, error, className }: Omit<P, "placeholder">) {
  return (
    <Field label={label} error={error} className={className}>
      <input className={cn("input", error && "invalid")} type="datetime-local" value={value} onChange={(e) => onChange(e.target.value)} />
    </Field>
  );
}

export function DateField({ label, value, onChange, error, className }: Omit<P, "placeholder">) {
  return (
    <Field label={label} error={error} className={className}>
      <input className={cn("input", error && "invalid")} type="date" value={value} onChange={(e) => onChange(e.target.value)} />
    </Field>
  );
}

export function SelectField({
  label,
  value,
  onChange,
  options,
  error,
  className,
}: {
  label?: string;
  value: string;
  onChange: (v: string) => void;
  options: string[];
  error?: string | null;
  className?: string;
}) {
  return (
    <Field label={label} error={error} className={className}>
      <div className="relative">
        <select className="input appearance-none pr-10" value={value} onChange={(e) => onChange(e.target.value)}>
          {options.map((o) => (
            <option key={o}>{o}</option>
          ))}
        </select>
        <Icon name="chevD" size={18} className="pointer-events-none absolute right-4 top-1/2 -translate-y-1/2 text-muted" />
      </div>
    </Field>
  );
}

export function YearField({ label, value, onChange, className }: Omit<P, "placeholder">) {
  const y = new Date().getFullYear();
  return (
    <Field label={label} className={className}>
      <div className="relative">
        <select className="input appearance-none pr-10" value={value} onChange={(e) => onChange(e.target.value)}>
          <option value="">Select year</option>
          {Array.from({ length: 45 }, (_, i) => y + 1 - i).map((yy) => (
            <option key={yy} value={yy}>
              {yy}
            </option>
          ))}
        </select>
        <Icon name="chevD" size={18} className="pointer-events-none absolute right-4 top-1/2 -translate-y-1/2 text-muted" />
      </div>
    </Field>
  );
}

/** Grouped section card used on every form */
export function Group({ title, children, index = 0 }: { title?: string; children: ReactNode; index?: number }) {
  return (
    <section className="card rise space-y-4 p-5" style={{ ["--i" as string]: index }}>
      {title && (
        <div>
          <h2 className="text-xl font-semibold text-ink">{title}</h2>
          <div className="gold-rule mt-1.5" />
        </div>
      )}
      {children}
    </section>
  );
}

/** Full-screen form frame with back button, sticky Save bar, optional delete */
export function FormShell({
  title,
  children,
  onSave,
  saving,
  error,
  onDelete,
  saveLabel = "Save",
  done,
}: {
  title: string;
  children: ReactNode;
  onSave: () => void | Promise<void>;
  saving: boolean;
  error?: string | null;
  onDelete?: () => void | Promise<void>;
  saveLabel?: string;
  done?: boolean;
}) {
  const router = useRouter();
  const [confirm, setConfirm] = useState(false);
  return (
    <div className="pb-32">
      <div className="mb-5 flex items-center gap-1">
        <IconButton icon="chevL" label="Back" onClick={() => router.back()} className="-ml-3" />
        <div>
          <h1 className="text-[30px] font-semibold leading-none">{title}</h1>
          <div className="gold-rule mt-2" />
        </div>
      </div>
      <div className="space-y-4">{children}</div>
      {error && <p className="mt-4 rounded-2xl bg-[color-mix(in_srgb,var(--err)_14%,transparent)] p-3 text-sm text-err" role="alert">{error}</p>}
      <div className="fixed inset-x-0 bottom-0 z-40 border-t border-line bg-surface/95 px-4 py-3 backdrop-blur">
        <div className="mx-auto flex max-w-2xl gap-3">
          {onDelete && (
            <button type="button" className="btn btn-ghost !px-4 text-err" onClick={() => setConfirm(true)} aria-label="Delete">
              <Icon name="trash" />
            </button>
          )}
          <button
            type="button"
            disabled={saving}
            className="btn btn-primary flex-1"
            onClick={() => {
              haptic();
              void onSave();
            }}
          >
            {saving ? "Saving…" : saveLabel}
          </button>
        </div>
      </div>
      <ConfirmDialog
        open={confirm}
        title="Delete this record?"
        message="This can't be undone."
        onCancel={() => setConfirm(false)}
        onConfirm={async () => {
          setConfirm(false);
          await onDelete?.();
        }}
      />
      <SuccessCheck show={!!done} />
    </div>
  );
}

/** Small hook shared by forms: runs save, shows the success animation, then navigates back */
export function useSaver() {
  const router = useRouter();
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [done, setDone] = useState(false);
  async function run(fn: () => Promise<unknown>, after?: () => void) {
    setSaving(true);
    setError(null);
    try {
      await fn();
      setDone(true);
      haptic(25);
      setTimeout(() => {
        if (after) after();
        else router.back();
      }, 800);
    } catch (e) {
      setError((e as Error).message);
      window.scrollTo({ top: document.body.scrollHeight, behavior: "smooth" });
      setSaving(false);
    }
  }
  return { saving, error, done, run, setError };
}

export function Metric({ label, value, tone }: { label: string; value: ReactNode; tone?: "ok" | "err" | "muted" }) {
  return (
    <div className="rounded-2xl bg-pc/60 p-3">
      <div className="text-[11px] font-semibold uppercase tracking-wider text-muted">{label}</div>
      <div className={cn("serif mt-1 text-2xl font-semibold", tone === "err" && "text-err", tone === "ok" && "text-ok")}>{value}</div>
    </div>
  );
}

export function useDebounced<T>(v: T, ms = 300): T {
  const [d, setD] = useState(v);
  useEffect(() => {
    const t = setTimeout(() => setD(v), ms);
    return () => clearTimeout(t);
  }, [v, ms]);
  return d;
}

export { num };
