"use client";
import { useEffect, useState } from "react";
import { api } from "@/lib/client";
import { fmtDate, fromInputValue, inr, num, toInputValue } from "@/lib/format";
import { DateTimeField, FormShell, Group, Metric, MoneyField, OdoField, TextArea, TextField, useSaver } from "../fields";
import { ImagePicker, ImgItem, toItems, toPayload } from "../ImagePicker";
import { DriverMultiSelector, DriverSelector, VehicleSelector } from "../Selectors";
import { Card, CountUp, Icon, Segmented, Switch } from "../ui";
import { Loader } from "./basic";
import { useRouter } from "next/navigation";

type Imgs = { id: number; title: string | null; thumb: string; isCover: boolean }[];

/* ═════════ odometer ═════════ */
type OdoRec = { vehicleId: number; driverId: number | null; at: string; startKm: number; stopKm: number };
type Ctx = { missing: string[]; lastStop: number | null; kmBefore: number };
type DayChoice = "holiday" | "non_working" | "no_info";

export function OdometerForm({ id }: { id?: number }) {
  return <Loader<OdoRec> resource="odometer" id={id}>{(d) => <OdoInner id={id} d={d} />}</Loader>;
}
function OdoInner({ id, d }: { id?: number; d: OdoRec | null }) {
  const router = useRouter();
  const [vehicleId, setVehicleId] = useState<number | null>(d?.vehicleId ?? null);
  const [at, setAt] = useState(toInputValue(d?.at ?? new Date()));
  const [driverId, setDriverId] = useState<number | null>(d?.driverId ?? null);
  const [start, setStart] = useState(d ? String(d.startKm) : "");
  const [stop, setStop] = useState(d ? String(d.stopKm) : "");
  const [touched, setTouched] = useState(!!d);
  const [ctx, setCtx] = useState<Ctx | null>(null);
  const [choices, setChoices] = useState<Record<string, DayChoice>>({});
  const [errs, setErrs] = useState<Record<string, string>>({});
  const s = useSaver();

  // Recompute missing days + last stop whenever vehicle or date changes
  useEffect(() => {
    if (!vehicleId) {
      setCtx(null);
      return;
    }
    let off = false;
    api<Ctx>(`/api/odometer/missing?vehicleId=${vehicleId}&at=${encodeURIComponent(fromInputValue(at))}${id ? `&excludeId=${id}` : ""}`)
      .then((c) => {
        if (off) return;
        setCtx(c);
        if (!touched && c.lastStop !== null) setStart(String(c.lastStop));
      })
      .catch(() => {});
    return () => {
      off = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [vehicleId, at]);

  const a = Number(start);
  const b = Number(stop);
  const valid = start !== "" && stop !== "" && b >= a;
  const trip = valid ? b - a : 0;
  const mismatch = ctx?.lastStop != null && start !== "" && a !== ctx.lastStop;

  async function save() {
    const e: Record<string, string> = {};
    if (!vehicleId) e.vehicle = "Choose a vehicle";
    if (start === "") e.start = "Enter the starting reading";
    if (stop === "") e.stop = "Enter the stopping reading";
    else if (start !== "" && b < a) e.stop = "Stopping reading must be at least the starting reading";
    setErrs(e);
    if (Object.keys(e).length) return;
    const dayStatuses = Object.entries(choices).map(([day, status]) => ({ day, status }));
    await s.run(() =>
      api(id ? `/api/odometer/${id}` : "/api/odometer", {
        method: id ? "PUT" : "POST",
        body: { vehicleId, driverId, at: fromInputValue(at), startKm: start, stopKm: stop, dayStatuses },
      }),
    );
  }

  return (
    <FormShell
      title={id ? "Edit reading" : "Odometer reading"}
      onSave={save}
      saving={s.saving}
      error={s.error}
      done={s.done}
      onDelete={id ? async () => { await api(`/api/odometer/${id}`, { method: "DELETE" }); router.back(); } : undefined}
    >
      <Group index={0}>
        <VehicleSelector value={vehicleId} onChange={(v) => setVehicleId(v)} error={errs.vehicle} />
        <DateTimeField value={at} onChange={setAt} />
      </Group>

      {ctx && ctx.missing.length > 0 && (
        <Group title="Days without a reading" index={1}>
          <p className="-mt-2 text-sm text-muted">The last {ctx.missing.length} day{ctx.missing.length > 1 ? "s" : ""} before this date with no entry. Mark them so they stop showing up.</p>
          <div className="space-y-3">
            {ctx.missing.map((day, i) => (
              <div key={day} className="rise rounded-2xl border border-line bg-bg/60 p-3" style={{ ["--i" as string]: i }}>
                <div className="mb-2 flex items-center gap-2 text-sm font-semibold">
                  <Icon name="calendar" size={16} className="text-gold" />
                  {fmtDate(day)}
                </div>
                <Segmented<DayChoice>
                  value={choices[day] ?? "no_info"}
                  onChange={(v) => setChoices((c) => ({ ...c, [day]: v }))}
                  options={[
                    { value: "holiday", label: "Holiday" },
                    { value: "non_working", label: "Non-working" },
                    { value: "no_info", label: "No information" },
                  ]}
                />
              </div>
            ))}
          </div>
        </Group>
      )}

      <Group title="Reading" index={2}>
        <DriverSelector value={driverId} onChange={setDriverId} />
        <OdoField
          label="Starting reading"
          value={start}
          onChange={(v) => {
            setStart(v);
            setTouched(true);
          }}
          error={errs.start}
          hint={mismatch ? <span className="text-warn">Differs from the last stopping reading ({num(ctx!.lastStop, 1)} km). Is that intended?</span> : ctx?.lastStop != null ? `Last stopping reading: ${num(ctx.lastStop, 1)} km` : undefined}
        />
        <OdoField label="Stopping reading" value={stop} onChange={setStop} error={errs.stop} />
        <div className="grid grid-cols-2 gap-3">
          <Metric label="This trip" value={<><CountUp value={trip} format={(n) => num(n, 1)} /> <span className="text-sm font-normal text-muted">km</span></>} />
          <Metric label="Vehicle total to date" value={<><CountUp value={(ctx?.kmBefore ?? 0) + trip} format={(n) => num(n, 1)} /> <span className="text-sm font-normal text-muted">km</span></>} />
        </div>
      </Group>
    </FormShell>
  );
}

/* ═════════ fuel ═════════ */
type FuelRec = { vehicleId: number; at: string; fuelType: string; litres: number; odometer: number; amount: number | null; fullTank: boolean; images: Imgs };
type Prev = { previous: { id: number; at: string; odometer: number; litres: number; mileage: number | null; goodMileage: number | null; fuelType: string } | null };

export function FuelForm({ id }: { id?: number }) {
  return <Loader<FuelRec> resource="fuel" id={id}>{(d) => <FuelInner id={id} d={d} />}</Loader>;
}
function FuelInner({ id, d }: { id?: number; d: FuelRec | null }) {
  const router = useRouter();
  const [vehicleId, setVehicleId] = useState<number | null>(d?.vehicleId ?? null);
  const [at, setAt] = useState(toInputValue(d?.at ?? new Date()));
  const [type, setType] = useState<"Diesel" | "Petrol">((d?.fuelType as "Diesel" | "Petrol") ?? "Diesel");
  const [litres, setLitres] = useState(d ? String(d.litres) : "");
  const [odo, setOdo] = useState(d ? String(d.odometer) : "");
  const [amount, setAmount] = useState(d?.amount != null ? String(d.amount) : "");
  const [full, setFull] = useState(d?.fullTank ?? true);
  const [imgs, setImgs] = useState<ImgItem[]>(toItems(d?.images));
  const [prev, setPrev] = useState<Prev["previous"]>(null);
  const [errs, setErrs] = useState<Record<string, string>>({});
  const s = useSaver();

  useEffect(() => {
    if (!vehicleId) {
      setPrev(null);
      return;
    }
    let off = false;
    api<Prev>(`/api/fuel/previous?vehicleId=${vehicleId}&at=${encodeURIComponent(fromInputValue(at))}${id ? `&excludeId=${id}` : ""}`)
      .then((r) => !off && setPrev(r.previous))
      .catch(() => {});
    return () => {
      off = true;
    };
  }, [vehicleId, at, id]);

  const o = Number(odo);
  const l = Number(litres);
  const distance = prev && odo !== "" ? o - prev.odometer : null;
  const mileage = distance !== null && distance > 0 && l > 0 ? distance / l : null;
  const ref = prev?.goodMileage ?? null;
  const delta = mileage !== null && ref !== null ? mileage - ref : null;
  const odoLow = distance !== null && distance < 0;

  async function save() {
    const e: Record<string, string> = {};
    if (!vehicleId) e.vehicle = "Choose a vehicle";
    if (!litres || l <= 0) e.litres = "Enter the litres filled";
    if (odo === "") e.odo = "Enter the odometer reading";
    else if (odoLow) e.odo = `Cannot be lower than the previous refill (${num(prev!.odometer, 1)} km)`;
    setErrs(e);
    if (Object.keys(e).length) return;
    await s.run(() =>
      api(id ? `/api/fuel/${id}` : "/api/fuel", {
        method: id ? "PUT" : "POST",
        body: { vehicleId, at: fromInputValue(at), fuelType: type, litres, odometer: odo, amount, fullTank: full, images: toPayload(imgs) },
      }),
    );
  }

  return (
    <FormShell
      title={id ? "Edit refill" : "Fuel refill"}
      onSave={save}
      saving={s.saving}
      error={s.error}
      done={s.done}
      onDelete={id ? async () => { await api(`/api/fuel/${id}`, { method: "DELETE" }); router.back(); } : undefined}
    >
      <Group index={0}>
        <VehicleSelector value={vehicleId} onChange={(v) => setVehicleId(v)} error={errs.vehicle} />
        <DateTimeField label="Date of refill" value={at} onChange={setAt} />
        <div>
          <span className="mb-1.5 block text-[13px] font-semibold text-muted">Fuel type</span>
          <Segmented value={type} onChange={setType} options={[{ value: "Diesel", label: "Diesel" }, { value: "Petrol", label: "Petrol" }]} />
        </div>
      </Group>

      {vehicleId && (
        <Card className="rise p-4" style={{ ["--i" as string]: 1 }}>
          <div className="text-[11px] font-semibold uppercase tracking-wider text-muted">Previous refill</div>
          {prev ? (
            <div className="mt-2 grid grid-cols-3 gap-2 text-sm">
              <div><div className="text-xs text-muted">Date</div><b>{fmtDate(prev.at)}</b></div>
              <div><div className="text-xs text-muted">Odometer</div><b>{num(prev.odometer, 1)} km</b></div>
              <div><div className="text-xs text-muted">Volume</div><b>{num(prev.litres, 2)} L</b></div>
            </div>
          ) : (
            <p className="mt-1 text-sm text-muted">No earlier refill for this vehicle — this will be the baseline.</p>
          )}
        </Card>
      )}

      <Group title="This refill" index={2}>
        <OdoField label="Volume filled" suffix="L" value={litres} onChange={setLitres} error={errs.litres} />
        <OdoField label="Odometer reading" value={odo} onChange={setOdo} error={errs.odo} />
        <MoneyField label="Amount paid (optional)" value={amount} onChange={setAmount} />
        <div className="flex items-center justify-between gap-4 rounded-2xl bg-bg/60 p-3">
          <div>
            <div className="font-semibold">Tank filled to full</div>
            <div className="text-xs text-muted">Needed for an exact mileage figure</div>
          </div>
          <Switch checked={full} onChange={setFull} label="Tank filled to full" />
        </div>
        {prev && (
          <div className="grid grid-cols-2 gap-3">
            <Metric label="Distance since last" value={distance !== null && distance >= 0 ? <><CountUp value={distance} format={(n) => num(n, 1)} /> <span className="text-sm font-normal text-muted">km</span></> : "—"} tone={odoLow ? "err" : undefined} />
            <Metric
              label={full ? "Mileage" : "Mileage (estimated)"}
              value={
                mileage !== null ? (
                  <span className="inline-flex items-center gap-1">
                    <CountUp value={mileage} format={(n) => n.toFixed(2)} />
                    <span className="text-sm font-normal text-muted">km/L</span>
                    {delta !== null && <Icon name={delta >= 0 ? "up" : "down"} size={18} className={delta >= 0 ? "text-ok" : "text-err"} />}
                  </span>
                ) : (
                  "—"
                )
              }
            />
            {delta !== null && ref !== null && (
              <p className={`col-span-2 text-sm ${delta >= 0 ? "text-ok" : "text-err"}`}>
                {delta >= 0 ? "Up" : "Down"} {Math.abs(delta).toFixed(2)} km/L ({Math.abs((delta / ref) * 100).toFixed(1)}%) versus the previous {ref.toFixed(2)} km/L.
              </p>
            )}
            {!full && <p className="col-span-2 text-xs text-muted">Not a full tank, so this mileage is marked as estimated and left out of averages.</p>}
          </div>
        )}
      </Group>

      <Group title="Receipt / pump photos" index={3}>
        <ImagePicker value={imgs} onChange={setImgs} label="Photos" />
      </Group>
    </FormShell>
  );
}

/* ═════════ damage ═════════ */
type DamageRec = { vehicleId: number; at: string; description: string | null; amount: number; location: string | null; lat: number | null; lng: number | null; driverIds: number[]; images: Imgs };

export function DamageForm({ id }: { id?: number }) {
  return <Loader<DamageRec> resource="damages" id={id}>{(d) => <DamageInner id={id} d={d} />}</Loader>;
}
function DamageInner({ id, d }: { id?: number; d: DamageRec | null }) {
  const router = useRouter();
  const [vehicleId, setVehicleId] = useState<number | null>(d?.vehicleId ?? null);
  const [at, setAt] = useState(toInputValue(d?.at ?? new Date()));
  const [desc, setDesc] = useState(d?.description ?? "");
  const [amount, setAmount] = useState(d ? String(d.amount) : "");
  const [location, setLocation] = useState(d?.location ?? "");
  const [pin, setPin] = useState<{ lat: number; lng: number } | null>(d?.lat != null && d?.lng != null ? { lat: d.lat, lng: d.lng } : null);
  const [locBusy, setLocBusy] = useState(false);
  const [locErr, setLocErr] = useState<string | null>(null);
  const [driverIds, setDriverIds] = useState<number[]>(d?.driverIds ?? []);
  const [imgs, setImgs] = useState<ImgItem[]>(toItems(d?.images));
  const [errs, setErrs] = useState<Record<string, string>>({});
  const s = useSaver();

  function locate() {
    if (!navigator.geolocation) return setLocErr("Location isn't available on this device");
    setLocBusy(true);
    setLocErr(null);
    navigator.geolocation.getCurrentPosition(
      (p) => {
        setPin({ lat: p.coords.latitude, lng: p.coords.longitude });
        setLocBusy(false);
      },
      () => {
        setLocErr("Couldn't get your location. Check permission and try again.");
        setLocBusy(false);
      },
      { enableHighAccuracy: true, timeout: 10000 },
    );
  }

  async function save() {
    const e: Record<string, string> = {};
    if (!vehicleId) e.vehicle = "Choose a vehicle";
    if (amount !== "" && Number(amount) < 0) e.amount = "Amount cannot be negative";
    setErrs(e);
    if (Object.keys(e).length) return;
    await s.run(() =>
      api(id ? `/api/damages/${id}` : "/api/damages", {
        method: id ? "PUT" : "POST",
        body: { vehicleId, at: fromInputValue(at), description: desc, amount: amount || 0, location, lat: pin?.lat, lng: pin?.lng, driverIds, images: toPayload(imgs) },
      }),
    );
  }
  return (
    <FormShell
      title={id ? "Edit damage" : "Record damage"}
      onSave={save}
      saving={s.saving}
      error={s.error}
      done={s.done}
      onDelete={id ? async () => { await api(`/api/damages/${id}`, { method: "DELETE" }); router.back(); } : undefined}
    >
      <Group index={0}>
        <VehicleSelector value={vehicleId} onChange={(v) => setVehicleId(v)} error={errs.vehicle} />
        <DateTimeField value={at} onChange={setAt} />
        <TextArea label="Description" value={desc} onChange={setDesc} placeholder="What happened?" />
        <MoneyField value={amount} onChange={setAmount} error={errs.amount} hint="Cost of the damage" />
      </Group>
      <Group title="Photos" index={1}>
        <ImagePicker value={imgs} onChange={setImgs} label="Damage photos" />
      </Group>
      <Group title="Where & who" index={2}>
        <TextField label="Location of damage" value={location} onChange={setLocation} placeholder="Place, road, landmark" />
        <div className="flex flex-wrap items-center gap-2">
          <button type="button" className="btn btn-soft" onClick={locate} disabled={locBusy}>
            <Icon name="pin" size={18} /> {locBusy ? "Locating…" : pin ? "Update pin" : "Use current location"}
          </button>
          {pin && (
            <a className="text-sm text-primary underline" target="_blank" rel="noreferrer" href={`https://www.google.com/maps?q=${pin.lat},${pin.lng}`}>
              {pin.lat.toFixed(4)}, {pin.lng.toFixed(4)}
            </a>
          )}
          {pin && (
            <button type="button" className="text-sm text-muted underline" onClick={() => setPin(null)}>
              Remove pin
            </button>
          )}
        </div>
        {locErr && <p className="text-[13px] text-err">{locErr}</p>}
        <DriverMultiSelector value={driverIds} onChange={setDriverIds} />
      </Group>
    </FormShell>
  );
}

void inr;
