"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { api } from "@/lib/client";
import { cn, fromInputValue, num, toInputValue, today } from "@/lib/format";
import { DateField, DateTimeField, FormShell, Group, Metric, OdoField, TextArea, TextField, useSaver } from "../fields";
import { ImagePicker, ImgItem, toItems, toPayload } from "../ImagePicker";
import { VehicleSelector } from "../Selectors";
import { Icon, IconButton, Segmented } from "../ui";
import { Loader } from "./basic";

type Imgs = { id: number; title: string | null; thumb: string; isCover: boolean }[];
type TireRec = {
  code: string;
  images: Imgs;
  damages: { id: number; at: string; odometer: number | null; note: string | null; images: Imgs }[];
  trail: { vehicleId: number; fitDate: string; fitOdometer: number; removeDate: string | null; removeOdometer: number | null }[];
};
type Dmg = { key: string; id?: number; at: string; odometer: string; note: string; images: ImgItem[] };
type Trail = { key: string; vehicleId: number | null; fitDate: string; fitOdo: string; removed: boolean; removeDate: string; removeOdo: string };

let k = 0;
const key = () => `k${++k}`;

export function TireForm({ id }: { id?: number }) {
  return <Loader<TireRec> resource="tires" id={id}>{(d) => <Inner id={id} d={d} />}</Loader>;
}

function Inner({ id, d }: { id?: number; d: TireRec | null }) {
  const router = useRouter();
  const [code, setCode] = useState(d?.code ?? "");
  const [imgs, setImgs] = useState<ImgItem[]>(toItems(d?.images));
  const [tab, setTab] = useState<"damage" | "trail">(d && d.damages.length && !d.trail.length ? "damage" : "trail");
  const [dmgs, setDmgs] = useState<Dmg[]>(
    (d?.damages ?? []).map((x) => ({ key: key(), id: x.id, at: toInputValue(x.at), odometer: x.odometer != null ? String(x.odometer) : "", note: x.note ?? "", images: toItems(x.images) })),
  );
  const [trail, setTrail] = useState<Trail[]>(
    (d?.trail ?? []).map((t) => ({
      key: key(),
      vehicleId: t.vehicleId,
      fitDate: t.fitDate,
      fitOdo: String(t.fitOdometer),
      removed: !!t.removeDate || t.removeOdometer != null,
      removeDate: t.removeDate ?? "",
      removeOdo: t.removeOdometer != null ? String(t.removeOdometer) : "",
    })),
  );
  const [errs, setErrs] = useState<Record<string, string>>({});
  const s = useSaver();

  const patchT = (kk: string, p: Partial<Trail>) => setTrail((l) => l.map((x) => (x.key === kk ? { ...x, ...p } : x)));
  const patchD = (kk: string, p: Partial<Dmg>) => setDmgs((l) => l.map((x) => (x.key === kk ? { ...x, ...p } : x)));

  const kmRun = (t: Trail) => (t.removed && t.fitOdo !== "" && t.removeOdo !== "" ? Number(t.removeOdo) - Number(t.fitOdo) : null);
  const totalLife = trail.reduce((sum, t) => sum + Math.max(0, kmRun(t) ?? 0), 0);

  async function save() {
    const e: Record<string, string> = {};
    if (!code.trim()) e.code = "Tire code is required";
    trail.forEach((t, i) => {
      if (!t.vehicleId) e[`t${i}v`] = "Choose a vehicle";
      if (!t.fitDate) e[`t${i}d`] = "Fitting date needed";
      if (t.fitOdo === "") e[`t${i}o`] = "Odometer needed";
      if (t.removed && t.removeOdo !== "" && t.fitOdo !== "" && Number(t.removeOdo) < Number(t.fitOdo)) e[`t${i}r`] = "Must be at least the fitting odometer";
    });
    setErrs(e);
    if (Object.keys(e).length) {
      if (e.code) window.scrollTo({ top: 0, behavior: "smooth" });
      else setTab("trail");
      return;
    }
    await s.run(() =>
      api(id ? `/api/tires/${id}` : "/api/tires", {
        method: id ? "PUT" : "POST",
        body: {
          code,
          images: toPayload(imgs),
          damages: dmgs.map((x) => ({ id: x.id, at: fromInputValue(x.at), odometer: x.odometer, note: x.note, images: toPayload(x.images) })),
          trail: trail.map((t) => ({
            vehicleId: t.vehicleId,
            fitDate: t.fitDate,
            fitOdometer: t.fitOdo,
            removeDate: t.removed ? t.removeDate || null : null,
            removeOdometer: t.removed ? t.removeOdo : null,
          })),
        },
      }),
    );
  }

  return (
    <FormShell
      title={id ? "Edit tire" : "New tire"}
      onSave={save}
      saving={s.saving}
      error={s.error}
      done={s.done}
      onDelete={id ? async () => { await api(`/api/tires/${id}`, { method: "DELETE" }); router.back(); } : undefined}
    >
      <Group title="Tire" index={0}>
        <TextField label="Tire code *" value={code} onChange={setCode} upper error={errs.code} placeholder="Unique serial / code" />
        <ImagePicker value={imgs} onChange={setImgs} label="Tire photos" />
      </Group>

      <Group title="Tire map" index={1}>
        <Segmented value={tab} onChange={setTab} options={[{ value: "damage", label: `Damage${dmgs.length ? ` (${dmgs.length})` : ""}` }, { value: "trail", label: `Trail${trail.length ? ` (${trail.length})` : ""}` }]} />

        {tab === "damage" && (
          <div className="space-y-4">
            {!dmgs.length && <p className="py-4 text-center text-sm text-muted">No damage recorded for this tire. Add one if it gets damaged.</p>}
            {dmgs.map((x, i) => (
              <div key={x.key} className="rise space-y-3 rounded-2xl border border-line bg-bg/60 p-4">
                <div className="flex items-center justify-between">
                  <span className="serif text-lg font-semibold">Damage {i + 1}</span>
                  <IconButton icon="trash" label="Remove damage" size={18} onClick={() => setDmgs((l) => l.filter((y) => y.key !== x.key))} />
                </div>
                <DateTimeField value={x.at} onChange={(v) => patchD(x.key, { at: v })} />
                <OdoField label="Odometer reading" value={x.odometer} onChange={(v) => patchD(x.key, { odometer: v })} />
                <TextArea label="Note (optional)" value={x.note} onChange={(v) => patchD(x.key, { note: v })} rows={2} />
                <ImagePicker value={x.images} onChange={(v) => patchD(x.key, { images: v })} label="Damage photos" />
              </div>
            ))}
            <button type="button" className="btn btn-soft w-full" onClick={() => setDmgs((l) => [...l, { key: key(), at: toInputValue(new Date()), odometer: "", note: "", images: [] }])}>
              <Icon name="plus" size={18} /> Add damage record
            </button>
          </div>
        )}

        {tab === "trail" && (
          <div>
            {!trail.length && <p className="pb-3 text-center text-sm text-muted">Record each vehicle this tire has been fitted to, in order.</p>}
            <ol className="relative">
              {trail.map((t, i) => {
                const km = kmRun(t);
                return (
                  <li key={t.key} className="rise relative pb-5 pl-9">
                    {/* animated connector line */}
                    {i < trail.length - 1 && <span className="draw absolute bottom-0 left-[13px] top-7 w-px bg-gold" style={{ height: "100%", animation: "grow 0.6s both", transformOrigin: "top" }} />}
                    <span className={cn("absolute left-0 top-1 flex h-7 w-7 items-center justify-center rounded-full border-2 border-gold bg-surface text-xs font-bold text-primary")}>{i + 1}</span>
                    <div className="space-y-3 rounded-2xl border border-line bg-bg/60 p-4">
                      <div className="flex items-center justify-between">
                        <span className="serif text-lg font-semibold">Vehicle {i + 1}</span>
                        <IconButton icon="trash" label="Remove entry" size={18} onClick={() => setTrail((l) => l.filter((y) => y.key !== t.key))} />
                      </div>
                      <VehicleSelector value={t.vehicleId} onChange={(v) => patchT(t.key, { vehicleId: v })} error={errs[`t${i}v`]} />
                      <div className="grid grid-cols-2 gap-3">
                        <DateField label="Date of fitting" value={t.fitDate} onChange={(v) => patchT(t.key, { fitDate: v })} error={errs[`t${i}d`]} />
                        <OdoField label="Odometer at fitting" value={t.fitOdo} onChange={(v) => patchT(t.key, { fitOdo: v })} error={errs[`t${i}o`]} />
                      </div>
                      {!t.removed ? (
                        <button type="button" className="text-sm font-semibold text-primary underline" onClick={() => patchT(t.key, { removed: true, removeDate: today() })}>
                          + Add removal details
                        </button>
                      ) : (
                        <div className="space-y-3 border-t border-line pt-3">
                          <div className="grid grid-cols-2 gap-3">
                            <DateField label="Removal date" value={t.removeDate} onChange={(v) => patchT(t.key, { removeDate: v })} />
                            <OdoField label="Odometer at removal" value={t.removeOdo} onChange={(v) => patchT(t.key, { removeOdo: v })} error={errs[`t${i}r`]} />
                          </div>
                          <div className="flex items-center justify-between">
                            {km !== null && km >= 0 ? <span className="text-sm text-ok">Ran {num(km, 1)} km on this vehicle</span> : <span />}
                            <button type="button" className="text-sm text-muted underline" onClick={() => patchT(t.key, { removed: false, removeDate: "", removeOdo: "" })}>
                              Still fitted
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  </li>
                );
              })}
            </ol>
            <button
              type="button"
              className="btn btn-soft w-full"
              onClick={() => {
                const prev = trail[trail.length - 1];
                setTrail((l) => [...l.map((x, idx) => (idx === l.length - 1 && !x.removed ? { ...x, removed: true, removeDate: today(), removeOdo: "" } : x)), { key: key(), vehicleId: null, fitDate: today(), fitOdo: prev?.removeOdo ?? "", removed: false, removeDate: "", removeOdo: "" }]);
              }}
            >
              <Icon name="plus" size={18} /> {trail.length ? "Add next vehicle" : "Add first vehicle"}
            </button>
            {trail.length > 0 && (
              <div className="mt-4 grid grid-cols-2 gap-3">
                <Metric label="Vehicles" value={trail.length} />
                <Metric label="Tire life so far" value={<>{num(totalLife, 0)} <span className="text-sm font-normal text-muted">km</span></>} />
              </div>
            )}
          </div>
        )}
      </Group>
    </FormShell>
  );
}
