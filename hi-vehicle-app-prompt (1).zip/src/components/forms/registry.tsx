"use client";
import { DriverForm, PaymentForm, RepairForm, VehicleForm } from "./basic";
import { DamageForm, FuelForm, OdometerForm } from "./ops";
import { TireForm } from "./TireForm";
import { notFound } from "next/navigation";

export const MODULES = ["vehicles", "odometer", "fuel", "damages", "tires", "repairs", "drivers", "payments"];

export function ModuleForm({ module, id }: { module: string; id?: number }) {
  switch (module) {
    case "vehicles": return <VehicleForm id={id} />;
    case "odometer": return <OdometerForm id={id} />;
    case "fuel": return <FuelForm id={id} />;
    case "damages": return <DamageForm id={id} />;
    case "tires": return <TireForm id={id} />;
    case "repairs": return <RepairForm id={id} />;
    case "drivers": return <DriverForm id={id} />;
    case "payments": if (!id) notFound(); return <PaymentForm id={id} />;
  }
  notFound();
}
