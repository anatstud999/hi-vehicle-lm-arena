"use client";
import { ReactNode, useState } from "react";
import { useRouter } from "next/navigation";
import { api, useFetch } from "@/lib/client";
import { fromInputValue, toInputValue, today } from "@/lib/format";
import { DateField, DateTimeField, FormShell, Group, MoneyField, SelectField, TextArea, TextField, YearField, useSaver } from "../fields";
import { ImagePicker, ImgItem, toItems, toPayload } from "../ImagePicker";
import { VehicleSelector } from "../Selectors";
import { ErrorBox, Segmented, Skeleton } from "../ui";

/** Loads an existing record for edit forms, renders children(null) for new ones. */
export function Loader<T>({ resource, id, children }: { resource: string; id?: number; children: (d: T | null) => ReactNode }) {
  const { data, error, loading } = useFetch<T>(id ? `/api/${resource}/${id}` : null);
  if (id && loading) return <Skeleton rows={3} />;
  if (error) return <ErrorBox message={error} />;
  return <>{children(data)}</>;
}

function useDelete(resource: string, id?: number) {
  const router = useRouter();
  return id
    ? async () => {
        await api(`/api/${resource}/${id}`, { method: "DELETE" });
        router.back();
      }
    : undefined;
}

/* ═════════ vehicle ═════════ */
const TYPES = ["Bus", "Mini Bus", "Van", "Car", "Truck", "Tempo Traveller", "Other"];
type VehicleRec = { name: string; plate: string; purchaseYear: number | null; type: string; details: string | null; images: { id: number; title: string | null; thumb: string; isCover: boolean }[] };

export function VehicleForm({ id }: { id?: number }) {
  return <Loader<VehicleRec> resource="vehicles" id={id}>{(d) => <VehicleInner id={id} d={d} />}</Loader>;
}
function VehicleInner({ id, d }: { id?: number; d: VehicleRec | null }) {
  const known = d ? TYPES.includes(d.type) : true;
  const [name, setName] = useState(d?.name ?? "");
  const [plate, setPlate] = useState(d?.plate ?? "");
  const [year, setYear] = useState(d?.purchaseYear ? String(d.purchaseYear) : "");
  const [type, setType] = useState(d ? (known ? d.type : "Other") : "Bus");
  const [custom, setCustom] = useState(d && !known ? d.type : "");
  const [details, setDetails] = useState(d?.details ?? "");
  const [imgs, setImgs] = useState<ImgItem[]>(toItems(d?.images));
  const [errs, setErrs] = useState<Record<string, string>>({});
  const s = useSaver();
  const del = useDelete("vehicles", id);

  async function save() {
    const e: Record<string, string> = {};
    if (!name.trim()) e.name = "Please give the vehicle a name";
    if (!plate.trim()) e.plate = "Number plate is required";
    setErrs(e);
    if (Object.keys(e).length) return;
    const t = type === "Other" && custom.trim() ? custom.trim() : type;
    await s.run(() => api(id ? `/api/vehicles/${id}` : "/api/vehicles", { method: id ? "PUT" : "POST", body: { name, plate, purchaseYear: year, type: t, details, images: toPayload(imgs) } }));
  }
  return (
    <FormShell title={id ? "Edit vehicle" : "New vehicle"} onSave={save} saving={s.saving} error={s.error} done={s.done} onDelete={del}>
      <Group title="Identity" index={0}>
        <TextField label="Vehicle name *" value={name} onChange={setName} error={errs.name} placeholder="e.g. Sunrise Express" />
        <TextField label="Number plate *" value={plate} onChange={setPlate} upper error={errs.plate} placeholder="e.g. MH 12 AB 1234" />
        <div className="grid grid-cols-2 gap-3">
          <YearField label="Year of purchase" value={year} onChange={setYear} />
          <SelectField label="Vehicle type" value={type} onChange={setType} options={TYPES} />
        </div>
        {type === "Other" && <TextField label="Custom type" value={custom} onChange={setCustom} placeholder="e.g. Ambulance" />}
      </Group>
      <Group title="Photos" index={1}>
        <ImagePicker value={imgs} onChange={setImgs} cover label="Vehicle images (first is the cover)" />
      </Group>
      <Group title="Other details" index={2}>
        <TextArea value={details} onChange={setDetails} placeholder="Chassis no., insurance, permit… (optional)" rows={4} />
      </Group>
    </FormShell>
  );
}

/* ═════════ driver ═════════ */
type DriverRec = { name: string; monthlySalary: number; phone: string | null; licenseNo: string | null; licenseExpiry: string | null; joiningDate: string | null; details: string | null; images: VehicleRec["images"] };

export function DriverForm({ id }: { id?: number }) {
  return <Loader<DriverRec> resource="drivers" id={id}>{(d) => <DriverInner id={id} d={d} />}</Loader>;
}
function DriverInner({ id, d }: { id?: number; d: DriverRec | null }) {
  const [name, setName] = useState(d?.name ?? "");
  const [salary, setSalary] = useState(d ? String(d.monthlySalary) : "");
  const [phone, setPhone] = useState(d?.phone ?? "");
  const [lic, setLic] = useState(d?.licenseNo ?? "");
  const [licExp, setLicExp] = useState(d?.licenseExpiry ?? "");
  const [join, setJoin] = useState(d?.joiningDate ?? "");
  const [details, setDetails] = useState(d?.details ?? "");
  const [imgs, setImgs] = useState<ImgItem[]>(toItems(d?.images));
  const [errs, setErrs] = useState<Record<string, string>>({});
  const s = useSaver();
  const del = useDelete("drivers", id);
  async function save() {
    const e: Record<string, string> = {};
    if (!name.trim()) e.name = "Driver name is required";
    if (salary && Number(salary) < 0) e.salary = "Salary cannot be negative";
    setErrs(e);
    if (Object.keys(e).length) return;
    await s.run(() =>
      api(id ? `/api/drivers/${id}` : "/api/drivers", {
        method: id ? "PUT" : "POST",
        body: { name, monthlySalary: salary || 0, phone, licenseNo: lic, licenseExpiry: licExp, joiningDate: join, details, images: toPayload(imgs) },
      }),
    );
  }
  return (
    <FormShell title={id ? "Edit driver" : "New driver"} onSave={save} saving={s.saving} error={s.error} done={s.done} onDelete={del}>
      <Group title="Driver" index={0}>
        <TextField label="Name *" value={name} onChange={setName} error={errs.name} />
        <MoneyField label="Monthly salary" value={salary} onChange={setSalary} error={errs.salary} />
        <TextField label="Phone" value={phone} onChange={setPhone} type="tel" />
      </Group>
      <Group title="Licence & joining" index={1}>
        <TextField label="Licence number" value={lic} onChange={setLic} upper />
        <div className="grid grid-cols-2 gap-3">
          <DateField label="Licence expiry" value={licExp} onChange={setLicExp} />
          <DateField label="Joining date" value={join} onChange={setJoin} />
        </div>
        <TextArea label="Other details" value={details} onChange={setDetails} rows={3} />
      </Group>
      <Group title="Photos & documents" index={2}>
        <ImagePicker value={imgs} onChange={setImgs} cover label="Photo, licence copy…" />
      </Group>
    </FormShell>
  );
}

/* ═════════ driver payment ═════════ */
const REASONS = ["Salary", "Advance", "Bonus", "Deduction/Fine", "Other"];
type PayRec = { driverId: number; at: string; amount: number; paidBy: string | null; reason: string; forMonth: string; details: string | null; mode: string; images: VehicleRec["images"] };

export function PaymentForm({ id, driverId }: { id?: number; driverId?: number }) {
  return <Loader<PayRec> resource="payments" id={id}>{(d) => <PaymentInner id={id} driverId={d?.driverId ?? driverId!} d={d} />}</Loader>;
}
function PaymentInner({ id, driverId, d }: { id?: number; driverId: number; d: PayRec | null }) {
  const driver = useFetch<{ name: string; monthlySalary: number }>(`/api/drivers/${driverId}`);
  const [at, setAt] = useState(toInputValue(d?.at ?? new Date()));
  const [amount, setAmount] = useState(d ? String(d.amount) : "");
  const [paidBy, setPaidBy] = useState(d?.paidBy ?? "");
  const [reason, setReason] = useState(d?.reason ?? "Salary");
  const [month, setMonth] = useState(d?.forMonth ?? today().slice(0, 7));
  const [details, setDetails] = useState(d?.details ?? "");
  const [mode, setMode] = useState<"Cash" | "Online">((d?.mode as "Cash" | "Online") ?? "Cash");
  const [imgs, setImgs] = useState<ImgItem[]>(toItems(d?.images));
  const [errs, setErrs] = useState<Record<string, string>>({});
  const s = useSaver();
  const del = useDelete("payments", id);
  async function save() {
    const e: Record<string, string> = {};
    if (!amount || Number(amount) <= 0) e.amount = "Enter an amount greater than zero";
    if (!month) e.month = "Choose the month this payment is for";
    setErrs(e);
    if (Object.keys(e).length) return;
    await s.run(() =>
      api(id ? `/api/payments/${id}` : "/api/payments", {
        method: id ? "PUT" : "POST",
        body: { driverId, at: fromInputValue(at), amount, paidBy, reason, forMonth: month, details, mode, images: toPayload(imgs) },
      }),
    );
  }
  return (
    <FormShell title={id ? "Edit payment" : "Driver payment"} onSave={save} saving={s.saving} error={s.error} done={s.done} onDelete={del}>
      <p className="-mt-2 text-sm text-muted">
        For <b className="text-ink">{driver.data?.name ?? "…"}</b>
        {driver.data ? ` · salary ₹${driver.data.monthlySalary.toLocaleString("en-IN")} / month` : ""}
      </p>
      <Group title="Payment" index={0}>
        <DateTimeField value={at} onChange={setAt} />
        <MoneyField value={amount} onChange={setAmount} error={errs.amount} />
        <TextField label="Paid by" value={paidBy} onChange={setPaidBy} placeholder="Who handed over the money" />
        <SelectField label="Reason" value={reason} onChange={setReason} options={REASONS} />
        <TextField label="Payment of month" type="month" value={month} onChange={setMonth} error={errs.month} />
        <div>
          <span className="mb-1.5 block text-[13px] font-semibold text-muted">Mode</span>
          <Segmented value={mode} onChange={setMode} options={[{ value: "Cash", label: "Cash" }, { value: "Online", label: "Online" }]} />
        </div>
        <TextArea label="Other details" value={details} onChange={setDetails} />
      </Group>
      <Group title="Receipts" index={1}>
        <ImagePicker value={imgs} onChange={setImgs} label="Receipt, screenshot…" />
      </Group>
    </FormShell>
  );
}

/* ═════════ repair / new part ═════════ */
type RepairRec = { vehicleId: number; at: string; kind: string; amount: number; place: string | null; description: string | null; images: VehicleRec["images"] };

export function RepairForm({ id }: { id?: number }) {
  return <Loader<RepairRec> resource="repairs" id={id}>{(d) => <RepairInner id={id} d={d} />}</Loader>;
}
function RepairInner({ id, d }: { id?: number; d: RepairRec | null }) {
  const [at, setAt] = useState(toInputValue(d?.at ?? new Date()));
  const [vehicleId, setVehicleId] = useState<number | null>(d?.vehicleId ?? null);
  const [kind, setKind] = useState<"repair" | "part">((d?.kind as "repair" | "part") ?? "repair");
  const [amount, setAmount] = useState(d ? String(d.amount) : "");
  const [place, setPlace] = useState(d?.place ?? "");
  const [desc, setDesc] = useState(d?.description ?? "");
  const [imgs, setImgs] = useState<ImgItem[]>(toItems(d?.images));
  const [errs, setErrs] = useState<Record<string, string>>({});
  const s = useSaver();
  const del = useDelete("repairs", id);
  async function save() {
    const e: Record<string, string> = {};
    if (!vehicleId) e.vehicle = "Choose a vehicle";
    if (amount === "" || Number(amount) < 0) e.amount = "Enter the amount";
    setErrs(e);
    if (Object.keys(e).length) return;
    await s.run(() =>
      api(id ? `/api/repairs/${id}` : "/api/repairs", {
        method: id ? "PUT" : "POST",
        body: { vehicleId, at: fromInputValue(at), kind, amount, place, description: desc, images: toPayload(imgs) },
      }),
    );
  }
  return (
    <FormShell title={id ? "Edit entry" : "Repair / New part"} onSave={save} saving={s.saving} error={s.error} done={s.done} onDelete={del}>
      <Group index={0}>
        <DateTimeField value={at} onChange={setAt} />
        <VehicleSelector value={vehicleId} onChange={(v) => setVehicleId(v)} error={errs.vehicle} />
        <div>
          <span className="mb-1.5 block text-[13px] font-semibold text-muted">Type</span>
          <Segmented value={kind} onChange={setKind} options={[{ value: "repair", label: "Repair" }, { value: "part", label: "New Part" }]} />
        </div>
        <MoneyField value={amount} onChange={setAmount} error={errs.amount} />
        <TextField label="Place" value={place} onChange={setPlace} placeholder="Shop or garage" />
        <TextArea label="Description" value={desc} onChange={setDesc} />
      </Group>
      <Group title="Photos" index={1}>
        <ImagePicker value={imgs} onChange={setImgs} label="Bills, parts, work done…" />
      </Group>
    </FormShell>
  );
}
