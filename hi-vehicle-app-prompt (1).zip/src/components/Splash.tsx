"use client";
import { useEffect, useState } from "react";

/** Wordmark fades in, a gold line draws beneath it, and a minimal bus outline slides across. */
export function Splash() {
  const [show, setShow] = useState(false);
  const [leaving, setLeaving] = useState(false);
  useEffect(() => {
    if (sessionStorage.getItem("hv-splash")) return;
    sessionStorage.setItem("hv-splash", "1");
    setShow(true);
    const a = setTimeout(() => setLeaving(true), 1500);
    const b = setTimeout(() => setShow(false), 1900);
    return () => {
      clearTimeout(a);
      clearTimeout(b);
    };
  }, []);
  if (!show) return null;
  return (
    <div className="fixed inset-0 z-[200] flex flex-col items-center justify-center bg-bg transition-opacity duration-400" style={{ opacity: leaving ? 0 : 1 }}>
      <div className="rise serif text-4xl font-bold tracking-[0.2em] text-primary">
        HI <span className="text-gold">VEHICLE</span>
      </div>
      <svg width="220" height="6" className="mt-3">
        <line x1="0" y1="3" x2="220" y2="3" stroke="var(--accent)" strokeWidth="1.5" className="draw" style={{ ["--len" as string]: 220 }} />
      </svg>
      <svg width="86" height="46" viewBox="0 0 86 46" fill="none" stroke="var(--primary)" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" className="mt-6" style={{ animation: "busSlide 1s 0.5s cubic-bezier(.2,.8,.3,1) both" }}>
        <rect x="6" y="6" width="68" height="28" rx="7" />
        <path d="M6 22h68M22 6v16M38 6v16M54 6v16" />
        <path d="M74 14h6l3 8v12h-9" />
        <circle cx="22" cy="36" r="5" fill="var(--bg)" />
        <circle cx="58" cy="36" r="5" fill="var(--bg)" />
      </svg>
    </div>
  );
}
