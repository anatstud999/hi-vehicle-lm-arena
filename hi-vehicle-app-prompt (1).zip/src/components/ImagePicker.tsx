"use client";
import { useRef, useState } from "react";
import { cn } from "@/lib/format";
import { Icon, IconButton } from "./ui";
import { useViewer } from "./ImageViewer";

export type ImgItem = { key: string; id?: number; title: string; thumb: string; data?: string; isCover?: boolean };
type Meta = { id: number; title: string | null; thumb: string; isCover: boolean };

export const toItems = (list: Meta[] | undefined): ImgItem[] =>
  (list ?? []).map((i) => ({ key: `e${i.id}`, id: i.id, title: i.title ?? "", thumb: i.thumb, isCover: i.isCover }));

export const toPayload = (items: ImgItem[]) => {
  const hasCover = items.some((i) => i.isCover);
  return items.map((i, idx) => ({
    id: i.id,
    title: i.title,
    isCover: hasCover ? !!i.isCover : idx === 0,
    ...(i.id ? {} : { thumb: i.thumb, data: i.data }),
  }));
};

function loadImage(file: File): Promise<HTMLImageElement> {
  return new Promise((res, rej) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      URL.revokeObjectURL(url);
      res(img);
    };
    img.onerror = () => rej(new Error("Could not read that image"));
    img.src = url;
  });
}
function scaled(img: HTMLImageElement, max: number, quality: number): string {
  const r = Math.min(1, max / Math.max(img.width, img.height));
  const c = document.createElement("canvas");
  c.width = Math.round(img.width * r);
  c.height = Math.round(img.height * r);
  c.getContext("2d")!.drawImage(img, 0, 0, c.width, c.height);
  return c.toDataURL("image/jpeg", quality);
}

/** Compresses to a 1600px original and a 240px thumbnail, generated locally and instantly. */
async function processFile(file: File): Promise<ImgItem> {
  const img = await loadImage(file);
  return {
    key: `n${Date.now()}${Math.random().toString(36).slice(2, 7)}`,
    title: "",
    thumb: scaled(img, 240, 0.7),
    data: scaled(img, 1600, 0.82),
  };
}

export function ImagePicker({
  value,
  onChange,
  label = "Images",
  cover = false,
}: {
  value: ImgItem[];
  onChange: (v: ImgItem[]) => void;
  label?: string;
  cover?: boolean;
}) {
  const gallery = useRef<HTMLInputElement>(null);
  const camera = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const viewer = useViewer();

  async function addFiles(files: FileList | null) {
    if (!files?.length) return;
    setBusy(true);
    setErr(null);
    try {
      const items = await Promise.all([...files].map(processFile));
      onChange([...value, ...items]);
    } catch (e) {
      setErr((e as Error).message);
    }
    setBusy(false);
  }
  const update = (key: string, patch: Partial<ImgItem>) => onChange(value.map((i) => (i.key === key ? { ...i, ...patch } : i)));
  const move = (idx: number, d: number) => {
    const next = [...value];
    const j = idx + d;
    if (j < 0 || j >= next.length) return;
    [next[idx], next[j]] = [next[j], next[idx]];
    onChange(next);
  };
  const coverKey = value.find((i) => i.isCover)?.key ?? value[0]?.key;

  return (
    <div>
      <div className="mb-2 flex items-center justify-between">
        <span className="text-[13px] font-semibold text-muted">{label}</span>
        <span className="text-xs text-muted">{value.length} added</span>
      </div>
      <div className="space-y-3">
        {value.map((it, idx) => (
          <div key={it.key} className="rise flex items-center gap-3 rounded-2xl border border-line bg-bg/60 p-2.5" style={{ ["--i" as string]: 0 }}>
            <button
              type="button"
              aria-label={`Open ${it.title || "image"}`}
              onClick={() => viewer.open(value.map((v) => ({ id: v.id, data: v.data, thumb: v.thumb, title: v.title })), idx)}
              className="relative h-16 w-16 shrink-0 overflow-hidden rounded-xl"
            >
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={it.thumb} alt={it.title} className="h-full w-full object-cover" />
              {cover && it.key === coverKey && <span className="absolute left-1 top-1 rounded-full bg-gold px-1.5 text-[9px] font-bold text-white">COVER</span>}
            </button>
            <input className="input !min-h-11 flex-1" placeholder="Title (e.g. Front view)" value={it.title} onChange={(e) => update(it.key, { title: e.target.value })} aria-label="Image title" />
            <div className="flex shrink-0 flex-col items-center">
              <div className="flex">
                {cover && (
                  <IconButton
                    icon="star"
                    label="Set as cover"
                    size={18}
                    className={cn("!h-10 !w-10", it.key === coverKey && "text-gold")}
                    onClick={() => onChange(value.map((v) => ({ ...v, isCover: v.key === it.key })))}
                  />
                )}
                <IconButton icon="trash" label="Remove image" size={18} className="!h-10 !w-10" onClick={() => onChange(value.filter((v) => v.key !== it.key))} />
              </div>
              <div className="flex">
                <IconButton icon="up" label="Move up" size={16} className="!h-8 !w-8" onClick={() => move(idx, -1)} />
                <IconButton icon="down" label="Move down" size={16} className="!h-8 !w-8" onClick={() => move(idx, 1)} />
              </div>
            </div>
          </div>
        ))}
      </div>
      <div className="mt-3 flex gap-2">
        <button type="button" className="btn btn-soft flex-1 !px-3" onClick={() => camera.current?.click()} disabled={busy}>
          <Icon name="camera" size={18} /> Camera
        </button>
        <button type="button" className="btn btn-soft flex-1 !px-3" onClick={() => gallery.current?.click()} disabled={busy}>
          <Icon name="image" size={18} /> {busy ? "Adding…" : "Gallery"}
        </button>
        <button type="button" aria-label="Add image row" className="btn btn-primary !px-4" onClick={() => gallery.current?.click()} disabled={busy}>
          <Icon name="plus" size={20} />
        </button>
      </div>
      {err && <p className="mt-1 text-[13px] text-err">{err}</p>}
      <input ref={gallery} type="file" accept="image/*" multiple hidden onChange={(e) => { void addFiles(e.target.files); e.target.value = ""; }} />
      <input ref={camera} type="file" accept="image/*" capture="environment" hidden onChange={(e) => { void addFiles(e.target.files); e.target.value = ""; }} />
    </div>
  );
}

export function Thumb({ src, size = 64, round, alt = "", className }: { src?: string | null; size?: number; round?: boolean; alt?: string; className?: string }) {
  return src ? (
    // eslint-disable-next-line @next/next/no-img-element
    <img src={src} alt={alt} width={size} height={size} loading="lazy" className={cn("shrink-0 object-cover", round ? "rounded-full" : "rounded-2xl", className)} style={{ width: size, height: size }} />
  ) : (
    <div className={cn("flex shrink-0 items-center justify-center bg-pc text-primary/60", round ? "rounded-full" : "rounded-2xl", className)} style={{ width: size, height: size }}>
      <Icon name="image" size={Math.round(size / 2.6)} />
    </div>
  );
}
