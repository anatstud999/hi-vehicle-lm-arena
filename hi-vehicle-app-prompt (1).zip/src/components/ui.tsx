"use client";
import { createContext, ReactNode, useCallback, useContext, useEffect, useRef, useState } from "react";
import { cn, inr, num } from "@/lib/format";

/* ───────── thin-stroke rounded icon set ───────── */
const PATHS: Record<string, string> = {
  home: "M3 11l9-7 9 7M5 10v10h5v-6h4v6h5V10",
  bus: "M5 17h14V6a2 2 0 00-2-2H7a2 2 0 00-2 2v11zM5 11h14M8 17v2M16 17v2M8.5 14h.01M15.5 14h.01",
  users: "M16 20v-1a4 4 0 00-4-4H8a4 4 0 00-4 4v1M10 11a3.5 3.5 0 100-7 3.5 3.5 0 000 7zM20 20v-1a3.5 3.5 0 00-2.5-3.3M15.5 4.3a3.5 3.5 0 010 6.4",
  chart: "M4 20V10M10 20V4M16 20v-7M22 20H2",
  settings: "M12 15a3 3 0 100-6 3 3 0 000 6zM19 12a7 7 0 00-.1-1.2l2-1.5-2-3.4-2.3.9a7 7 0 00-2-1.2L14.2 3h-4l-.4 2.6a7 7 0 00-2 1.2l-2.3-.9-2 3.4 2 1.5a7 7 0 000 2.4l-2 1.5 2 3.4 2.3-.9a7 7 0 002 1.2l.4 2.6h4l.4-2.6a7 7 0 002-1.2l2.3.9 2-3.4-2-1.5c.1-.4.1-.8.1-1.2z",
  plus: "M12 5v14M5 12h14",
  search: "M11 18a7 7 0 100-14 7 7 0 000 14zM21 21l-4.3-4.3",
  close: "M6 6l12 12M18 6L6 18",
  camera: "M4 8h3l2-3h6l2 3h3v11H4V8zM12 17a3.5 3.5 0 100-7 3.5 3.5 0 000 7z",
  image: "M4 5h16v14H4V5zM4 16l5-5 4 4 3-3 4 4M9 9.5h.01",
  trash: "M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3",
  chevR: "M9 5l7 7-7 7",
  chevL: "M15 5l-7 7 7 7",
  chevD: "M5 9l7 7 7-7",
  check: "M5 12.5l4.5 4.5L19 7.5",
  filter: "M4 5h16l-6 8v6l-4-2v-4L4 5z",
  sort: "M7 4v16M7 20l-3-3M7 20l3-3M17 20V4M17 4l-3 3M17 4l3 3",
  gauge: "M4 17a8 8 0 1116 0M12 17l4-6M12 9V7M6.5 11l-1.3-.8M17.5 11l1.3-.8",
  fuel: "M5 20V5a1 1 0 011-1h7a1 1 0 011 1v15M4 20h11M14 9h2a2 2 0 012 2v5a1.5 1.5 0 003 0V8l-3-3M7 8h5",
  alert: "M12 4l9 16H3L12 4zM12 10v4M12 17h.01",
  tire: "M12 21a9 9 0 100-18 9 9 0 000 18zM12 15a3 3 0 100-6 3 3 0 000 6zM12 3v3M12 18v3M3 12h3M18 12h3",
  wrench: "M14.5 6.5a4 4 0 005 5L20 12l-8 8a2.1 2.1 0 01-3-3l8-8-.5-.5zM14.5 6.5l3-3 2 2-3 3",
  file: "M7 3h7l5 5v13H7V3zM14 3v5h5M10 13h6M10 17h6",
  table: "M4 5h16v14H4V5zM4 10h16M4 15h16M10 5v14",
  lock: "M6 11h12v9H6v-9zM8.5 11V8a3.5 3.5 0 017 0v3M12 15v2",
  unlock: "M6 11h12v9H6v-9zM8.5 11V8a3.5 3.5 0 016.7-1.4M12 15v2",
  up: "M12 19V5M6 11l6-6 6 6",
  down: "M12 5v14M6 13l6 6 6-6",
  pin: "M12 21s7-6 7-11a7 7 0 10-14 0c0 5 7 11 7 11zM12 12a2.5 2.5 0 100-5 2.5 2.5 0 000 5z",
  edit: "M4 20h4L19 9l-4-4L4 16v4zM13 7l4 4",
  copy: "M8 8h11v12H8V8zM5 16V4h11",
  download: "M12 4v11M7 11l5 5 5-5M5 20h14",
  upload: "M12 16V5M7 9l5-5 5 5M5 20h14",
  share: "M12 4v12M7 8l5-5 5 5M5 14v6h14v-6",
  star: "M12 3.5l2.6 5.4 5.9.8-4.3 4.1 1 5.9L12 16.9l-5.2 2.8 1-5.9-4.3-4.1 5.9-.8L12 3.5z",
  calendar: "M4 6h16v14H4V6zM4 10h16M8 3v4M16 3v4",
  phone: "M5 4h4l2 5-2.5 1.5a11 11 0 005 5L15 13l5 2v4a1 1 0 01-1 1A16 16 0 014 5a1 1 0 011-1z",
  sun: "M12 16a4 4 0 100-8 4 4 0 000 8zM12 2v2M12 20v2M4 12H2M22 12h-2M5 5l1.5 1.5M17.5 17.5L19 19M5 19l1.5-1.5M17.5 6.5L19 5",
  moon: "M20 14.5A8 8 0 019.5 4 8 8 0 1020 14.5z",
  grip: "M9 6h.01M9 12h.01M9 18h.01M15 6h.01M15 12h.01M15 18h.01",
  coin: "M12 21a9 9 0 100-18 9 9 0 000 18zM9.5 9.5h4a1.5 1.5 0 010 3h-3a1.5 1.5 0 000 3h4M12 7.5v1.5M12 15.5V17",
  cloud: "M7 18a4 4 0 01-.5-8 5.5 5.5 0 0110.7-1A4.5 4.5 0 0117 18H7z",
  wifiOff: "M3 3l18 18M8.5 16a5 5 0 017 0M5 12.5a10 10 0 014-2.3M12 20h.01",
  clock: "M12 21a9 9 0 100-18 9 9 0 000 18zM12 7v5l3 2",
  print: "M7 9V3h10v6M7 17H4v-7h16v7h-3M7 14h10v7H7v-7z",
  dots: "M12 6h.01M12 12h.01M12 18h.01",
  arrowR: "M5 12h14M13 6l6 6-6 6",
};

export function Icon({ name, size = 22, className }: { name: string; size?: number; className?: string }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.6}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden="true"
    >
      <path d={PATHS[name] ?? PATHS.dots} />
    </svg>
  );
}

export function IconButton({
  icon,
  label,
  onClick,
  className,
  size = 22,
}: {
  icon: string;
  label: string;
  onClick?: () => void;
  className?: string;
  size?: number;
}) {
  return (
    <button
      type="button"
      aria-label={label}
      title={label}
      onClick={onClick}
      className={cn("inline-flex h-12 w-12 items-center justify-center rounded-full text-muted transition hover:bg-pc hover:text-primary active:scale-95", className)}
    >
      <Icon name={icon} size={size} />
    </button>
  );
}

/* ───────── basic building blocks ───────── */
export function Card({ children, className, style, onClick }: { children: ReactNode; className?: string; style?: React.CSSProperties; onClick?: () => void }) {
  return (
    <div className={cn("card", className)} style={style} onClick={onClick}>
      {children}
    </div>
  );
}

export function PageTitle({ title, sub, right }: { title: string; sub?: string; right?: ReactNode }) {
  return (
    <div className="mb-5 flex items-end justify-between gap-3">
      <div>
        <h1 className="text-[34px] font-semibold leading-none text-ink">{title}</h1>
        <div className="gold-rule mt-3" />
        {sub && <p className="mt-2 text-sm text-muted">{sub}</p>}
      </div>
      {right}
    </div>
  );
}

export function Chip({ children, tone = "sage" }: { children: ReactNode; tone?: "sage" | "clay" | "gold" | "err" | "ok" | "info" | "warn" }) {
  const tones: Record<string, string> = {
    sage: "bg-pc text-primary",
    clay: "bg-[color-mix(in_srgb,var(--secondary)_20%,transparent)] text-clay",
    gold: "bg-[color-mix(in_srgb,var(--accent)_22%,transparent)] text-gold",
    err: "bg-[color-mix(in_srgb,var(--err)_16%,transparent)] text-err",
    ok: "bg-[color-mix(in_srgb,var(--ok)_18%,transparent)] text-ok",
    info: "bg-[color-mix(in_srgb,var(--info)_18%,transparent)] text-info",
    warn: "bg-[color-mix(in_srgb,var(--warn)_22%,transparent)] text-warn",
  };
  return <span className={cn("chip", tones[tone])}>{children}</span>;
}

export function Segmented<T extends string>({
  value,
  onChange,
  options,
  className,
}: {
  value: T;
  onChange: (v: T) => void;
  options: { value: T; label: string }[];
  className?: string;
}) {
  const idx = Math.max(0, options.findIndex((o) => o.value === value));
  return (
    <div className={cn("relative grid rounded-full border border-line bg-bg p-1", className)} style={{ gridTemplateColumns: `repeat(${options.length}, 1fr)` }} role="tablist">
      <span
        className="absolute bottom-1 top-1 rounded-full bg-primary shadow transition-all duration-300"
        style={{ width: `calc((100% - 8px) / ${options.length})`, left: `calc(4px + ${idx} * (100% - 8px) / ${options.length})`, transitionTimingFunction: "cubic-bezier(.3,1.3,.5,1)" }}
      />
      {options.map((o) => (
        <button
          type="button"
          key={o.value}
          role="tab"
          aria-selected={o.value === value}
          onClick={() => onChange(o.value)}
          className={cn("relative z-10 min-h-10 rounded-full px-2 text-[13px] font-semibold transition-colors", o.value === value ? "text-onp" : "text-muted")}
        >
          {o.label}
        </button>
      ))}
    </div>
  );
}

export function Switch({ checked, onChange, label }: { checked: boolean; onChange: (v: boolean) => void; label: string }) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      aria-label={label}
      onClick={() => onChange(!checked)}
      className={cn("relative h-8 w-14 shrink-0 rounded-full transition-colors duration-300", checked ? "bg-primary" : "bg-line")}
    >
      <span className="absolute top-1 h-6 w-6 rounded-full bg-surface shadow transition-all duration-300" style={{ left: checked ? 28 : 4, transitionTimingFunction: "cubic-bezier(.3,1.4,.5,1)" }} />
    </button>
  );
}

export function EmptyState({ text, action }: { text: string; action?: ReactNode }) {
  return (
    <div className="rise flex flex-col items-center px-6 py-14 text-center">
      <svg width="132" height="104" viewBox="0 0 132 104" fill="none" strokeLinecap="round" strokeLinejoin="round">
        <path d="M14 82h104" stroke="var(--accent)" strokeWidth="1.5" />
        <rect x="20" y="30" width="92" height="46" rx="10" stroke="var(--primary)" strokeWidth="1.6" />
        <path d="M20 52h92M40 30v22M64 30v22M88 30v22" stroke="var(--primary)" strokeWidth="1.2" opacity=".6" />
        <circle cx="42" cy="82" r="7" stroke="var(--primary)" strokeWidth="1.6" fill="var(--surface)" />
        <circle cx="90" cy="82" r="7" stroke="var(--primary)" strokeWidth="1.6" fill="var(--surface)" />
        <path d="M100 18l2 5 5 2-5 2-2 5-2-5-5-2 5-2z" stroke="var(--accent)" strokeWidth="1.3" />
      </svg>
      <p className="serif mt-4 max-w-xs text-xl text-ink">{text}</p>
      {action && <div className="mt-5">{action}</div>}
    </div>
  );
}

export function Skeleton({ rows = 4 }: { rows?: number }) {
  return (
    <div className="space-y-3" aria-busy="true">
      {Array.from({ length: rows }).map((_, i) => (
        <div key={i} className="shimmer h-24" />
      ))}
    </div>
  );
}

export function ErrorBox({ message, retry }: { message: string; retry?: () => void }) {
  return (
    <div className="card p-6 text-center">
      <p className="text-err">{message}</p>
      {retry && (
        <button className="btn btn-soft mt-4" onClick={retry}>
          Try again
        </button>
      )}
    </div>
  );
}

/* ───────── count-up number ───────── */
export function CountUp({ value, format = (n: number) => num(n), duration = 800 }: { value: number; format?: (n: number) => string; duration?: number }) {
  const [shown, setShown] = useState(0);
  const from = useRef(0);
  useEffect(() => {
    const start = from.current;
    const t0 = performance.now();
    let raf = 0;
    const tick = (t: number) => {
      const p = Math.min(1, (t - t0) / duration);
      const e = 1 - Math.pow(1 - p, 3);
      setShown(start + (value - start) * e);
      if (p < 1) raf = requestAnimationFrame(tick);
      else from.current = value;
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [value, duration]);
  return <span className="tabular">{format(shown)}</span>;
}

export function StatCard({
  label,
  value,
  format,
  icon,
  index = 0,
  hint,
  gold,
}: {
  label: string;
  value: number;
  format?: (n: number) => string;
  icon?: string;
  index?: number;
  hint?: string;
  gold?: boolean;
}) {
  return (
    <Card className="rise p-4" style={{ ["--i" as string]: index }}>
      <div className="flex items-center justify-between text-muted">
        <span className="text-xs font-medium uppercase tracking-wider">{label}</span>
        {icon && <Icon name={icon} size={18} />}
      </div>
      <div className={cn("serif mt-2 text-[30px] font-semibold leading-none", gold ? "text-gold" : "text-ink")}>
        <CountUp value={value} format={format} />
      </div>
      {hint && <div className="mt-1 text-xs text-muted">{hint}</div>}
    </Card>
  );
}

/* ───────── bottom sheet & dialogs ───────── */
export function BottomSheet({ open, onClose, title, children }: { open: boolean; onClose: () => void; title?: string; children: ReactNode }) {
  useEffect(() => {
    if (!open) return;
    const h = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-[70] flex items-end justify-center sm:items-center" role="dialog" aria-modal="true">
      <div className="fade absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="sheet-up relative z-10 flex max-h-[88vh] w-full max-w-xl flex-col rounded-t-[28px] bg-surface p-5 shadow-2xl sm:rounded-[28px]">
        <div className="mx-auto mb-3 h-1 w-10 rounded-full bg-line sm:hidden" />
        {title && (
          <div className="mb-3 flex items-center justify-between">
            <h2 className="text-2xl font-semibold">{title}</h2>
            <IconButton icon="close" label="Close" onClick={onClose} />
          </div>
        )}
        <div className="min-h-0 flex-1 overflow-y-auto">{children}</div>
      </div>
    </div>
  );
}

export function ConfirmDialog({
  open,
  title,
  message,
  confirmLabel = "Delete",
  onConfirm,
  onCancel,
}: {
  open: boolean;
  title: string;
  message: string;
  confirmLabel?: string;
  onConfirm: () => void;
  onCancel: () => void;
}) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-[80] flex items-center justify-center p-5" role="alertdialog" aria-modal="true">
      <div className="fade absolute inset-0 bg-black/45" onClick={onCancel} />
      <div className="pop card relative z-10 w-full max-w-sm p-6">
        <h2 className="text-2xl font-semibold">{title}</h2>
        <p className="mt-2 text-sm text-muted">{message}</p>
        <div className="mt-6 flex justify-end gap-3">
          <button className="btn btn-ghost" onClick={onCancel}>
            Cancel
          </button>
          <button className="btn btn-danger" onClick={onConfirm}>
            {confirmLabel}
          </button>
        </div>
      </div>
    </div>
  );
}

/* ───────── toasts with undo ───────── */
type ToastCtx = {
  show: (msg: string, tone?: "ok" | "err") => void;
  undoable: (msg: string, commit: () => void | Promise<void>, onUndo?: () => void) => void;
};
const ToastContext = createContext<ToastCtx>({ show: () => {}, undoable: () => {} });
export const useToast = () => useContext(ToastContext);

export function ToastProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<{ id: number; msg: string; tone: string; undo?: () => void }[]>([]);
  const seq = useRef(0);
  const remove = useCallback((id: number) => setItems((s) => s.filter((x) => x.id !== id)), []);
  const show = useCallback<ToastCtx["show"]>(
    (msg, tone = "ok") => {
      const id = ++seq.current;
      setItems((s) => [...s, { id, msg, tone }]);
      setTimeout(() => remove(id), 3200);
    },
    [remove],
  );
  const undoable = useCallback<ToastCtx["undoable"]>(
    (msg, commit, onUndo) => {
      const id = ++seq.current;
      let done = false;
      const timer = setTimeout(() => {
        if (!done) {
          done = true;
          void commit();
        }
        remove(id);
      }, 5000);
      const undo = () => {
        if (done) return;
        done = true;
        clearTimeout(timer);
        onUndo?.();
        remove(id);
      };
      setItems((s) => [...s, { id, msg, tone: "ok", undo }]);
    },
    [remove],
  );
  return (
    <ToastContext.Provider value={{ show, undoable }}>
      {children}
      <div className="pointer-events-none fixed inset-x-0 bottom-24 z-[90] flex flex-col items-center gap-2 px-4" aria-live="polite">
        {items.map((t) => (
          <div key={t.id} className={cn("pop pointer-events-auto flex items-center gap-4 rounded-2xl px-5 py-3 text-sm shadow-xl", t.tone === "err" ? "bg-err text-white" : "bg-ink text-bg")}>
            <span>{t.msg}</span>
            {t.undo && (
              <button onClick={t.undo} className="font-bold uppercase tracking-wide text-gold">
                Undo
              </button>
            )}
          </div>
        ))}
      </div>
    </ToastContext.Provider>
  );
}

export function SuccessCheck({ show }: { show: boolean }) {
  if (!show) return null;
  return (
    <div className="fade fixed inset-0 z-[95] flex items-center justify-center bg-black/30">
      <div className="pop card flex h-36 w-36 flex-col items-center justify-center gap-2">
        <svg width="64" height="64" viewBox="0 0 64 64" fill="none">
          <circle cx="32" cy="32" r="28" stroke="var(--accent)" strokeWidth="2" style={{ ["--len" as string]: 176 }} className="draw" />
          <path d="M20 33l8 8 17-18" stroke="var(--primary)" strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round" style={{ ["--len" as string]: 50 }} className="draw" />
        </svg>
        <span className="serif text-lg">Saved</span>
      </div>
    </div>
  );
}

export { inr };
