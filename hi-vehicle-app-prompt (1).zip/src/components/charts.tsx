"use client";
import { inr, num } from "@/lib/format";

/** Animated SVG line chart */
export function LineChart({ points, unit = "km/L", height = 150 }: { points: { label: string; value: number }[]; unit?: string; height?: number }) {
  if (!points.length) return <p className="py-6 text-center text-sm text-muted">Not enough data for a chart yet.</p>;
  const w = 320;
  const pad = 26;
  const vals = points.map((p) => p.value);
  const min = Math.min(...vals) * 0.9;
  const max = Math.max(...vals) * 1.05 || 1;
  const x = (i: number) => pad + (points.length === 1 ? (w - pad * 2) / 2 : (i * (w - pad * 2)) / (points.length - 1));
  const y = (v: number) => height - pad - ((v - min) / (max - min || 1)) * (height - pad * 2);
  const d = points.map((p, i) => `${i ? "L" : "M"}${x(i).toFixed(1)} ${y(p.value).toFixed(1)}`).join(" ");
  const len = Math.max(400, points.length * 120);
  return (
    <svg viewBox={`0 0 ${w} ${height}`} className="w-full" role="img" aria-label={`Line chart of ${unit}`}>
      {[0, 0.5, 1].map((t) => (
        <g key={t}>
          <line x1={pad} x2={w - pad} y1={pad + t * (height - pad * 2)} y2={pad + t * (height - pad * 2)} stroke="var(--line)" />
          <text x={4} y={pad + t * (height - pad * 2) + 4} fontSize="9" fill="var(--muted)">
            {(max - t * (max - min)).toFixed(1)}
          </text>
        </g>
      ))}
      <path d={d} fill="none" stroke="var(--primary)" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" className="draw" style={{ ["--len" as string]: len }} />
      {points.map((p, i) => (
        <circle key={i} cx={x(i)} cy={y(p.value)} r="3.4" fill="var(--surface)" stroke="var(--accent)" strokeWidth="1.8">
          <title>{`${p.label}: ${p.value.toFixed(2)} ${unit}`}</title>
        </circle>
      ))}
      {points.length > 1 && (
        <>
          <text x={pad} y={height - 6} fontSize="9" fill="var(--muted)">{points[0].label}</text>
          <text x={w - pad} y={height - 6} fontSize="9" fill="var(--muted)" textAnchor="end">{points[points.length - 1].label}</text>
        </>
      )}
    </svg>
  );
}

export const SPLIT_COLORS = ["var(--primary)", "var(--secondary)", "var(--accent)", "var(--err)"];

/** Donut with animated segments */
export function Donut({ parts, size = 150 }: { parts: { label: string; value: number }[]; size?: number }) {
  const total = parts.reduce((s, p) => s + p.value, 0);
  const r = 52;
  const c = 2 * Math.PI * r;
  let offset = 0;
  return (
    <div className="flex items-center gap-5">
      <svg width={size} height={size} viewBox="0 0 140 140" role="img" aria-label="Cost split donut">
        <circle cx="70" cy="70" r={r} fill="none" stroke="var(--line)" strokeWidth="16" />
        {total > 0 &&
          parts.map((p, i) => {
            const len = (p.value / total) * c;
            const el = (
              <circle
                key={p.label}
                cx="70"
                cy="70"
                r={r}
                fill="none"
                stroke={SPLIT_COLORS[i % 4]}
                strokeWidth="16"
                strokeDasharray={`${len} ${c - len}`}
                strokeDashoffset={-offset}
                transform="rotate(-90 70 70)"
                className="fade"
              />
            );
            offset += len;
            return el;
          })}
        <text x="70" y="66" textAnchor="middle" fontSize="9" fill="var(--muted)">Total</text>
        <text x="70" y="82" textAnchor="middle" fontSize="13" fontWeight="700" fill="var(--ink)" fontFamily="var(--font-serif)">{inr(total)}</text>
      </svg>
      <ul className="space-y-1.5 text-sm">
        {parts.map((p, i) => (
          <li key={p.label} className="flex items-center gap-2">
            <span className="h-3 w-3 rounded-full" style={{ background: SPLIT_COLORS[i % 4] }} />
            <span className="text-muted">{p.label}</span>
            <span className="ml-auto pl-3 font-semibold">{total ? Math.round((p.value / total) * 100) : 0}%</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

/** Stacked monthly bar chart */
export function StackedBars({ data }: { data: { label: string; values: number[] }[] }) {
  const w = 320;
  const h = 170;
  const pad = 26;
  const max = Math.max(1, ...data.map((d) => d.values.reduce((s, v) => s + v, 0)));
  const bw = Math.min(40, ((w - pad * 2) / Math.max(1, data.length)) * 0.6);
  return (
    <svg viewBox={`0 0 ${w} ${h}`} className="w-full" role="img" aria-label="Monthly running cost">
      <line x1={pad} x2={w - pad} y1={h - pad} y2={h - pad} stroke="var(--line)" />
      <text x={4} y={pad + 4} fontSize="9" fill="var(--muted)">{num(max)}</text>
      {data.map((d, i) => {
        const cx = pad + ((i + 0.5) * (w - pad * 2)) / data.length;
        let acc = 0;
        return (
          <g key={d.label}>
            {d.values.map((v, j) => {
              const bh = (v / max) * (h - pad * 2);
              const yy = h - pad - acc - bh;
              acc += bh;
              return <rect key={j} x={cx - bw / 2} y={yy} width={bw} height={Math.max(0, bh)} fill={SPLIT_COLORS[j % 4]} className="grow" style={{ animationDelay: `${i * 60}ms` }} rx="2" />;
            })}
            <text x={cx} y={h - 8} fontSize="8.5" textAnchor="middle" fill="var(--muted)">{d.label}</text>
          </g>
        );
      })}
    </svg>
  );
}
