"use client";
import { ReactNode, useEffect, useMemo, useState } from "react";
import { useFetch } from "@/lib/client";
import { addDays, cn, fmtDate, fmtDateTime, inr, monthLabel, num, today } from "@/lib/format";
import type { ReportData, VehicleReport } from "@/lib/server/reports";
import { Donut, LineChart, StackedBars } from "./charts";
import { Thumb } from "./ImagePicker";
import { coverOf, VehicleLite } from "./Selectors";
import { Card, Chip, EmptyState, ErrorBox, Icon, Skeleton, Switch } from "./ui";
import { Field } from "./fields";

type Period = "week" | "month" | "last30" | "quarter" | "fy" | "custom";
const PERIODS: { v: Period; label: string }[] = [
  { v: "week", label: "This Week" },
  { v: "month", label: "This Month" },
  { v: "last30", label: "Last 30 Days" },
  { v: "quarter", label: "This Quarter" },
  { v: "fy", label: "Financial Year" },
  { v: "custom", label: "Custom" },
];

function range(p: Period, cf: string, ct: string): { from: string; to: string } {
  const t = today();
  const [y, m] = t.split("-").map(Number);
  const pad = (n: number) => String(n).padStart(2, "0");
  const lastDay = (yy: number, mm: number) => new Date(Date.UTC(yy, mm, 0)).getUTCDate();
  switch (p) {
    case "week": {
      const dow = (new Date(`${t}T00:00:00Z`).getUTCDay() + 6) % 7; // Monday = 0
      const from = addDays(t, -dow);
      return { from, to: addDays(from, 6) };
    }
    case "month":
      return { from: `${y}-${pad(m)}-01`, to: `${y}-${pad(m)}-${lastDay(y, m)}` };
    case "last30":
      return { from: addDays(t, -29), to: t };
    case "quarter": {
      const qs = Math.floor((m - 1) / 3) * 3 + 1;
      return { from: `${y}-${pad(qs)}-01`, to: `${y}-${pad(qs + 2)}-${lastDay(y, qs + 2)}` };
    }
    case "fy": {
      const fy = m >= 4 ? y : y - 1;
      return { from: `${fy}-04-01`, to: `${fy + 1}-03-31` };
    }
    default:
      return { from: cf, to: ct };
  }
}

export function ReportsView() {
  const vs = useFetch<VehicleLite[]>("/api/vehicles");
  const [sel, setSel] = useState<number[] | null>(null);
  const [period, setPeriod] = useState<Period>("month");
  const [cf, setCf] = useState(addDays(today(), -29));
  const [ct, setCt] = useState(today());
  const [images, setImages] = useState(true);

  useEffect(() => {
    if (vs.data && sel === null) setSel(vs.data.length ? [vs.data[0].id] : []);
  }, [vs.data, sel]);

  const r = range(period, cf, ct);
  const url = sel && sel.length && r.from && r.to && r.from <= r.to ? `/api/reports?vehicleIds=${sel.join(",")}&from=${r.from}&to=${r.to}` : null;
  const rep = useFetch<ReportData>(url);
  const all = vs.data ?? [];
  const toggle = (id: number) => setSel((s) => ((s ?? []).includes(id) ? (s ?? []).filter((x) => x !== id) : [...(s ?? []), id]));

  return (
    <div>
      <div className="no-print">
        <div className="mb-5">
          <h1 className="text-[34px] font-semibold leading-none">Reports</h1>
          <div className="gold-rule mt-3" />
        </div>
        <Card className="space-y-4 p-4">
          <div>
            <div className="mb-2 flex items-center justify-between">
              <span className="text-[13px] font-semibold text-muted">Vehicles</span>
              <button className="text-sm font-semibold text-primary" onClick={() => setSel(sel?.length === all.length ? [] : all.map((v) => v.id))}>
                {sel?.length === all.length && all.length ? "Clear all" : "Select all"}
              </button>
            </div>
            <div className="flex flex-wrap gap-2">
              {all.map((v) => {
                const on = sel?.includes(v.id);
                return (
                  <button key={v.id} onClick={() => toggle(v.id)} aria-pressed={on} className={cn("flex min-h-10 items-center gap-2 rounded-full border px-3.5 text-sm font-semibold transition", on ? "border-primary bg-primary text-onp" : "border-line text-muted")}>
                    {on && <Icon name="check" size={14} />}
                    {v.name}
                  </button>
                );
              })}
              {!all.length && !vs.loading && <span className="text-sm text-muted">Add a vehicle to see reports.</span>}
            </div>
          </div>
          <div>
            <span className="mb-2 block text-[13px] font-semibold text-muted">Period</span>
            <div className="flex flex-wrap gap-2">
              {PERIODS.map((p) => (
                <button key={p.v} onClick={() => setPeriod(p.v)} aria-pressed={period === p.v} className={cn("min-h-10 rounded-full border px-3.5 text-sm font-semibold transition", period === p.v ? "border-gold bg-pc text-primary" : "border-line text-muted")}>
                  {p.label}
                </button>
              ))}
            </div>
            {period === "custom" && (
              <div className="mt-3 grid grid-cols-2 gap-3">
                <Field label="From"><input type="date" className="input" value={cf} onChange={(e) => setCf(e.target.value)} /></Field>
                <Field label="To"><input type="date" className="input" value={ct} onChange={(e) => setCt(e.target.value)} /></Field>
              </div>
            )}
            <p className="mt-2 text-xs text-muted">{fmtDate(r.from)} – {fmtDate(r.to)}</p>
          </div>
          <div className="flex items-center justify-between gap-3 border-t border-line pt-3">
            <div className="flex items-center gap-3">
              <Switch checked={images} onChange={setImages} label="Include images" />
              <span className="text-sm">Include images</span>
            </div>
            <button className="btn btn-primary" disabled={!rep.data} onClick={() => window.print()}>
              <Icon name="file" size={18} /> Export PDF
            </button>
          </div>
        </Card>
      </div>

      <div className="mt-5">
        {rep.loading && <Skeleton rows={3} />}
        {rep.error && <ErrorBox message={rep.error} retry={rep.reload} />}
        {!sel?.length && vs.data && <EmptyState text="Choose at least one vehicle to see its story." />}
        {rep.data && !rep.loading && <ReportBody data={rep.data} images={images} />}
      </div>
    </div>
  );
}

/* ───────── report body (also what gets printed to PDF) ───────── */
function ReportBody({ data, images }: { data: ReportData; images: boolean }) {
  const multi = data.vehicles.length > 1;
  const fleet = useMemo(() => {
    const v = data.vehicles;
    const sum = (f: (x: VehicleReport) => number) => v.reduce((s, x) => s + f(x), 0);
    return { km: sum((x) => x.distance.totalKm), litres: sum((x) => x.fuel.litres), fuel: sum((x) => x.cost.fuel), repairs: sum((x) => x.cost.repairs + x.cost.parts), damages: sum((x) => x.cost.damages), total: sum((x) => x.cost.total) };
  }, [data]);

  return (
    <div className="space-y-6">
      {/* branded cover page — print only */}
      <section className="print-only print-page" style={{ minHeight: "240mm" }}>
        <div className="flex h-[240mm] flex-col items-center justify-center text-center">
          <div className="serif text-6xl font-bold tracking-[0.2em] text-primary">HI <span className="text-gold">VEHICLE</span></div>
          <div className="gold-rule my-6 !w-40" />
          <div className="serif text-3xl">Fleet Report</div>
          <div className="mt-3 text-lg text-muted">{fmtDate(data.from)} – {fmtDate(data.to)}</div>
          <div className="mt-1 text-sm text-muted">Generated {fmtDateTime(data.generatedAt)}</div>
          <div className="mt-8 text-sm text-muted">{data.vehicles.map((v) => v.vehicle.name).join(" · ")}</div>
        </div>
      </section>

      {(multi || true) && (
        <Card className="print-page print-break p-5">
          <h2 className="text-2xl font-semibold">Fleet summary</h2>
          <div className="gold-rule mt-1.5" />
          <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-3">
            <Tile label="Vehicles" value={String(data.vehicles.length)} />
            <Tile label="Total km" value={num(fleet.km, 0)} />
            <Tile label="Fuel" value={`${num(fleet.litres, 1)} L`} />
            <Tile label="Fuel cost" value={inr(fleet.fuel)} />
            <Tile label="Repairs & parts" value={inr(fleet.repairs)} />
            <Tile label="Damages" value={inr(fleet.damages)} />
          </div>
          <div className="serif mt-4 flex items-baseline justify-between rounded-2xl bg-pc/70 px-4 py-3">
            <span className="text-lg">Fleet running cost</span>
            <span className="text-3xl font-semibold text-gold">{inr(fleet.total)}</span>
          </div>
          {multi && (
            <div className="mt-5 overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-pc text-left text-primary">
                  <tr>
                    {["Vehicle", "Km", "Litres", "km/L", "Fuel ₹", "Repairs+Parts", "Damages", "Total", "Entries"].map((h) => (
                      <th key={h} className="whitespace-nowrap px-3 py-2 font-semibold">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {data.vehicles.map((v, i) => (
                    <tr key={v.vehicle.id} className={i % 2 ? "bg-surface" : "bg-bg/60"}>
                      <td className="whitespace-nowrap px-3 py-2 font-medium">{v.vehicle.name}</td>
                      <td className="px-3 py-2">{num(v.distance.totalKm, 0)}</td>
                      <td className="px-3 py-2">{num(v.fuel.litres, 1)}</td>
                      <td className="px-3 py-2">{v.fuel.avgMileage?.toFixed(2) ?? "—"}</td>
                      <td className="px-3 py-2">{inr(v.cost.fuel)}</td>
                      <td className="px-3 py-2">{inr(v.cost.repairs + v.cost.parts)}</td>
                      <td className="px-3 py-2">{inr(v.cost.damages)}</td>
                      <td className="px-3 py-2 font-semibold">{inr(v.cost.total)}</td>
                      <td className="px-3 py-2">{v.distance.compliance.toFixed(0)}%</td>
                    </tr>
                  ))}
                  <tr className="bg-pc/70 font-semibold">
                    <td className="px-3 py-2">Fleet total</td>
                    <td className="px-3 py-2">{num(fleet.km, 0)}</td>
                    <td className="px-3 py-2">{num(fleet.litres, 1)}</td>
                    <td className="px-3 py-2">—</td>
                    <td className="px-3 py-2">{inr(fleet.fuel)}</td>
                    <td className="px-3 py-2">{inr(fleet.repairs)}</td>
                    <td className="px-3 py-2">{inr(fleet.damages)}</td>
                    <td className="px-3 py-2">{inr(fleet.total)}</td>
                    <td className="px-3 py-2">—</td>
                  </tr>
                </tbody>
              </table>
            </div>
          )}
        </Card>
      )}

      {data.vehicles.map((v, i) => (
        <VehicleSection key={v.vehicle.id} v={v} images={images} index={i} />
      ))}
      <div className="print-only mt-6 border-t border-line pt-2 text-center text-xs text-muted">HI VEHICLE · Fleet report · {fmtDate(data.from)} – {fmtDate(data.to)}</div>
    </div>
  );
}

function Tile({ label, value, tone, sub }: { label: string; value: ReactNode; tone?: "ok" | "err"; sub?: ReactNode }) {
  return (
    <div className="rounded-2xl bg-pc/60 p-3">
      <div className="text-[10.5px] font-semibold uppercase tracking-wider text-muted">{label}</div>
      <div className={cn("serif mt-0.5 text-[22px] font-semibold leading-tight", tone === "ok" && "text-ok", tone === "err" && "text-err")}>{value}</div>
      {sub && <div className="text-xs text-muted">{sub}</div>}
    </div>
  );
}
function Block({ title, children, icon }: { title: string; children: ReactNode; icon: string }) {
  return (
    <div className="print-page">
      <h3 className="mb-2 flex items-center gap-2 text-xl font-semibold">
        <Icon name={icon} size={18} className="text-gold" /> {title}
      </h3>
      {children}
    </div>
  );
}

function VehicleSection({ v, images, index }: { v: VehicleReport; images: boolean; index: number }) {
  const f = v.fuel;
  const d = v.distance;
  const parts = [
    { label: "Fuel", value: v.cost.fuel },
    { label: "Repairs", value: v.cost.repairs },
    { label: "New parts", value: v.cost.parts },
    { label: "Damages", value: v.cost.damages },
  ];
  return (
    <Card className="rise space-y-6 p-5 print-break" style={{ ["--i" as string]: index }}>
      <div className="flex items-center gap-4">
        {images && <Thumb src={v.vehicle.cover} size={72} />}
        <div>
          <h2 className="text-3xl font-semibold leading-tight">{v.vehicle.name}</h2>
          <div className="text-sm tracking-widest text-muted">{v.vehicle.plate} · {v.vehicle.type}</div>
          <div className="gold-rule mt-2" />
        </div>
      </div>

      {v.insights.length > 0 && (
        <div className="rounded-2xl border border-gold/50 bg-[color-mix(in_srgb,var(--accent)_8%,transparent)] p-4">
          <div className="serif mb-1 text-lg font-semibold text-gold">Insights</div>
          <ul className="space-y-1 text-sm">
            {v.insights.map((t, i) => (
              <li key={i} className="flex gap-2"><span className="text-gold">✦</span>{t}</li>
            ))}
          </ul>
        </div>
      )}

      <Block title="Distance" icon="gauge">
        <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-4">
          <Tile label="Total km" value={num(d.totalKm, 0)} />
          <Tile label="Avg km / working day" value={num(d.avgPerWorkingDay, 1)} />
          <Tile label="Working days" value={d.workingDays} />
          <Tile label="Entry compliance" value={`${d.compliance.toFixed(0)}%`} tone={d.compliance >= 80 ? "ok" : "err"} />
          <Tile label="Holidays" value={d.holidays} />
          <Tile label="Non-working" value={d.nonWorking} />
          <Tile label="No information" value={d.noInfo} />
        </div>
      </Block>

      <Block title="Fuel" icon="fuel">
        <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-4">
          <Tile label="Total litres" value={num(f.litres, 1)} sub={`${f.refills} refills`} />
          <Tile label="Last 7 days" value={`${num(f.last7, 1)} L`} />
          <Tile label="Last 30 days" value={`${num(f.last30, 1)} L`} />
          <Tile label="Fuel cost" value={inr(f.cost)} />
          <Tile label="Avg mileage" value={f.avgMileage ? `${f.avgMileage.toFixed(2)}` : "—"} sub="km/L" />
          <Tile label="Best" value={f.bestMileage ? f.bestMileage.toFixed(2) : "—"} tone="ok" />
          <Tile label="Worst" value={f.worstMileage ? f.worstMileage.toFixed(2) : "—"} tone="err" />
          <Tile label="Cost per km" value={f.costPerKm ? inr(Math.round(f.costPerKm * 100) / 100) : "—"} />
        </div>
        <div className="mt-2 flex flex-wrap gap-2">
          {Object.entries(f.byType).map(([t, l]) => (
            <Chip key={t} tone={t === "Diesel" ? "sage" : "gold"}>{t}: {num(l, 1)} L</Chip>
          ))}
          {f.mileageDelta !== null && f.prevAvgMileage !== null && (
            <Chip tone={f.mileageDelta >= 0 ? "ok" : "err"}>
              <Icon name={f.mileageDelta >= 0 ? "up" : "down"} size={12} />
              {Math.abs(f.mileageDelta).toFixed(2)} km/L ({Math.abs(f.mileageDeltaPct ?? 0).toFixed(1)}%) vs previous period
            </Chip>
          )}
        </div>
        <div className="mt-3">
          <LineChart points={f.series.map((s) => ({ label: fmtDate(s.at).slice(0, 6), value: s.mileage }))} />
        </div>
      </Block>

      <Block title="Damages" icon="alert">
        <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-3">
          <Tile label="Count" value={v.damages.count} />
          <Tile label="Total" value={inr(v.damages.total)} />
          <Tile label="Most recent" value={v.damages.latest ? fmtDate(v.damages.latest.at) : "—"} sub={v.damages.latest?.description ?? undefined} />
        </div>
        {v.damages.byDriver.length > 0 && (
          <div className="mt-2 flex flex-wrap gap-2">
            {v.damages.byDriver.map((x) => (
              <Chip key={x.name} tone="clay">{x.name}: {x.count} · {inr(x.amount)}</Chip>
            ))}
          </div>
        )}
      </Block>

      <Block title="Repairs & parts" icon="wrench">
        <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-4">
          <Tile label="Repairs" value={v.repairs.repairCount} sub={inr(v.repairs.repairTotal)} />
          <Tile label="New parts" value={v.repairs.partCount} sub={inr(v.repairs.partTotal)} />
          <Tile label="Biggest expense" value={v.repairs.biggest ? inr(v.repairs.biggest.amount) : "—"} sub={v.repairs.biggest ? (v.repairs.biggest.description ?? (v.repairs.biggest.kind === "part" ? "New part" : "Repair")) : undefined} />
        </div>
      </Block>

      <Block title="Tires" icon="tire">
        <div className="grid grid-cols-2 gap-2.5">
          <Tile label="Currently fitted" value={v.tires.fitted} />
          <Tile label="Damaged" value={v.tires.damaged} tone={v.tires.damaged ? "err" : undefined} />
        </div>
        {v.tires.trail.length > 0 && (
          <ul className="mt-2 divide-y divide-line text-sm">
            {v.tires.trail.map((t) => (
              <li key={t.code} className="flex items-center justify-between py-2">
                <span className="font-semibold">{t.code}</span>
                <span className="flex items-center gap-2 text-muted">
                  fitted {fmtDate(t.fitDate)} · {t.km ? `${num(t.km, 0)} km run` : "running"}
                  {t.fitted ? <Chip tone="ok">Fitted</Chip> : <Chip>Removed</Chip>}
                  {t.damaged && <Chip tone="err">Damaged</Chip>}
                </span>
              </li>
            ))}
          </ul>
        )}
      </Block>

      <Block title="Total running cost" icon="coin">
        <div className="serif mb-3 text-4xl font-semibold text-gold">{inr(v.cost.total)}</div>
        <Donut parts={parts} />
        {v.cost.monthly.length > 0 && (
          <div className="mt-4">
            <div className="mb-1 text-sm font-semibold text-muted">Monthly cost (fuel · repairs · parts · damages)</div>
            <StackedBars data={v.cost.monthly.map((m) => ({ label: monthLabel(m.month).slice(0, 3), values: [m.fuel, m.repairs, m.parts, m.damages] }))} />
          </div>
        )}
      </Block>

      <Block title="Drivers" icon="users">
        {!v.drivers.length ? (
          <p className="text-sm text-muted">No trips recorded in this period.</p>
        ) : (
          <ul className="space-y-2">
            {v.drivers.map((x) => {
              const max = v.drivers[0].km || 1;
              return (
                <li key={x.name}>
                  <div className="mb-0.5 flex justify-between text-sm"><span className="font-medium">{x.name}</span><span className="text-muted">{num(x.km, 0)} km</span></div>
                  <div className="h-2 overflow-hidden rounded-full bg-line"><div className="h-full rounded-full bg-primary" style={{ width: `${(x.km / max) * 100}%` }} /></div>
                </li>
              );
            })}
          </ul>
        )}
      </Block>
    </Card>
  );
}
