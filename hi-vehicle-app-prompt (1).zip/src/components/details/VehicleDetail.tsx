"use client";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useFetch } from "@/lib/client";
import { fmtDateTime, inr, num } from "@/lib/format";
import { useViewer } from "../ImageViewer";
import { Chip, EmptyState, ErrorBox, Icon, IconButton, Skeleton, StatCard } from "../ui";

type V = {
  id: number;
  name: string;
  plate: string;
  type: string;
  purchaseYear: number | null;
  details: string | null;
  images: { id: number; title: string | null; thumb: string; isCover: boolean }[];
  stats: { totalKm: number; lastReading: number | null; litres: number; avgMileage: number | null; spend: number };
  timeline: { type: string; at: string; title: string; sub: string; amount: number | null }[];
};
const ICON: Record<string, string> = { odometer: "gauge", fuel: "fuel", damage: "alert", repair: "wrench", part: "wrench" };

export function VehicleDetail({ id }: { id: number }) {
  const { data: v, error, loading, reload } = useFetch<V>(`/api/vehicles/${id}`);
  const router = useRouter();
  const viewer = useViewer();
  if (loading) return <Skeleton rows={3} />;
  if (error || !v) return <ErrorBox message={error ?? "Not found"} retry={reload} />;
  const ordered = [...v.images].sort((a, b) => Number(b.isCover) - Number(a.isCover));
  const list = ordered.map((i) => ({ id: i.id, thumb: i.thumb, title: i.title }));

  return (
    <div className="pb-6">
      <div className="mb-4 flex items-center justify-between">
        <IconButton icon="chevL" label="Back" onClick={() => router.back()} className="-ml-3" />
        <Link href={`/vehicles/${id}/edit`} className="btn btn-soft !min-h-10 !px-4">
          <Icon name="edit" size={16} /> Edit
        </Link>
      </div>

      {ordered.length > 0 && (
        <div className="-mx-4 mb-5 flex snap-x snap-mandatory gap-3 overflow-x-auto px-4 pb-2">
          {ordered.map((img, i) => (
            <button key={img.id} onClick={() => viewer.open(list, i)} className="rise relative h-56 w-[85%] shrink-0 snap-center overflow-hidden rounded-[20px] sm:w-[70%]" style={{ ["--i" as string]: i }} aria-label={`Open ${img.title ?? "image"}`}>
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={i === 0 ? `/api/images/${img.id}` : img.thumb} alt={img.title ?? v.name} loading={i === 0 ? "eager" : "lazy"} className="h-full w-full object-cover" />
              {img.title && <span className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/60 to-transparent px-4 pb-3 pt-8 text-left text-sm text-white">{img.title}</span>}
            </button>
          ))}
        </div>
      )}

      <h1 className="text-4xl font-semibold leading-tight">{v.name}</h1>
      <div className="mt-1 flex flex-wrap items-center gap-2">
        <span className="tracking-widest text-muted">{v.plate}</span>
        <Chip>{v.type}</Chip>
        {v.purchaseYear && <span className="text-sm text-muted">Purchased {v.purchaseYear}</span>}
      </div>
      <div className="gold-rule mt-3" />
      {v.details && <p className="mt-3 whitespace-pre-wrap text-sm text-muted">{v.details}</p>}

      <div className="mt-5 grid grid-cols-2 gap-3">
        <StatCard index={0} label="Total km" value={v.stats.totalKm} format={(n) => num(n, 0)} icon="gauge" />
        <StatCard index={1} label="Avg mileage" value={v.stats.avgMileage ?? 0} format={(n) => (v.stats.avgMileage ? `${n.toFixed(2)} km/L` : "—")} icon="fuel" />
        <StatCard index={2} label="Fuel used" value={v.stats.litres} format={(n) => `${num(n, 1)} L`} icon="fuel" />
        <StatCard index={3} label="Total spend" value={v.stats.spend} format={(n) => inr(Math.round(n))} icon="coin" gold />
      </div>
      {v.stats.lastReading !== null && <p className="mt-2 text-sm text-muted">Last odometer reading: <b className="text-ink">{num(v.stats.lastReading, 1)} km</b></p>}

      <div className="mt-5 grid grid-cols-4 gap-2">
        {[
          ["/odometer/new", "Odometer", "gauge"],
          ["/fuel/new", "Fuel", "fuel"],
          ["/damages/new", "Damage", "alert"],
          ["/repairs/new", "Repair", "wrench"],
        ].map(([href, label, icon]) => (
          <Link key={href} href={href} className="card flex flex-col items-center gap-1 py-3 text-xs font-semibold text-primary">
            <Icon name={icon} />
            {label}
          </Link>
        ))}
      </div>

      <h2 className="mb-3 mt-8 text-2xl font-semibold">Recent activity</h2>
      {!v.timeline.length ? (
        <EmptyState text="Nothing logged for this vehicle yet." />
      ) : (
        <ol className="relative ml-4 border-l border-gold/50">
          {v.timeline.map((t, i) => (
            <li key={i} className="rise relative mb-4 pl-6" style={{ ["--i" as string]: i }}>
              <span className="absolute -left-[15px] top-0 flex h-7 w-7 items-center justify-center rounded-full border border-line bg-surface text-primary">
                <Icon name={ICON[t.type] ?? "dots"} size={14} />
              </span>
              <div className="flex items-start justify-between gap-2">
                <div>
                  <div className="font-semibold">{t.title}</div>
                  <div className="text-xs text-muted">{fmtDateTime(t.at)}</div>
                  {t.sub && <div className="text-sm text-muted">{t.sub}</div>}
                </div>
                {t.amount ? <span className="text-sm font-semibold">{inr(t.amount)}</span> : null}
              </div>
            </li>
          ))}
        </ol>
      )}
    </div>
  );
}
