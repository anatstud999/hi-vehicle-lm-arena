"use client";
import Link from "next/link";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { useFetch } from "@/lib/client";
import { fmtDate, fmtDateTime, inr, monthLabel, num } from "@/lib/format";
import { Thumb } from "../ImagePicker";
import { coverOf } from "../Selectors";
import { useViewer } from "../ImageViewer";
import { Card, Chip, EmptyState, ErrorBox, Icon, IconButton, Segmented, Skeleton, StatCard } from "../ui";

type Img = { id: number; title: string | null; thumb: string; isCover: boolean };
type D = {
  id: number;
  name: string;
  monthlySalary: number;
  phone: string | null;
  licenseNo: string | null;
  licenseExpiry: string | null;
  joiningDate: string | null;
  details: string | null;
  images: Img[];
  totalKm: number;
  payments: { id: number; at: string; amount: number; paidBy: string | null; reason: string; forMonth: string; mode: string; details: string | null; images: Img[] }[];
  months: { month: string; due: number; paid: number; deductions: number; bonus: number; balance: number }[];
  trips: { id: number; at: string; startKm: number; stopKm: number; vehicleName: string }[];
  damages: { id: number; at: string; amount: number; vehicleName: string; description: string | null }[];
};
type Tab = "overview" | "payments" | "activity";

export function DriverDetail({ id }: { id: number }) {
  const { data: d, error, loading, reload } = useFetch<D>(`/api/drivers/${id}`);
  const router = useRouter();
  const viewer = useViewer();
  const [tab, setTab] = useState<Tab>("overview");
  if (loading) return <Skeleton rows={3} />;
  if (error || !d) return <ErrorBox message={error ?? "Not found"} retry={reload} />;
  const paidTotal = d.payments.filter((p) => p.reason !== "Deduction/Fine").reduce((s, p) => s + p.amount, 0);
  const expired = d.licenseExpiry && d.licenseExpiry < new Date().toISOString().slice(0, 10);

  return (
    <div className="pb-6">
      <div className="mb-4 flex items-center justify-between">
        <IconButton icon="chevL" label="Back" onClick={() => router.back()} className="-ml-3" />
        <Link href={`/drivers/${id}/edit`} className="btn btn-soft !min-h-10 !px-4">
          <Icon name="edit" size={16} /> Edit
        </Link>
      </div>
      <div className="flex items-center gap-4">
        <Thumb src={coverOf(d.images)} size={84} round />
        <div>
          <h1 className="text-4xl font-semibold leading-tight">{d.name}</h1>
          <div className="text-muted">{inr(d.monthlySalary)} / month</div>
          {d.phone && (
            <a href={`tel:${d.phone}`} className="mt-1 inline-flex items-center gap-1 text-sm text-primary">
              <Icon name="phone" size={14} /> {d.phone}
            </a>
          )}
        </div>
      </div>
      <Link href={`/drivers/${id}/pay`} className="btn btn-primary mt-5 w-full">
        <Icon name="coin" size={20} /> Driver payment
      </Link>
      <div className="mt-5">
        <Segmented<Tab> value={tab} onChange={setTab} options={[{ value: "overview", label: "Overview" }, { value: "payments", label: "Payments" }, { value: "activity", label: "Activity" }]} />
      </div>

      {tab === "overview" && (
        <div className="mt-5 space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <StatCard index={0} label="Km driven" value={d.totalKm} format={(n) => num(n, 0)} icon="gauge" />
            <StatCard index={1} label="Total paid" value={paidTotal} format={(n) => inr(Math.round(n))} icon="coin" gold />
          </div>
          <Card className="space-y-3 p-5 text-sm">
            <Row k="Licence number" v={d.licenseNo} />
            <Row k="Licence expiry" v={d.licenseExpiry ? fmtDate(d.licenseExpiry) : null} extra={expired ? <Chip tone="err">Expired</Chip> : null} />
            <Row k="Joined" v={d.joiningDate ? fmtDate(d.joiningDate) : null} />
            {d.details && <p className="whitespace-pre-wrap border-t border-line pt-3 text-muted">{d.details}</p>}
          </Card>
          {d.images.length > 0 && (
            <div>
              <h3 className="mb-2 text-xl font-semibold">Photos & documents</h3>
              <div className="grid grid-cols-3 gap-2">
                {d.images.map((img, i) => (
                  <button key={img.id} onClick={() => viewer.open(d.images.map((x) => ({ id: x.id, thumb: x.thumb, title: x.title })), i)} className="overflow-hidden rounded-2xl" aria-label={img.title ?? "Open image"}>
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img src={img.thumb} alt={img.title ?? ""} className="aspect-square w-full object-cover" />
                    {img.title && <span className="block truncate bg-pc px-2 py-1 text-xs">{img.title}</span>}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {tab === "payments" && (
        <div className="mt-5 space-y-5">
          <div>
            <h3 className="mb-1 text-xl font-semibold">Month-wise summary</h3>
            <p className="mb-2 text-xs text-muted">Balance = salary due − fines − salary &amp; advances paid. Bonuses are tracked separately.</p>
            <Card className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-pc text-left text-primary">
                  <tr>
                    {["Month", "Due", "Paid", "Fines", "Balance"].map((h) => (
                      <th key={h} className="px-3 py-2.5 font-semibold">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {d.months.map((m, i) => (
                    <tr key={m.month} className={i % 2 ? "bg-surface" : "bg-bg/60"}>
                      <td className="px-3 py-2.5 font-medium">{monthLabel(m.month)}</td>
                      <td className="px-3 py-2.5">{inr(m.due)}</td>
                      <td className="px-3 py-2.5">{inr(m.paid)}</td>
                      <td className="px-3 py-2.5">{m.deductions ? inr(m.deductions) : "—"}</td>
                      <td className={`px-3 py-2.5 font-semibold ${m.balance > 0 ? "text-err" : "text-ok"}`}>{inr(m.balance)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </Card>
          </div>
          <div>
            <h3 className="mb-2 text-xl font-semibold">History</h3>
            {!d.payments.length ? (
              <EmptyState text="No payments recorded yet." />
            ) : (
              <div className="space-y-3">
                {d.payments.map((p, i) => (
                  <Link key={p.id} href={`/payments/${p.id}/edit`} className="card rise block p-4" style={{ ["--i" as string]: Math.min(i, 8) }}>
                    <div className="flex items-start justify-between">
                      <div>
                        <div className="flex flex-wrap items-center gap-2">
                          <Chip tone={p.reason === "Deduction/Fine" ? "err" : p.reason === "Bonus" ? "gold" : "sage"}>{p.reason}</Chip>
                          <Chip tone="info">{p.mode}</Chip>
                        </div>
                        <div className="mt-1 text-xs text-muted">{fmtDateTime(p.at)} · for {monthLabel(p.forMonth)}</div>
                        {p.paidBy && <div className="text-xs text-muted">Paid by {p.paidBy}</div>}
                        {p.details && <div className="mt-1 text-sm text-muted">{p.details}</div>}
                      </div>
                      <div className="serif text-2xl font-semibold">{inr(p.amount)}</div>
                    </div>
                  </Link>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {tab === "activity" && (
        <div className="mt-5 space-y-5">
          <div>
            <h3 className="mb-2 text-xl font-semibold">Trips</h3>
            {!d.trips.length ? <EmptyState text="No trips for this driver yet." /> : (
              <div className="space-y-2">
                {d.trips.map((t) => (
                  <Link key={t.id} href={`/odometer/${t.id}/edit`} className="card flex items-center justify-between p-3.5">
                    <div>
                      <div className="font-semibold">{t.vehicleName}</div>
                      <div className="text-xs text-muted">{fmtDateTime(t.at)}</div>
                    </div>
                    <div className="serif text-2xl font-semibold text-primary">{num(t.stopKm - t.startKm, 1)} <span className="text-xs font-normal text-muted">km</span></div>
                  </Link>
                ))}
              </div>
            )}
          </div>
          <div>
            <h3 className="mb-2 text-xl font-semibold">Damages involved</h3>
            {!d.damages.length ? <EmptyState text="No damages linked to this driver." /> : (
              <div className="space-y-2">
                {d.damages.map((x) => (
                  <Link key={x.id} href={`/damages/${x.id}/edit`} className="card flex items-center justify-between p-3.5">
                    <div>
                      <div className="font-semibold">{x.vehicleName}</div>
                      <div className="text-xs text-muted">{fmtDateTime(x.at)}</div>
                      {x.description && <div className="text-sm text-muted">{x.description}</div>}
                    </div>
                    <div className="font-semibold text-err">{inr(x.amount)}</div>
                  </Link>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

function Row({ k, v, extra }: { k: string; v: string | null; extra?: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-3">
      <span className="text-muted">{k}</span>
      <span className="flex items-center gap-2 font-medium">{v ?? "—"} {extra}</span>
    </div>
  );
}
