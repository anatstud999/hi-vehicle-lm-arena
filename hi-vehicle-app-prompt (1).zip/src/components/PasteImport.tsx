"use client";
import { useEffect, useMemo, useState } from "react";
import { api } from "@/lib/client";
import { cn } from "@/lib/format";
import { Icon, IconButton, Switch, useToast } from "./ui";

type Field = { key: string; label: string; required: boolean };
type RowResult = { index: number; errors: Record<string, string>; duplicate: boolean; ok: boolean };

/** Parses clipboard text that is tab-separated (Excel / Sheets) or comma-separated (with quotes). */
export function parseClipboard(text: string): string[][] {
  const t = text.replace(/\r\n/g, "\n").replace(/\r/g, "\n").replace(/\n+$/, "");
  if (!t.trim()) return [];
  const first = t.split("\n")[0];
  const delim = first.includes("\t") ? "\t" : ",";
  const rows: string[][] = [];
  let row: string[] = [];
  let cell = "";
  let q = false;
  for (let i = 0; i < t.length; i++) {
    const ch = t[i];
    if (q) {
      if (ch === '"' && t[i + 1] === '"') {
        cell += '"';
        i++;
      } else if (ch === '"') q = false;
      else cell += ch;
    } else if (ch === '"' && cell === "") q = true;
    else if (ch === delim) {
      row.push(cell);
      cell = "";
    } else if (ch === "\n") {
      row.push(cell);
      rows.push(row);
      row = [];
      cell = "";
    } else cell += ch;
  }
  row.push(cell);
  rows.push(row);
  return rows.filter((r) => r.some((c) => c.trim() !== ""));
}

const norm = (s: string) => s.toLowerCase().replace(/[^a-z]/g, "");
const ALIASES: Record<string, string[]> = {
  vehicle: ["vehicle", "vehiclename", "plate", "numberplate"],
  start: ["start", "startkm", "starting", "startingreading", "open", "opening"],
  stop: ["stop", "stopkm", "stopping", "stoppingreading", "close", "closing", "end"],
  litres: ["litres", "liters", "volume", "qty", "l"],
  fuelType: ["fueltype", "fuel", "type"],
  odometer: ["odometer", "odo", "reading", "km"],
  type: ["type", "kind"],
};

function autoMap(headers: string[], fields: Field[]): number[] {
  // returns, for each source column, index of target field or -1
  const used = new Set<number>();
  return headers.map((h) => {
    const n = norm(h);
    const idx = fields.findIndex((f, i) => !used.has(i) && (norm(f.key) === n || norm(f.label) === n || norm(f.label.split("(")[0]) === n || (ALIASES[f.key] ?? []).includes(n)));
    if (idx >= 0) used.add(idx);
    return idx;
  });
}

export function PasteImport({ sheet, title, fields, onClose, onDone }: { sheet: string; title: string; fields: Field[]; onClose: () => void; onDone: () => void }) {
  const toast = useToast();
  const [text, setText] = useState("");
  const [raw, setRaw] = useState<string[][] | null>(null);
  const [header, setHeader] = useState(true);
  const [map, setMap] = useState<number[]>([]);
  const [results, setResults] = useState<RowResult[]>([]);
  const [skip, setSkip] = useState<Set<number>>(new Set());
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  // try the clipboard straight away; the textarea remains as a manual fallback
  useEffect(() => {
    navigator.clipboard?.readText().then((t) => t && setText(t)).catch(() => {});
  }, []);

  const body = useMemo(() => (raw ? (header ? raw.slice(1) : raw) : []), [raw, header]);
  const headers = useMemo(() => (raw ? (header ? raw[0] : raw[0].map((_, i) => `Column ${i + 1}`)) : []), [raw, header]);

  function parse() {
    const rows = parseClipboard(text);
    if (!rows.length) return setErr("Nothing to import yet — copy some rows and paste them here.");
    setErr(null);
    const looksHeader = rows[0].some((c) => c.trim() && Number.isNaN(Number(c.replace(/[₹,\s]/g, ""))) && autoMap([c], fields)[0] >= 0);
    setHeader(looksHeader);
    setRaw(rows);
    setMap(looksHeader ? autoMap(rows[0], fields) : rows[0].map((_, i) => (i < fields.length ? i : -1)));
  }
  useEffect(() => {
    if (raw && !header) setMap((m) => (m.every((x) => x < 0) ? raw[0].map((_, i) => (i < fields.length ? i : -1)) : m));
  }, [header, raw, fields.length]);

  const mapped = useMemo(
    () =>
      body.map((r) => {
        const o: Record<string, string> = {};
        map.forEach((fi, ci) => {
          if (fi >= 0) o[fields[fi].key] = (r[ci] ?? "").trim();
        });
        return o;
      }),
    [body, map, fields],
  );

  // live server-side validation (debounced)
  useEffect(() => {
    if (!raw) return;
    const t = setTimeout(() => {
      api<{ results: RowResult[] }>(`/api/sheets/${sheet}/import`, { body: { rows: mapped, commit: false } })
        .then((r) => setResults(r.results))
        .catch((e: Error) => setErr(e.message));
    }, 350);
    return () => clearTimeout(t);
  }, [mapped, raw, sheet]);

  const missingRequired = fields.filter((f) => f.required && !map.includes(fields.indexOf(f)));
  const include = results.filter((r) => r.ok && !skip.has(r.index));
  const invalid = results.filter((r) => Object.keys(r.errors).length).length;
  const dups = results.filter((r) => r.duplicate).length;

  async function commit() {
    setBusy(true);
    try {
      const rows = mapped.filter((_, i) => !skip.has(i));
      const res = await api<{ imported: number }>(`/api/sheets/${sheet}/import`, { body: { rows, commit: true } });
      toast.show(`Imported ${res.imported} row${res.imported === 1 ? "" : "s"}`);
      onDone();
    } catch (e) {
      setErr((e as Error).message);
      setBusy(false);
    }
  }

  const setCell = (ri: number, ci: number, v: string) => setRaw((r) => r && r.map((row, i) => (i === ri + (header ? 1 : 0) ? row.map((c, j) => (j === ci ? v : c)) : row)));

  return (
    <div className="fixed inset-0 z-[75] flex flex-col bg-bg">
      <div className="flex items-center gap-1 border-b border-line px-3 py-2">
        <IconButton icon="close" label="Close" onClick={onClose} />
        <h2 className="serif text-2xl font-semibold">Paste into {title}</h2>
      </div>
      <div className="flex-1 overflow-y-auto p-4">
        {!raw ? (
          <div className="mx-auto max-w-2xl space-y-3">
            <p className="text-sm text-muted">Copy rows from Excel or Google Sheets and paste them below. Tab- or comma-separated text both work. You'll review everything before it's saved.</p>
            <textarea className="input min-h-56 font-mono text-xs" placeholder="Paste data here…" value={text} onChange={(e) => setText(e.target.value)} />
            <div className="rounded-2xl bg-pc/60 p-3 text-xs text-muted">
              Expected columns: {fields.map((f) => `${f.label}${f.required ? "*" : ""}`).join(", ")}
            </div>
            {err && <p className="text-sm text-err">{err}</p>}
            <button className="btn btn-primary w-full" onClick={parse}>Preview</button>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="flex flex-wrap items-center gap-4">
              <label className="flex items-center gap-2 text-sm"><Switch checked={header} onChange={setHeader} label="First row is header" /> First row is header</label>
              <button className="text-sm text-primary underline" onClick={() => { setRaw(null); setResults([]); setSkip(new Set()); }}>Paste different data</button>
            </div>
            {missingRequired.length > 0 && <p className="rounded-2xl bg-[color-mix(in_srgb,var(--warn)_20%,transparent)] p-3 text-sm">Map a column for: <b>{missingRequired.map((f) => f.label).join(", ")}</b></p>}
            <div className="flex flex-wrap gap-2 text-sm">
              <span className="chip">{body.length} rows</span>
              <span className="chip" style={{ background: "color-mix(in srgb, var(--ok) 18%, transparent)", color: "var(--ok)" }}>{include.length} ready</span>
              {invalid > 0 && <span className="chip" style={{ background: "color-mix(in srgb, var(--err) 16%, transparent)", color: "var(--err)" }}>{invalid} invalid</span>}
              {dups > 0 && <span className="chip" style={{ background: "color-mix(in srgb, var(--warn) 22%, transparent)", color: "var(--warn)" }}>{dups} duplicate</span>}
            </div>
            <div className="card overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="bg-pc">
                    <th className="px-2 py-2 text-left text-xs text-primary">Use</th>
                    {headers.map((h, ci) => (
                      <th key={ci} className="min-w-36 px-2 py-2 text-left align-top">
                        <div className="mb-1 truncate text-xs font-normal text-muted">{h}</div>
                        <select className="input !min-h-9 !py-1 text-xs" value={map[ci] ?? -1} onChange={(e) => setMap((m) => m.map((x, i) => (i === ci ? Number(e.target.value) : x)))} aria-label={`Map ${h}`}>
                          <option value={-1}>Ignore</option>
                          {fields.map((f, fi) => (
                            <option key={f.key} value={fi}>{f.label}{f.required ? " *" : ""}</option>
                          ))}
                        </select>
                      </th>
                    ))}
                    <th className="px-2 py-2 text-left text-xs text-primary">Check</th>
                  </tr>
                </thead>
                <tbody>
                  {body.map((r, ri) => {
                    const res = results.find((x) => x.index === ri);
                    const skipped = skip.has(ri);
                    return (
                      <tr key={ri} className={cn("border-t border-line", skipped && "opacity-40")}>
                        <td className="px-2 py-1.5">
                          <input type="checkbox" className="h-5 w-5 accent-[var(--primary)]" checked={!skipped} onChange={() => setSkip((s) => { const n = new Set(s); if (n.has(ri)) n.delete(ri); else n.add(ri); return n; })} aria-label={`Include row ${ri + 1}`} />
                        </td>
                        {headers.map((_, ci) => {
                          const fi = map[ci];
                          const e = fi >= 0 ? res?.errors[fields[fi].key] : undefined;
                          return (
                            <td key={ci} className="px-1.5 py-1">
                              <input className={cn("input !min-h-9 !px-2 !py-1 text-xs", e && "invalid !bg-[color-mix(in_srgb,var(--err)_12%,transparent)]")} value={r[ci] ?? ""} title={e} onChange={(ev) => setCell(ri, ci, ev.target.value)} aria-label={`Row ${ri + 1} ${headers[ci]}`} />
                              {e && <div className="px-1 text-[11px] text-err">{e}</div>}
                            </td>
                          );
                        })}
                        <td className="whitespace-nowrap px-2 py-1.5 text-xs">
                          {!res ? "…" : res.duplicate ? <span className="text-warn">Duplicate · skipped</span> : Object.keys(res.errors).length ? <span className="text-err">Fix or skip</span> : <span className="text-ok">OK</span>}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
            {err && <p className="text-sm text-err">{err}</p>}
          </div>
        )}
      </div>
      {raw && (
        <div className="border-t border-line bg-surface px-4 py-3">
          <div className="mx-auto flex max-w-2xl gap-3">
            <button className="btn btn-ghost" onClick={onClose}>Cancel</button>
            <button className="btn btn-primary flex-1" disabled={busy || !include.length || missingRequired.length > 0} onClick={commit}>
              <Icon name="upload" size={18} /> {busy ? "Importing…" : `Import ${include.length} row${include.length === 1 ? "" : "s"}`}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
