import {
  boolean,
  doublePrecision,
  date,
  index,
  integer,
  pgTable,
  serial,
  text,
  timestamp,
  uniqueIndex,
} from "drizzle-orm/pg-core";

const now = () => timestamp("created_at", { withTimezone: true }).defaultNow().notNull();

export const vehicles = pgTable("vehicles", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  plate: text("plate").notNull().unique(),
  purchaseYear: integer("purchase_year"),
  type: text("type").notNull().default("Bus"),
  details: text("details"),
  createdAt: now(),
});

export const drivers = pgTable("drivers", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  monthlySalary: doublePrecision("monthly_salary").notNull().default(0),
  phone: text("phone"),
  licenseNo: text("license_no"),
  licenseExpiry: date("license_expiry", { mode: "string" }),
  joiningDate: date("joining_date", { mode: "string" }),
  details: text("details"),
  createdAt: now(),
});

export const odometerEntries = pgTable(
  "odometer_entries",
  {
    id: serial("id").primaryKey(),
    vehicleId: integer("vehicle_id").notNull().references(() => vehicles.id, { onDelete: "cascade" }),
    driverId: integer("driver_id").references(() => drivers.id, { onDelete: "set null" }),
    at: timestamp("at", { withTimezone: true }).notNull(),
    day: date("day", { mode: "string" }).notNull(),
    startKm: doublePrecision("start_km").notNull(),
    stopKm: doublePrecision("stop_km").notNull(),
    createdAt: now(),
  },
  (t) => [index("odo_vehicle_day_idx").on(t.vehicleId, t.day)],
);

export const dayStatuses = pgTable(
  "day_statuses",
  {
    id: serial("id").primaryKey(),
    vehicleId: integer("vehicle_id").notNull().references(() => vehicles.id, { onDelete: "cascade" }),
    day: date("day", { mode: "string" }).notNull(),
    status: text("status").notNull(), // holiday | non_working
  },
  (t) => [uniqueIndex("day_status_uq").on(t.vehicleId, t.day)],
);

export const fuelRefills = pgTable(
  "fuel_refills",
  {
    id: serial("id").primaryKey(),
    vehicleId: integer("vehicle_id").notNull().references(() => vehicles.id, { onDelete: "cascade" }),
    at: timestamp("at", { withTimezone: true }).notNull(),
    fuelType: text("fuel_type").notNull().default("Diesel"),
    litres: doublePrecision("litres").notNull(),
    odometer: doublePrecision("odometer").notNull(),
    amount: doublePrecision("amount"),
    fullTank: boolean("full_tank").notNull().default(true),
    createdAt: now(),
  },
  (t) => [index("fuel_vehicle_idx").on(t.vehicleId, t.at)],
);

export const damages = pgTable("damages", {
  id: serial("id").primaryKey(),
  vehicleId: integer("vehicle_id").notNull().references(() => vehicles.id, { onDelete: "cascade" }),
  at: timestamp("at", { withTimezone: true }).notNull(),
  description: text("description"),
  amount: doublePrecision("amount").notNull().default(0),
  location: text("location"),
  lat: doublePrecision("lat"),
  lng: doublePrecision("lng"),
  createdAt: now(),
});

export const damageDrivers = pgTable("damage_drivers", {
  id: serial("id").primaryKey(),
  damageId: integer("damage_id").notNull().references(() => damages.id, { onDelete: "cascade" }),
  driverId: integer("driver_id").notNull().references(() => drivers.id, { onDelete: "cascade" }),
});

export const tires = pgTable("tires", {
  id: serial("id").primaryKey(),
  code: text("code").notNull().unique(),
  createdAt: now(),
});

export const tireDamages = pgTable("tire_damages", {
  id: serial("id").primaryKey(),
  tireId: integer("tire_id").notNull().references(() => tires.id, { onDelete: "cascade" }),
  at: timestamp("at", { withTimezone: true }).notNull(),
  odometer: doublePrecision("odometer"),
  note: text("note"),
});

export const tireTrail = pgTable("tire_trail", {
  id: serial("id").primaryKey(),
  tireId: integer("tire_id").notNull().references(() => tires.id, { onDelete: "cascade" }),
  seq: integer("seq").notNull(),
  vehicleId: integer("vehicle_id").notNull().references(() => vehicles.id, { onDelete: "cascade" }),
  fitDate: date("fit_date", { mode: "string" }).notNull(),
  fitOdometer: doublePrecision("fit_odometer").notNull(),
  removeDate: date("remove_date", { mode: "string" }),
  removeOdometer: doublePrecision("remove_odometer"),
});

export const repairs = pgTable("repairs", {
  id: serial("id").primaryKey(),
  vehicleId: integer("vehicle_id").notNull().references(() => vehicles.id, { onDelete: "cascade" }),
  at: timestamp("at", { withTimezone: true }).notNull(),
  kind: text("kind").notNull().default("repair"), // repair | part
  amount: doublePrecision("amount").notNull().default(0),
  place: text("place"),
  description: text("description"),
  createdAt: now(),
});

export const driverPayments = pgTable("driver_payments", {
  id: serial("id").primaryKey(),
  driverId: integer("driver_id").notNull().references(() => drivers.id, { onDelete: "cascade" }),
  at: timestamp("at", { withTimezone: true }).notNull(),
  amount: doublePrecision("amount").notNull(),
  paidBy: text("paid_by"),
  reason: text("reason").notNull().default("Salary"),
  forMonth: text("for_month").notNull(), // yyyy-mm
  details: text("details"),
  mode: text("mode").notNull().default("Cash"),
  createdAt: now(),
});

/** Titled images attached to any record. `data` holds a compressed data URL, `thumb` a tiny one. */
export const images = pgTable(
  "images",
  {
    id: serial("id").primaryKey(),
    ownerType: text("owner_type").notNull(),
    ownerId: integer("owner_id").notNull(),
    title: text("title"),
    thumb: text("thumb").notNull(),
    data: text("data").notNull(),
    isCover: boolean("is_cover").notNull().default(false),
    sort: integer("sort").notNull().default(0),
  },
  (t) => [index("img_owner_idx").on(t.ownerType, t.ownerId)],
);

export const settings = pgTable("settings", {
  key: text("key").primaryKey(),
  value: text("value").notNull(),
});
