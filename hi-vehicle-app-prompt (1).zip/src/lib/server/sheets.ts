import { db } from "@/db";
import { damageDrivers, damages, drivers, fuelRefills, odometerEntries, repairs, vehicles } from "@/db/schema";
import { inArray } from "drizzle-orm";
import { fmtDate, fmtTime, istDay } from "@/lib/format";
import { HttpError } from "./http";
import { listDamages, listFuel, listOdometer, listRepairs } from "./resources";

export type SheetKey = "odometer" | "fuel" | "repairs" | "damages";
export type ColType = "text" | "int" | "dec" | "money";
export type Col = { key: string; label: string; type: ColType };
type Cell = string | number | null;
export type SheetRow = { id: number; v: Record<string, Cell>; s?: Record<string, string | number> };

export const SHEET_TITLES: Record<SheetKey, string> = {
  odometer: "Odometer",
  fuel: "Fuel Refill",
  repairs: "Repairs & New Parts",
  damages: "Damages",
};

const COLS: Record<SheetKey, Col[]> = {
  odometer: [
    { key: "date", label: "Date", type: "text" },
    { key: "time", label: "Time", type: "text" },
    { key: "vehicle", label: "Vehicle", type: "text" },
    { key: "driver", label: "Driver", type: "text" },
    { key: "start", label: "Start (km)", type: "dec" },
    { key: "stop", label: "Stop (km)", type: "dec" },
    { key: "km", label: "Km", type: "dec" },
    { key: "status", label: "Status", type: "text" },
  ],
  fuel: [
    { key: "date", label: "Date", type: "text" },
    { key: "vehicle", label: "Vehicle", type: "text" },
    { key: "fuelType", label: "Fuel type", type: "text" },
    { key: "litres", label: "Litres", type: "dec" },
    { key: "odometer", label: "Odometer", type: "dec" },
    { key: "prevOdometer", label: "Prev. odometer", type: "dec" },
    { key: "distance", label: "Distance", type: "dec" },
    { key: "mileage", label: "km/L", type: "dec" },
    { key: "amount", label: "Amount", type: "money" },
  ],
  repairs: [
    { key: "date", label: "Date", type: "text" },
    { key: "vehicle", label: "Vehicle", type: "text" },
    { key: "type", label: "Type", type: "text" },
    { key: "amount", label: "Amount", type: "money" },
    { key: "place", label: "Place", type: "text" },
    { key: "description", label: "Description", type: "text" },
  ],
  damages: [
    { key: "date", label: "Date", type: "text" },
    { key: "vehicle", label: "Vehicle", type: "text" },
    { key: "drivers", label: "Drivers", type: "text" },
    { key: "amount", label: "Amount", type: "money" },
    { key: "location", label: "Location", type: "text" },
    { key: "description", label: "Description", type: "text" },
  ],
};

export const IMPORT_FIELDS: Record<SheetKey, { key: string; label: string; required: boolean }[]> = {
  odometer: [
    { key: "date", label: "Date", required: true },
    { key: "time", label: "Time", required: false },
    { key: "vehicle", label: "Vehicle (name or plate)", required: true },
    { key: "driver", label: "Driver", required: false },
    { key: "start", label: "Start (km)", required: true },
    { key: "stop", label: "Stop (km)", required: true },
  ],
  fuel: [
    { key: "date", label: "Date", required: true },
    { key: "vehicle", label: "Vehicle (name or plate)", required: true },
    { key: "fuelType", label: "Fuel type", required: false },
    { key: "litres", label: "Litres", required: true },
    { key: "odometer", label: "Odometer", required: true },
    { key: "amount", label: "Amount", required: false },
  ],
  repairs: [
    { key: "date", label: "Date", required: true },
    { key: "vehicle", label: "Vehicle (name or plate)", required: true },
    { key: "type", label: "Type (Repair / New Part)", required: false },
    { key: "amount", label: "Amount", required: true },
    { key: "place", label: "Place", required: false },
    { key: "description", label: "Description", required: false },
  ],
  damages: [
    { key: "date", label: "Date", required: true },
    { key: "vehicle", label: "Vehicle (name or plate)", required: true },
    { key: "drivers", label: "Drivers (comma separated)", required: false },
    { key: "amount", label: "Amount", required: false },
    { key: "location", label: "Location", required: false },
    { key: "description", label: "Description", required: false },
  ],
};

export function isSheet(k: string): k is SheetKey {
  return k in COLS;
}

const r2 = (n: number | null) => (n === null ? null : Math.round(n * 100) / 100);
const dt = (d: Date | string) => `${fmtDate(d)} ${fmtTime(d)}`;

export async function sheetData(key: SheetKey) {
  let rows: SheetRow[] = [];
  if (key === "odometer") {
    rows = (await listOdometer()).map((o) => ({
      id: o.id,
      v: {
        date: fmtDate(o.at),
        time: fmtTime(o.at),
        vehicle: `${o.vehicleName} (${o.plate})`,
        driver: o.driverName ?? "",
        start: o.startKm,
        stop: o.stopKm,
        km: o.km,
        status: o.status,
      },
      s: { date: o.at.getTime(), time: o.at.getTime() % 86400000 },
    }));
  } else if (key === "fuel") {
    rows = (await listFuel()).map((f) => ({
      id: f.id,
      v: {
        date: dt(f.at),
        vehicle: `${f.vehicleName} (${f.plate})`,
        fuelType: f.fuelType,
        litres: f.litres,
        odometer: f.odometer,
        prevOdometer: f.prevOdometer,
        distance: f.distance,
        mileage: r2(f.mileage),
        amount: f.amount,
      },
      s: { date: new Date(f.at).getTime() },
    }));
  } else if (key === "repairs") {
    rows = (await listRepairs()).map((r) => ({
      id: r.id,
      v: {
        date: dt(r.at),
        vehicle: `${r.vehicleName} (${r.plate})`,
        type: r.kind === "part" ? "New Part" : "Repair",
        amount: r.amount,
        place: r.place ?? "",
        description: r.description ?? "",
      },
      s: { date: r.at.getTime() },
    }));
  } else {
    rows = (await listDamages()).map((d) => ({
      id: d.id,
      v: {
        date: dt(d.at),
        vehicle: `${d.vehicleName} (${d.plate})`,
        drivers: d.drivers.map((x) => x.name).join(", "),
        amount: d.amount,
        location: d.location ?? "",
        description: d.description ?? "",
      },
      s: { date: d.at.getTime() },
    }));
  }
  const vehicleOptions = [...new Set(rows.map((r) => String(r.v.vehicle)))].sort();
  return { key, title: SHEET_TITLES[key], columns: COLS[key], rows, vehicleOptions, importFields: IMPORT_FIELDS[key] };
}

export async function deleteSheetRows(key: SheetKey, ids: number[]) {
  if (!ids.length) return;
  const table = { odometer: odometerEntries, fuel: fuelRefills, repairs, damages }[key];
  await db.delete(table).where(inArray(table.id, ids));
}

/* ═════════ import / paste ═════════ */
const MON = ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"];

export function parseDateTime(dateStr: string, timeStr?: string): Date | null {
  let s = `${dateStr ?? ""} ${timeStr ?? ""}`.trim().replace(/,/g, " ").replace(/\s+/g, " ");
  let y = 0,
    m = 0,
    d = 0;
  let mt: RegExpMatchArray | null;
  if ((mt = s.match(/^(\d{4})-(\d{1,2})-(\d{1,2})/))) {
    [y, m, d] = [+mt[1], +mt[2], +mt[3]];
  } else if ((mt = s.match(/^(\d{1,2})[/.-](\d{1,2})[/.-](\d{2,4})/))) {
    [d, m, y] = [+mt[1], +mt[2], +mt[3]];
    if (y < 100) y += 2000;
  } else if ((mt = s.match(/^(\d{1,2})[ -]([A-Za-z]{3})[a-z]*[ -](\d{2,4})/))) {
    d = +mt[1];
    m = MON.indexOf(mt[2].toLowerCase()) + 1;
    y = +mt[3];
    if (y < 100) y += 2000;
  } else return null;
  if (!m || m > 12 || d < 1 || d > 31) return null;
  s = s.slice(mt![0].length).trim();
  let hh = 9,
    mm = 0;
  const tm = s.match(/(\d{1,2}):(\d{2})\s*([AaPp][Mm])?/);
  if (tm) {
    hh = +tm[1];
    mm = +tm[2];
    if (tm[3]) {
      const pm = tm[3].toLowerCase() === "pm";
      if (pm && hh < 12) hh += 12;
      if (!pm && hh === 12) hh = 0;
    }
  }
  const iso = `${y}-${String(m).padStart(2, "0")}-${String(d).padStart(2, "0")}T${String(hh).padStart(2, "0")}:${String(mm).padStart(2, "0")}:00+05:30`;
  const out = new Date(iso);
  return Number.isNaN(out.getTime()) ? null : out;
}

function parseNum(s: string | undefined): number | null {
  if (s === undefined || s === null) return null;
  const c = String(s).replace(/[₹,\s]|km|kms|ltrs?|litres?|l$/gi, "");
  if (c === "") return null;
  const n = Number(c);
  return Number.isFinite(n) ? n : null;
}

type Raw = Record<string, string>;
export type RowResult = { index: number; errors: Record<string, string>; duplicate: boolean; ok: boolean };

export async function importRows(key: SheetKey, rows: Raw[], commit: boolean) {
  const vs = await db.select().from(vehicles);
  const ds = await db.select().from(drivers);
  const norm = (x: string) => x.toLowerCase().replace(/\s+/g, "");
  const findVehicle = (s: string) => {
    const q = norm(s.replace(/\(.*\)/, "")) || norm(s);
    const plateInParens = s.match(/\(([^)]+)\)/)?.[1];
    return (
      vs.find((v) => plateInParens && norm(v.plate) === norm(plateInParens)) ??
      vs.find((v) => norm(v.plate) === norm(s) || norm(v.plate) === q) ??
      vs.find((v) => norm(v.name) === q)
    );
  };
  const findDriver = (s: string) => ds.find((d) => norm(d.name) === norm(s));

  // existing keys for duplicate detection
  const seen = new Set<string>();
  const minute = (d: Date | string) => Math.floor(new Date(d).getTime() / 60000);
  if (key === "odometer") (await listOdometer()).forEach((o) => seen.add(`${o.vehicleId}|${minute(o.at)}|${o.startKm}|${o.stopKm}`));
  if (key === "fuel") (await listFuel()).forEach((o) => seen.add(`${o.vehicleId}|${minute(o.at)}|${o.odometer}`));
  if (key === "repairs") (await listRepairs()).forEach((o) => seen.add(`${o.vehicleId}|${minute(o.at)}|${o.amount}`));
  if (key === "damages") (await listDamages()).forEach((o) => seen.add(`${o.vehicleId}|${minute(o.at)}|${o.amount}`));

  const results: RowResult[] = [];
  let imported = 0;
  for (let i = 0; i < rows.length; i++) {
    const r = rows[i];
    const errors: Record<string, string> = {};
    const at = parseDateTime(r.date ?? "", r.time);
    if (!at) errors.date = "Unrecognised date";
    const veh = (r.vehicle ?? "").trim() ? findVehicle(r.vehicle) : undefined;
    if (!veh) errors.vehicle = r.vehicle ? "Vehicle not found" : "Required";
    let dupKey = "";
    let exec: (() => Promise<void>) | null = null;

    if (key === "odometer") {
      const start = parseNum(r.start);
      const stop = parseNum(r.stop);
      if (start === null) errors.start = "Number needed";
      if (stop === null) errors.stop = "Number needed";
      if (start !== null && stop !== null && stop < start) errors.stop = "Must be ≥ start";
      const drv = (r.driver ?? "").trim() ? findDriver(r.driver) : null;
      if ((r.driver ?? "").trim() && !drv) errors.driver = "Driver not found";
      if (!Object.keys(errors).length) {
        dupKey = `${veh!.id}|${minute(at!)}|${start}|${stop}`;
        exec = async () => {
          await db.insert(odometerEntries).values({
            vehicleId: veh!.id,
            driverId: drv?.id ?? null,
            at: at!,
            day: istDay(at!),
            startKm: start!,
            stopKm: stop!,
          });
        };
      }
    } else if (key === "fuel") {
      const litres = parseNum(r.litres);
      const odo = parseNum(r.odometer);
      const amount = parseNum(r.amount);
      if (litres === null || litres <= 0) errors.litres = "Number needed";
      if (odo === null) errors.odometer = "Number needed";
      if ((r.amount ?? "").trim() && amount === null) errors.amount = "Not a number";
      const ft = /^p/i.test(r.fuelType ?? "") ? "Petrol" : "Diesel";
      if (!Object.keys(errors).length) {
        dupKey = `${veh!.id}|${minute(at!)}|${odo}`;
        exec = async () => {
          await db.insert(fuelRefills).values({ vehicleId: veh!.id, at: at!, fuelType: ft, litres: litres!, odometer: odo!, amount, fullTank: true });
        };
      }
    } else if (key === "repairs") {
      const amount = parseNum(r.amount);
      if (amount === null) errors.amount = "Number needed";
      const kind = /part/i.test(r.type ?? "") ? "part" : "repair";
      if (!Object.keys(errors).length) {
        dupKey = `${veh!.id}|${minute(at!)}|${amount}`;
        exec = async () => {
          await db.insert(repairs).values({
            vehicleId: veh!.id,
            at: at!,
            kind,
            amount: amount!,
            place: (r.place ?? "").trim() || null,
            description: (r.description ?? "").trim() || null,
          });
        };
      }
    } else {
      const amount = (r.amount ?? "").trim() ? parseNum(r.amount) : 0;
      if (amount === null) errors.amount = "Not a number";
      const names = (r.drivers ?? "").split(/[,;]/).map((x) => x.trim()).filter(Boolean);
      const found = names.map((n) => findDriver(n));
      if (found.some((f) => !f)) errors.drivers = "Driver not found";
      if (!Object.keys(errors).length) {
        dupKey = `${veh!.id}|${minute(at!)}|${amount}`;
        exec = async () => {
          const [row] = await db
            .insert(damages)
            .values({
              vehicleId: veh!.id,
              at: at!,
              amount: amount!,
              location: (r.location ?? "").trim() || null,
              description: (r.description ?? "").trim() || null,
            })
            .returning({ id: damages.id });
          const dids = found.filter(Boolean).map((f) => f!.id);
          if (dids.length) await db.insert(damageDrivers).values(dids.map((driverId) => ({ damageId: row.id, driverId })));
        };
      }
    }

    const duplicate = !!dupKey && seen.has(dupKey);
    const ok = !Object.keys(errors).length && !duplicate;
    if (dupKey) seen.add(dupKey);
    if (commit && ok && exec) {
      await exec();
      imported++;
    }
    results.push({ index: i, errors, duplicate, ok });
  }
  if (commit && !rows.length) throw new HttpError(400, "Nothing to import");
  return { results, imported };
}
