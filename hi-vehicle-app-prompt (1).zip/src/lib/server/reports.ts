import { eq, inArray } from "drizzle-orm";
import { db } from "@/db";
import { dayStatuses, drivers, fuelRefills, odometerEntries, tireDamages, tireTrail, tires, vehicles } from "@/db/schema";
import { computeFuel } from "@/lib/calc";
import { addDays, diffDays, inr, istDay, monthLabel, today } from "@/lib/format";
import { listDamages, listRepairs } from "./resources";
import { imagesFor } from "./http";

const startOf = (d: string) => new Date(`${d}T00:00:00+05:30`).getTime();
const endOf = (d: string) => new Date(`${d}T23:59:59.999+05:30`).getTime();
const sum = (a: number[]) => a.reduce((s, x) => s + x, 0);
const avg = (a: number[]) => (a.length ? sum(a) / a.length : null);

export async function buildReport(vehicleIds: number[], from: string, to: string) {
  const vs = vehicleIds.length
    ? await db.select().from(vehicles).where(inArray(vehicles.id, vehicleIds))
    : [];
  const imgs = await imagesFor("vehicle", vs.map((v) => v.id));
  const [odoAll, fuelAll, dmgAll, repAll, statuses, trails, tireRows, tireDmg, driverRows] = await Promise.all([
    db.select().from(odometerEntries),
    db
      .select()
      .from(fuelRefills),
    listDamages(),
    listRepairs(),
    db.select().from(dayStatuses),
    db.select().from(tireTrail),
    db.select().from(tires),
    db.select().from(tireDamages),
    db.select().from(drivers),
  ]);
  const driverName = new Map(driverRows.map((d) => [d.id, d.name]));
  const fuelComputed = computeFuel(fuelAll);

  const totalDays = Math.max(1, diffDays(from, to) + 1);
  const effTo = to > today() ? today() : to;
  const effDays = Math.max(0, diffDays(from, effTo) + 1);
  const prevTo = addDays(from, -1);
  const prevFrom = addDays(from, -totalDays);
  const now = Date.now();
  const months: string[] = [];
  for (let d = from.slice(0, 7); d <= to.slice(0, 7); ) {
    months.push(d);
    let [y, m] = d.split("-").map(Number);
    m++;
    if (m > 12) {
      m = 1;
      y++;
    }
    d = `${y}-${String(m).padStart(2, "0")}`;
  }

  const reports = vs.map((v) => {
    const inRange = (at: Date | string) => {
      const t = new Date(at).getTime();
      return t >= startOf(from) && t <= endOf(to);
    };
    // ── distance
    const odo = odoAll.filter((o) => o.vehicleId === v.id && o.day >= from && o.day <= to);
    const totalKm = sum(odo.map((o) => o.stopKm - o.startKm));
    const workDays = new Set(odo.map((o) => o.day));
    const st = statuses.filter((s) => s.vehicleId === v.id && s.day >= from && s.day <= to && !workDays.has(s.day));
    const holidays = st.filter((s) => s.status === "holiday").length;
    const nonWorking = st.filter((s) => s.status === "non_working").length;
    const noInfo = Math.max(0, effDays - workDays.size - holidays - nonWorking);
    const compliance = effDays ? ((effDays - noInfo) / effDays) * 100 : 100;
    const byDriverKm = new Map<string, number>();
    for (const o of odo) {
      const n = o.driverId ? (driverName.get(o.driverId) ?? "Unknown") : "Unassigned";
      byDriverKm.set(n, (byDriverKm.get(n) ?? 0) + (o.stopKm - o.startKm));
    }

    // ── fuel
    const fv = fuelComputed.filter((f) => f.vehicleId === v.id);
    const fr = fv.filter((f) => inRange(f.at)).sort((a, b) => new Date(a.at).getTime() - new Date(b.at).getTime());
    const good = fr.filter((f) => f.mileage && !f.estimated);
    const goodVals = good.map((f) => f.mileage as number);
    const prevGood = fv
      .filter((f) => f.mileage && !f.estimated && new Date(f.at).getTime() >= startOf(prevFrom) && new Date(f.at).getTime() <= endOf(prevTo))
      .map((f) => f.mileage as number);
    const avgM = avg(goodVals);
    const prevAvg = avg(prevGood);
    const litres = sum(fr.map((f) => f.litres));
    const fuelCost = sum(fr.map((f) => f.amount ?? 0));
    const byType: Record<string, number> = {};
    for (const f of fr) byType[f.fuelType] = (byType[f.fuelType] ?? 0) + f.litres;
    const litresSince = (days: number) =>
      sum(fv.filter((f) => new Date(f.at).getTime() >= now - days * 86400000).map((f) => f.litres));
    const mileageDelta = avgM !== null && prevAvg !== null ? avgM - prevAvg : null;
    const mileageDeltaPct = mileageDelta !== null && prevAvg ? (mileageDelta / prevAvg) * 100 : null;

    // ── damages & repairs
    const dm = dmgAll.filter((d) => d.vehicleId === v.id && inRange(d.at));
    const dmByDriver = new Map<string, { count: number; amount: number }>();
    for (const d of dm)
      for (const dr of d.drivers) {
        const cur = dmByDriver.get(dr.name) ?? { count: 0, amount: 0 };
        dmByDriver.set(dr.name, { count: cur.count + 1, amount: cur.amount + d.amount });
      }
    const rp = repAll.filter((r) => r.vehicleId === v.id && inRange(r.at));
    const reps = rp.filter((r) => r.kind === "repair");
    const parts = rp.filter((r) => r.kind === "part");
    const biggest = [...rp].sort((a, b) => b.amount - a.amount)[0];

    // ── tires
    const tireInfo = tireRows
      .map((t) => {
        const tr = trails.filter((x) => x.tireId === t.id).sort((a, b) => a.seq - b.seq);
        const last = tr[tr.length - 1];
        const here = tr.filter((x) => x.vehicleId === v.id);
        if (!here.length) return null;
        const km = sum(here.map((x) => (x.removeOdometer !== null ? x.removeOdometer - x.fitOdometer : 0)));
        return {
          code: t.code,
          fitted: !!last && last.vehicleId === v.id && !last.removeDate,
          damaged: tireDmg.some((d) => d.tireId === t.id),
          km,
          fitDate: here[0].fitDate,
        };
      })
      .filter(Boolean) as { code: string; fitted: boolean; damaged: boolean; km: number; fitDate: string }[];

    // ── cost
    const dmgTotal = sum(dm.map((d) => d.amount));
    const repTotal = sum(reps.map((r) => r.amount));
    const partTotal = sum(parts.map((r) => r.amount));
    const totalCost = fuelCost + dmgTotal + repTotal + partTotal;
    const monthly = months.map((m) => {
      const inM = (at: Date | string) => istDay(at).slice(0, 7) === m;
      return {
        month: m,
        label: monthLabel(m),
        fuel: sum(fr.filter((f) => inM(f.at)).map((f) => f.amount ?? 0)),
        repairs: sum(reps.filter((r) => inM(r.at)).map((r) => r.amount)),
        parts: sum(parts.filter((r) => inM(r.at)).map((r) => r.amount)),
        damages: sum(dm.filter((d) => inM(d.at)).map((d) => d.amount)),
      };
    });

    // ── insights
    const insights: string[] = [];
    if (mileageDeltaPct !== null)
      insights.push(
        `Mileage ${mileageDeltaPct < 0 ? "fell" : "rose"} ${Math.abs(mileageDeltaPct).toFixed(0)}% compared with the previous period.`,
      );
    if (effDays && noInfo > 0) insights.push(`Odometer entries are missing for ${noInfo} day${noInfo > 1 ? "s" : ""} in this period.`);
    if (totalKm > 0 && fuelCost > 0) insights.push(`Fuel costs about ${inr(Math.round((fuelCost / totalKm) * 100) / 100)} per kilometre.`);
    if (totalCost > 0) {
      const parts3: [string, number][] = [["Fuel", fuelCost], ["Repairs", repTotal], ["New parts", partTotal], ["Damages", dmgTotal]];
      const top = parts3.sort((a, b) => b[1] - a[1])[0];
      insights.push(`${top[0]} is the largest expense at ${((top[1] / totalCost) * 100).toFixed(0)}% of running cost.`);
    }
    if (dm.length) insights.push(`${dm.length} damage${dm.length > 1 ? "s" : ""} recorded, costing ${inr(dmgTotal)}.`);
    if (!odo.length && !fr.length) insights.push("No activity recorded for this vehicle in the selected period.");

    return {
      vehicle: { id: v.id, name: v.name, plate: v.plate, type: v.type, cover: (imgs.get(v.id) ?? []).find((i) => i.isCover)?.thumb ?? imgs.get(v.id)?.[0]?.thumb ?? null },
      distance: {
        totalKm,
        workingDays: workDays.size,
        avgPerWorkingDay: workDays.size ? totalKm / workDays.size : 0,
        holidays,
        nonWorking,
        noInfo,
        compliance,
      },
      fuel: {
        litres,
        last7: litresSince(7),
        last30: litresSince(30),
        byType,
        cost: fuelCost,
        avgMileage: avgM,
        bestMileage: goodVals.length ? Math.max(...goodVals) : null,
        worstMileage: goodVals.length ? Math.min(...goodVals) : null,
        prevAvgMileage: prevAvg,
        mileageDelta,
        mileageDeltaPct,
        costPerKm: totalKm > 0 && fuelCost > 0 ? fuelCost / totalKm : null,
        series: fr
          .filter((f) => f.mileage)
          .map((f) => ({ at: new Date(f.at).toISOString(), mileage: f.mileage as number, estimated: f.estimated })),
        refills: fr.length,
      },
      damages: {
        count: dm.length,
        total: dmgTotal,
        latest: dm[0] ? { at: dm[0].at, description: dm[0].description, amount: dm[0].amount } : null,
        byDriver: [...dmByDriver.entries()].map(([name, x]) => ({ name, ...x })),
      },
      repairs: {
        repairCount: reps.length,
        repairTotal: repTotal,
        partCount: parts.length,
        partTotal,
        biggest: biggest ? { kind: biggest.kind, amount: biggest.amount, description: biggest.description, at: biggest.at } : null,
      },
      tires: {
        fitted: tireInfo.filter((t) => t.fitted).length,
        damaged: tireInfo.filter((t) => t.damaged).length,
        trail: tireInfo,
      },
      cost: { fuel: fuelCost, repairs: repTotal, parts: partTotal, damages: dmgTotal, total: totalCost, monthly },
      drivers: [...byDriverKm.entries()].map(([name, km]) => ({ name, km })).sort((a, b) => b.km - a.km),
      insights,
    };
  });

  return { from, to, totalDays, generatedAt: new Date().toISOString(), vehicles: reports };
}

export type ReportData = Awaited<ReturnType<typeof buildReport>>;
export type VehicleReport = ReportData["vehicles"][number];
void eq;
