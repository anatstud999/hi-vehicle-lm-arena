import crypto from "node:crypto";
import { cookies } from "next/headers";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { settings } from "@/db/schema";
import { HttpError } from "./http";

const COOKIE = "hv_sheet";
const TTL_MS = 2 * 60 * 1000; // auto-lock after 2 minutes

async function getSetting(key: string): Promise<string | null> {
  const r = await db.select().from(settings).where(eq(settings.key, key)).limit(1);
  return r[0]?.value ?? null;
}
async function setSetting(key: string, value: string) {
  await db.insert(settings).values({ key, value }).onConflictDoUpdate({ target: settings.key, set: { value } });
}

export function hashPassword(pw: string, salt = crypto.randomBytes(16).toString("hex")): string {
  const h = crypto.scryptSync(pw, salt, 32).toString("hex");
  return `${salt}:${h}`;
}
export function verifyHash(pw: string, stored: string): boolean {
  const [salt, h] = stored.split(":");
  if (!salt || !h) return false;
  const a = Buffer.from(crypto.scryptSync(pw, salt, 32).toString("hex"));
  const b = Buffer.from(h);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

function sign(exp: number, stored: string): string {
  return crypto.createHmac("sha256", stored).update(String(exp)).digest("hex");
}

export async function lockStatus() {
  const stored = await getSetting("master_hash");
  const hint = await getSetting("master_hint");
  let unlocked = false;
  if (stored) {
    const c = (await cookies()).get(COOKIE)?.value;
    if (c) {
      const [exp, sig] = c.split(".");
      unlocked = Number(exp) > Date.now() && sig === sign(Number(exp), stored);
    }
  }
  return { configured: !!stored, unlocked, hint };
}

export async function requireUnlocked() {
  const s = await lockStatus();
  if (!s.unlocked) throw new HttpError(401, "Data Sheets are locked");
}

async function issue(stored: string) {
  const exp = Date.now() + TTL_MS;
  (await cookies()).set(COOKIE, `${exp}.${sign(exp, stored)}`, {
    httpOnly: true,
    sameSite: "lax",
    path: "/",
    maxAge: 60 * 60,
  });
}

export async function lockAction(body: Record<string, unknown>) {
  const action = String(body.action ?? "");
  const stored = await getSetting("master_hash");
  const pw = typeof body.password === "string" ? body.password : "";

  if (action === "setup") {
    if (stored) throw new HttpError(400, "A master password already exists");
    if (pw.length < 4) throw new HttpError(400, "Use at least 4 characters");
    if (pw !== body.confirm) throw new HttpError(400, "Passwords do not match");
    const h = hashPassword(pw);
    await setSetting("master_hash", h);
    await setSetting("master_hint", typeof body.hint === "string" ? body.hint.trim() : "");
    await issue(h);
    return { ok: true };
  }
  if (!stored) throw new HttpError(400, "Create a master password first");

  if (action === "unlock") {
    if (!verifyHash(pw, stored)) throw new HttpError(401, "That password is not correct");
    await issue(stored);
    return { ok: true };
  }
  if (action === "keepalive") {
    const s = await lockStatus();
    if (!s.unlocked) throw new HttpError(401, "Locked");
    await issue(stored);
    return { ok: true };
  }
  if (action === "lock") {
    (await cookies()).delete(COOKIE);
    return { ok: true };
  }
  if (action === "change" || action === "reset") {
    const next = typeof body.next === "string" ? body.next : "";
    if (next.length < 4) throw new HttpError(400, "Use at least 4 characters");
    if (next !== body.confirm) throw new HttpError(400, "Passwords do not match");
    if (action === "change" && !verifyHash(String(body.old ?? ""), stored))
      throw new HttpError(401, "The current password is not correct");
    if (action === "reset" && body.confirmOwner !== true) throw new HttpError(400, "Please confirm ownership first");
    const h = hashPassword(next);
    await setSetting("master_hash", h);
    if (typeof body.hint === "string") await setSetting("master_hint", body.hint.trim());
    await issue(h);
    return { ok: true };
  }
  throw new HttpError(400, "Unknown action");
}
