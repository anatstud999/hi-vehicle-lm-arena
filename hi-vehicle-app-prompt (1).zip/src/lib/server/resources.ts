import { and, asc, desc, eq, inArray, lt, ne, notInArray, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  damageDrivers,
  damages,
  dayStatuses,
  driverPayments,
  drivers,
  fuelRefills,
  images,
  odometerEntries,
  repairs,
  tireDamages,
  tireTrail,
  tires,
  vehicles,
} from "@/db/schema";
import { computeFuel } from "@/lib/calc";
import { addDays, diffDays, istDay, today } from "@/lib/format";
import {
  HttpError,
  deleteImagesOf,
  imagesFor,
  optDay,
  optNum,
  optStr,
  reqDate,
  reqNum,
  reqStr,
  syncImages,
} from "./http";

type Body = Record<string, unknown>;
export type Resource = {
  list: (sp: URLSearchParams) => Promise<unknown>;
  get: (id: number) => Promise<unknown>;
  create: (b: Body) => Promise<{ id: number }>;
  update: (id: number, b: Body) => Promise<unknown>;
  remove: (id: number) => Promise<unknown>;
};

const ids = <T extends { id: number }>(rows: T[]) => rows.map((r) => r.id);
const notFound = () => new HttpError(404, "Record not found");

/* ═════════ shared list builders (also used by data sheets, reports, dashboard) ═════════ */
export async function listOdometer() {
  const rows = await db
    .select({
      id: odometerEntries.id,
      vehicleId: odometerEntries.vehicleId,
      driverId: odometerEntries.driverId,
      at: odometerEntries.at,
      day: odometerEntries.day,
      startKm: odometerEntries.startKm,
      stopKm: odometerEntries.stopKm,
      vehicleName: vehicles.name,
      plate: vehicles.plate,
      driverName: drivers.name,
    })
    .from(odometerEntries)
    .innerJoin(vehicles, eq(vehicles.id, odometerEntries.vehicleId))
    .leftJoin(drivers, eq(drivers.id, odometerEntries.driverId))
    .orderBy(asc(odometerEntries.at), asc(odometerEntries.id));
  const run = new Map<number, number>();
  const lastStop = new Map<number, number>();
  const out = rows.map((r) => {
    const km = r.stopKm - r.startKm;
    const total = (run.get(r.vehicleId) ?? 0) + km;
    run.set(r.vehicleId, total);
    const prev = lastStop.get(r.vehicleId);
    lastStop.set(r.vehicleId, r.stopKm);
    return { ...r, km, totalKm: total, status: prev === undefined || prev === r.startKm ? "OK" : "Gap" };
  });
  return out.reverse();
}

export async function listFuel() {
  const rows = await db
    .select({
      id: fuelRefills.id,
      vehicleId: fuelRefills.vehicleId,
      at: fuelRefills.at,
      fuelType: fuelRefills.fuelType,
      litres: fuelRefills.litres,
      odometer: fuelRefills.odometer,
      amount: fuelRefills.amount,
      fullTank: fuelRefills.fullTank,
      vehicleName: vehicles.name,
      plate: vehicles.plate,
    })
    .from(fuelRefills)
    .innerJoin(vehicles, eq(vehicles.id, fuelRefills.vehicleId));
  return computeFuel(rows).sort((a, b) => new Date(b.at).getTime() - new Date(a.at).getTime() || b.id - a.id);
}

export async function listRepairs() {
  return db
    .select({
      id: repairs.id,
      vehicleId: repairs.vehicleId,
      at: repairs.at,
      kind: repairs.kind,
      amount: repairs.amount,
      place: repairs.place,
      description: repairs.description,
      vehicleName: vehicles.name,
      plate: vehicles.plate,
    })
    .from(repairs)
    .innerJoin(vehicles, eq(vehicles.id, repairs.vehicleId))
    .orderBy(desc(repairs.at));
}

export async function listDamages() {
  const rows = await db
    .select({
      id: damages.id,
      vehicleId: damages.vehicleId,
      at: damages.at,
      description: damages.description,
      amount: damages.amount,
      location: damages.location,
      lat: damages.lat,
      lng: damages.lng,
      vehicleName: vehicles.name,
      plate: vehicles.plate,
    })
    .from(damages)
    .innerJoin(vehicles, eq(vehicles.id, damages.vehicleId))
    .orderBy(desc(damages.at));
  const links = rows.length
    ? await db
        .select({ damageId: damageDrivers.damageId, id: drivers.id, name: drivers.name })
        .from(damageDrivers)
        .innerJoin(drivers, eq(drivers.id, damageDrivers.driverId))
        .where(inArray(damageDrivers.damageId, ids(rows)))
    : [];
  return rows.map((r) => ({
    ...r,
    drivers: links.filter((l) => l.damageId === r.id).map((l) => ({ id: l.id, name: l.name })),
  }));
}

/* ═════════ vehicles ═════════ */
async function ensurePlateFree(plate: string, exceptId?: number) {
  const dup = await db
    .select({ id: vehicles.id })
    .from(vehicles)
    .where(exceptId ? and(eq(vehicles.plate, plate), ne(vehicles.id, exceptId)) : eq(vehicles.plate, plate))
    .limit(1);
  if (dup.length) throw new HttpError(409, "This number plate is already registered");
}
function vehicleFields(b: Body) {
  return {
    name: reqStr(b, "name", "Vehicle name"),
    plate: reqStr(b, "plate", "Number plate").toUpperCase().replace(/\s+/g, " "),
    purchaseYear: optNum(b, "purchaseYear"),
    type: optStr(b, "type") ?? "Bus",
    details: optStr(b, "details"),
  };
}

const vehicleRes: Resource = {
  async list() {
    const rows = await db.select().from(vehicles).orderBy(asc(vehicles.name));
    const imgs = await imagesFor("vehicle", ids(rows));
    return rows.map((r) => ({ ...r, images: imgs.get(r.id) ?? [] }));
  },
  async get(id) {
    const [v] = await db.select().from(vehicles).where(eq(vehicles.id, id));
    if (!v) throw notFound();
    const imgs = await imagesFor("vehicle", [id]);
    const [odo, fuel, dmg, rep] = await Promise.all([
      db.select().from(odometerEntries).where(eq(odometerEntries.vehicleId, id)).orderBy(desc(odometerEntries.at)),
      db.select().from(fuelRefills).where(eq(fuelRefills.vehicleId, id)),
      db.select().from(damages).where(eq(damages.vehicleId, id)).orderBy(desc(damages.at)),
      db.select().from(repairs).where(eq(repairs.vehicleId, id)).orderBy(desc(repairs.at)),
    ]);
    const fc = computeFuel(fuel).sort((a, b) => new Date(b.at).getTime() - new Date(a.at).getTime());
    const good = fc.filter((f) => f.mileage && !f.estimated);
    const stats = {
      totalKm: odo.reduce((s, o) => s + (o.stopKm - o.startKm), 0),
      lastReading: odo[0]?.stopKm ?? null,
      litres: fuel.reduce((s, f) => s + f.litres, 0),
      avgMileage: good.length ? good.reduce((s, f) => s + (f.mileage as number), 0) / good.length : null,
      spend:
        fuel.reduce((s, f) => s + (f.amount ?? 0), 0) +
        dmg.reduce((s, d) => s + d.amount, 0) +
        rep.reduce((s, r) => s + r.amount, 0),
    };
    const timeline = [
      ...odo.slice(0, 8).map((o) => ({
        type: "odometer",
        at: o.at,
        title: `Trip ${Math.round(o.stopKm - o.startKm)} km`,
        sub: `${o.startKm} → ${o.stopKm} km`,
        amount: null as number | null,
      })),
      ...fc.slice(0, 8).map((f) => ({
        type: "fuel",
        at: f.at,
        title: `Refuelled ${f.litres} L ${f.fuelType}`,
        sub: f.mileage ? `${f.mileage.toFixed(2)} km/L` : `${f.odometer} km`,
        amount: f.amount,
      })),
      ...dmg.slice(0, 8).map((d) => ({
        type: "damage",
        at: d.at,
        title: "Damage",
        sub: d.description ?? d.location ?? "",
        amount: d.amount,
      })),
      ...rep.slice(0, 8).map((r) => ({
        type: r.kind,
        at: r.at,
        title: r.kind === "part" ? "New part" : "Repair",
        sub: r.description ?? r.place ?? "",
        amount: r.amount,
      })),
    ]
      .sort((a, b) => new Date(b.at).getTime() - new Date(a.at).getTime())
      .slice(0, 14);
    return { ...v, images: imgs.get(id) ?? [], stats, timeline };
  },
  async create(b) {
    const f = vehicleFields(b);
    await ensurePlateFree(f.plate);
    const [row] = await db.insert(vehicles).values(f).returning({ id: vehicles.id });
    await syncImages("vehicle", row.id, b.images);
    return row;
  },
  async update(id, b) {
    const f = vehicleFields(b);
    await ensurePlateFree(f.plate, id);
    await db.update(vehicles).set(f).where(eq(vehicles.id, id));
    await syncImages("vehicle", id, b.images);
    return { id };
  },
  async remove(id) {
    const fuel = await db.select({ id: fuelRefills.id }).from(fuelRefills).where(eq(fuelRefills.vehicleId, id));
    const dmg = await db.select({ id: damages.id }).from(damages).where(eq(damages.vehicleId, id));
    const rep = await db.select({ id: repairs.id }).from(repairs).where(eq(repairs.vehicleId, id));
    await deleteImagesOf("fuel", ids(fuel));
    await deleteImagesOf("damage", ids(dmg));
    await deleteImagesOf("repair", ids(rep));
    await deleteImagesOf("vehicle", [id]);
    await db.delete(vehicles).where(eq(vehicles.id, id));
    return { ok: true };
  },
};

/* ═════════ drivers ═════════ */
function driverFields(b: Body) {
  return {
    name: reqStr(b, "name", "Driver name"),
    monthlySalary: optNum(b, "monthlySalary") ?? 0,
    phone: optStr(b, "phone"),
    licenseNo: optStr(b, "licenseNo"),
    licenseExpiry: optDay(b, "licenseExpiry"),
    joiningDate: optDay(b, "joiningDate"),
    details: optStr(b, "details"),
  };
}

function monthsBetween(from: string, to: string): string[] {
  const out: string[] = [];
  let [y, m] = from.split("-").map(Number);
  const [ty, tm] = to.split("-").map(Number);
  while (y < ty || (y === ty && m <= tm)) {
    out.push(`${y}-${String(m).padStart(2, "0")}`);
    m++;
    if (m > 12) {
      m = 1;
      y++;
    }
  }
  return out;
}

const driverRes: Resource = {
  async list() {
    const rows = await db.select().from(drivers).orderBy(asc(drivers.name));
    const imgs = await imagesFor("driver", ids(rows));
    return rows.map((r) => ({ ...r, images: imgs.get(r.id) ?? [] }));
  },
  async get(id) {
    const [d] = await db.select().from(drivers).where(eq(drivers.id, id));
    if (!d) throw notFound();
    const imgs = await imagesFor("driver", [id]);
    const pays = await db
      .select()
      .from(driverPayments)
      .where(eq(driverPayments.driverId, id))
      .orderBy(desc(driverPayments.at));
    const payImgs = await imagesFor("payment", ids(pays));
    const trips = await db
      .select({
        id: odometerEntries.id,
        at: odometerEntries.at,
        startKm: odometerEntries.startKm,
        stopKm: odometerEntries.stopKm,
        vehicleName: vehicles.name,
      })
      .from(odometerEntries)
      .innerJoin(vehicles, eq(vehicles.id, odometerEntries.vehicleId))
      .where(eq(odometerEntries.driverId, id))
      .orderBy(desc(odometerEntries.at))
      .limit(100);
    const allDamages = (await listDamages()).filter((x) => x.drivers.some((dr) => dr.id === id));

    // Month-wise salary summary: due = monthly salary; balance = due − fines − salary/advance paid
    const nowYm = today().slice(0, 7);
    const earliestPay = pays.length ? pays[pays.length - 1].forMonth : nowYm;
    const startYm = d.joiningDate ? d.joiningDate.slice(0, 7) : earliestPay < nowYm ? earliestPay : nowYm;
    const months = monthsBetween(startYm, nowYm)
      .slice(-24)
      .map((ym) => {
        const p = pays.filter((x) => x.forMonth === ym);
        const sum = (reasons: string[]) => p.filter((x) => reasons.includes(x.reason)).reduce((s, x) => s + x.amount, 0);
        const paid = sum(["Salary", "Advance"]);
        const deductions = sum(["Deduction/Fine"]);
        const bonus = sum(["Bonus"]);
        return { month: ym, due: d.monthlySalary, paid, deductions, bonus, balance: d.monthlySalary - deductions - paid };
      })
      .reverse();
    return {
      ...d,
      images: imgs.get(id) ?? [],
      payments: pays.map((p) => ({ ...p, images: payImgs.get(p.id) ?? [] })),
      months,
      trips,
      damages: allDamages,
      totalKm: trips.reduce((s, t) => s + (t.stopKm - t.startKm), 0),
    };
  },
  async create(b) {
    const [row] = await db.insert(drivers).values(driverFields(b)).returning({ id: drivers.id });
    await syncImages("driver", row.id, b.images);
    return row;
  },
  async update(id, b) {
    await db.update(drivers).set(driverFields(b)).where(eq(drivers.id, id));
    await syncImages("driver", id, b.images);
    return { id };
  },
  async remove(id) {
    const pays = await db.select({ id: driverPayments.id }).from(driverPayments).where(eq(driverPayments.driverId, id));
    await deleteImagesOf("payment", ids(pays));
    await deleteImagesOf("driver", [id]);
    await db.delete(drivers).where(eq(drivers.id, id));
    return { ok: true };
  },
};

/* ═════════ driver payments ═════════ */
const REASONS = ["Salary", "Advance", "Bonus", "Deduction/Fine", "Other"];
function paymentFields(b: Body) {
  const reason = optStr(b, "reason") ?? "Salary";
  if (!REASONS.includes(reason)) throw new HttpError(400, "Choose a valid reason");
  const forMonth = reqStr(b, "forMonth", "Payment month");
  if (!/^\d{4}-\d{2}$/.test(forMonth)) throw new HttpError(400, "Payment month is invalid");
  const amount = reqNum(b, "amount", "Amount");
  if (amount <= 0) throw new HttpError(400, "Amount must be greater than zero");
  return {
    at: reqDate(b, "at", "Date"),
    amount,
    paidBy: optStr(b, "paidBy"),
    reason,
    forMonth,
    details: optStr(b, "details"),
    mode: b.mode === "Online" ? "Online" : "Cash",
  };
}
const paymentRes: Resource = {
  async list(sp) {
    const did = Number(sp.get("driverId"));
    const q = db
      .select({
        id: driverPayments.id,
        driverId: driverPayments.driverId,
        at: driverPayments.at,
        amount: driverPayments.amount,
        paidBy: driverPayments.paidBy,
        reason: driverPayments.reason,
        forMonth: driverPayments.forMonth,
        mode: driverPayments.mode,
        details: driverPayments.details,
        driverName: drivers.name,
      })
      .from(driverPayments)
      .innerJoin(drivers, eq(drivers.id, driverPayments.driverId));
    const rows = await (did ? q.where(eq(driverPayments.driverId, did)) : q).orderBy(desc(driverPayments.at));
    const imgs = await imagesFor("payment", ids(rows));
    return rows.map((r) => ({ ...r, images: imgs.get(r.id) ?? [] }));
  },
  async get(id) {
    const [p] = await db.select().from(driverPayments).where(eq(driverPayments.id, id));
    if (!p) throw notFound();
    const imgs = await imagesFor("payment", [id]);
    return { ...p, images: imgs.get(id) ?? [] };
  },
  async create(b) {
    const driverId = reqNum(b, "driverId", "Driver");
    const [row] = await db
      .insert(driverPayments)
      .values({ ...paymentFields(b), driverId })
      .returning({ id: driverPayments.id });
    await syncImages("payment", row.id, b.images);
    return row;
  },
  async update(id, b) {
    await db.update(driverPayments).set(paymentFields(b)).where(eq(driverPayments.id, id));
    await syncImages("payment", id, b.images);
    return { id };
  },
  async remove(id) {
    await deleteImagesOf("payment", [id]);
    await db.delete(driverPayments).where(eq(driverPayments.id, id));
    return { ok: true };
  },
};

/* ═════════ odometer ═════════ */
function odoFields(b: Body) {
  const startKm = reqNum(b, "startKm", "Starting reading");
  const stopKm = reqNum(b, "stopKm", "Stopping reading");
  if (startKm < 0) throw new HttpError(400, "Starting reading cannot be negative");
  if (stopKm < startKm) throw new HttpError(400, "Stopping reading must be at least the starting reading");
  const at = reqDate(b, "at", "Date and time");
  return {
    vehicleId: reqNum(b, "vehicleId", "Vehicle"),
    driverId: optNum(b, "driverId"),
    at,
    day: istDay(at),
    startKm,
    stopKm,
  };
}
async function saveDayStatuses(vehicleId: number, list: unknown) {
  for (const s of (Array.isArray(list) ? list : []) as { day?: string; status?: string }[]) {
    if (!s.day || !/^\d{4}-\d{2}-\d{2}$/.test(s.day)) continue;
    if (s.status === "holiday" || s.status === "non_working") {
      await db
        .insert(dayStatuses)
        .values({ vehicleId, day: s.day, status: s.status })
        .onConflictDoUpdate({ target: [dayStatuses.vehicleId, dayStatuses.day], set: { status: s.status } });
    }
  }
}
const odometerRes: Resource = {
  list: () => listOdometer(),
  async get(id) {
    const [o] = await db.select().from(odometerEntries).where(eq(odometerEntries.id, id));
    if (!o) throw notFound();
    return o;
  },
  async create(b) {
    const f = odoFields(b);
    const [row] = await db.insert(odometerEntries).values(f).returning({ id: odometerEntries.id });
    await saveDayStatuses(f.vehicleId, b.dayStatuses);
    return row;
  },
  async update(id, b) {
    const f = odoFields(b);
    await db.update(odometerEntries).set(f).where(eq(odometerEntries.id, id));
    await saveDayStatuses(f.vehicleId, b.dayStatuses);
    return { id };
  },
  async remove(id) {
    await db.delete(odometerEntries).where(eq(odometerEntries.id, id));
    return { ok: true };
  },
};

/** Last 15 days before `at` with no odometer entry and no saved day-status, plus last stop reading. */
export async function odometerContext(vehicleId: number, at: Date, excludeId?: number) {
  const day = istDay(at);
  const lookbackStart = addDays(day, -180);
  const entries = await db
    .select({ id: odometerEntries.id, day: odometerEntries.day, stopKm: odometerEntries.stopKm, at: odometerEntries.at })
    .from(odometerEntries)
    .where(eq(odometerEntries.vehicleId, vehicleId))
    .orderBy(asc(odometerEntries.at));
  const others = excludeId ? entries.filter((e) => e.id !== excludeId) : entries;
  const filled = new Set(others.map((e) => e.day));
  const st = await db.select().from(dayStatuses).where(eq(dayStatuses.vehicleId, vehicleId));
  const marked = new Set(st.map((s) => s.day));
  const missing: string[] = [];
  for (let d = addDays(day, -1); d >= lookbackStart && missing.length < 15; d = addDays(d, -1)) {
    if (!filled.has(d) && !marked.has(d)) missing.push(d);
  }
  const before = others.filter((e) => e.at.getTime() < at.getTime());
  return {
    missing,
    lastStop: before.length ? before[before.length - 1].stopKm : null,
    kmBefore: await sumKmBefore(vehicleId, at, excludeId),
  };
}
async function sumKmBefore(vehicleId: number, at: Date, excludeId?: number) {
  const conds = [eq(odometerEntries.vehicleId, vehicleId), lt(odometerEntries.at, at)];
  if (excludeId) conds.push(ne(odometerEntries.id, excludeId));
  const [r] = await db
    .select({ km: sql<number>`coalesce(sum(${odometerEntries.stopKm} - ${odometerEntries.startKm}), 0)::float8` })
    .from(odometerEntries)
    .where(and(...conds));
  return r.km;
}

/* ═════════ fuel ═════════ */
function fuelFields(b: Body) {
  const litres = reqNum(b, "litres", "Volume");
  if (litres <= 0) throw new HttpError(400, "Volume must be greater than zero");
  return {
    vehicleId: reqNum(b, "vehicleId", "Vehicle"),
    at: reqDate(b, "at", "Date of refill"),
    fuelType: b.fuelType === "Petrol" ? "Petrol" : "Diesel",
    litres,
    odometer: reqNum(b, "odometer", "Odometer reading"),
    amount: optNum(b, "amount"),
    fullTank: b.fullTank !== false,
  };
}
async function checkFuelOdo(f: ReturnType<typeof fuelFields>, exceptId?: number) {
  const rows = await db.select().from(fuelRefills).where(eq(fuelRefills.vehicleId, f.vehicleId));
  const prev = rows
    .filter((r) => r.id !== exceptId && r.at.getTime() <= f.at.getTime())
    .sort((a, b) => b.at.getTime() - a.at.getTime())[0];
  if (prev && f.odometer < prev.odometer)
    throw new HttpError(400, `Odometer cannot be lower than the previous refill (${prev.odometer} km)`);
}
const fuelRes: Resource = {
  async list() {
    const rows = await listFuel();
    const imgs = await imagesFor("fuel", ids(rows));
    return rows.map((r) => ({ ...r, images: imgs.get(r.id) ?? [] }));
  },
  async get(id) {
    const [f] = await db.select().from(fuelRefills).where(eq(fuelRefills.id, id));
    if (!f) throw notFound();
    const imgs = await imagesFor("fuel", [id]);
    return { ...f, images: imgs.get(id) ?? [] };
  },
  async create(b) {
    const f = fuelFields(b);
    await checkFuelOdo(f);
    const [row] = await db.insert(fuelRefills).values(f).returning({ id: fuelRefills.id });
    await syncImages("fuel", row.id, b.images);
    return row;
  },
  async update(id, b) {
    const f = fuelFields(b);
    await checkFuelOdo(f, id);
    await db.update(fuelRefills).set(f).where(eq(fuelRefills.id, id));
    await syncImages("fuel", id, b.images);
    return { id };
  },
  async remove(id) {
    await deleteImagesOf("fuel", [id]);
    await db.delete(fuelRefills).where(eq(fuelRefills.id, id));
    return { ok: true };
  },
};

export async function fuelPrevious(vehicleId: number, at: Date, excludeId?: number) {
  const rows = await db
    .select({
      id: fuelRefills.id,
      vehicleId: fuelRefills.vehicleId,
      at: fuelRefills.at,
      odometer: fuelRefills.odometer,
      litres: fuelRefills.litres,
      fullTank: fuelRefills.fullTank,
      fuelType: fuelRefills.fuelType,
    })
    .from(fuelRefills)
    .where(eq(fuelRefills.vehicleId, vehicleId));
  const computed = computeFuel(rows.filter((r) => r.id !== excludeId));
  const before = computed
    .filter((r) => new Date(r.at).getTime() <= at.getTime())
    .sort((a, b) => new Date(b.at).getTime() - new Date(a.at).getTime() || b.id - a.id);
  const p = before[0];
  if (!p) return { previous: null };
  const lastGood = before.find((r) => r.mileage && !r.estimated);
  return { previous: { ...p, goodMileage: lastGood?.mileage ?? null } };
}

/* ═════════ damages ═════════ */
function damageFields(b: Body) {
  return {
    vehicleId: reqNum(b, "vehicleId", "Vehicle"),
    at: reqDate(b, "at", "Date and time"),
    description: optStr(b, "description"),
    amount: optNum(b, "amount") ?? 0,
    location: optStr(b, "location"),
    lat: optNum(b, "lat"),
    lng: optNum(b, "lng"),
  };
}
async function saveDamageDrivers(id: number, list: unknown) {
  const dids = (Array.isArray(list) ? list : []).map(Number).filter(Boolean);
  await db.delete(damageDrivers).where(eq(damageDrivers.damageId, id));
  if (dids.length) await db.insert(damageDrivers).values(dids.map((driverId) => ({ damageId: id, driverId })));
}
const damageRes: Resource = {
  async list() {
    const rows = await listDamages();
    const imgs = await imagesFor("damage", ids(rows));
    return rows.map((r) => ({ ...r, images: imgs.get(r.id) ?? [] }));
  },
  async get(id) {
    const row = (await listDamages()).find((d) => d.id === id);
    if (!row) throw notFound();
    const imgs = await imagesFor("damage", [id]);
    return { ...row, driverIds: row.drivers.map((d) => d.id), images: imgs.get(id) ?? [] };
  },
  async create(b) {
    const [row] = await db.insert(damages).values(damageFields(b)).returning({ id: damages.id });
    await saveDamageDrivers(row.id, b.driverIds);
    await syncImages("damage", row.id, b.images);
    return row;
  },
  async update(id, b) {
    await db.update(damages).set(damageFields(b)).where(eq(damages.id, id));
    await saveDamageDrivers(id, b.driverIds);
    await syncImages("damage", id, b.images);
    return { id };
  },
  async remove(id) {
    await deleteImagesOf("damage", [id]);
    await db.delete(damages).where(eq(damages.id, id));
    return { ok: true };
  },
};

/* ═════════ repairs & parts ═════════ */
function repairFields(b: Body) {
  return {
    vehicleId: reqNum(b, "vehicleId", "Vehicle"),
    at: reqDate(b, "at", "Date and time"),
    kind: b.kind === "part" ? "part" : "repair",
    amount: reqNum(b, "amount", "Amount"),
    place: optStr(b, "place"),
    description: optStr(b, "description"),
  };
}
const repairRes: Resource = {
  async list() {
    const rows = await listRepairs();
    const imgs = await imagesFor("repair", ids(rows));
    return rows.map((r) => ({ ...r, images: imgs.get(r.id) ?? [] }));
  },
  async get(id) {
    const [r] = await db.select().from(repairs).where(eq(repairs.id, id));
    if (!r) throw notFound();
    const imgs = await imagesFor("repair", [id]);
    return { ...r, images: imgs.get(id) ?? [] };
  },
  async create(b) {
    const [row] = await db.insert(repairs).values(repairFields(b)).returning({ id: repairs.id });
    await syncImages("repair", row.id, b.images);
    return row;
  },
  async update(id, b) {
    await db.update(repairs).set(repairFields(b)).where(eq(repairs.id, id));
    await syncImages("repair", id, b.images);
    return { id };
  },
  async remove(id) {
    await deleteImagesOf("repair", [id]);
    await db.delete(repairs).where(eq(repairs.id, id));
    return { ok: true };
  },
};

/* ═════════ tires ═════════ */
async function ensureTireCodeFree(code: string, exceptId?: number) {
  const dup = await db
    .select({ id: tires.id })
    .from(tires)
    .where(exceptId ? and(eq(tires.code, code), ne(tires.id, exceptId)) : eq(tires.code, code))
    .limit(1);
  if (dup.length) throw new HttpError(409, "This tire code already exists");
}
type TrailIn = { vehicleId?: number; fitDate?: string; fitOdometer?: number | string; removeDate?: string; removeOdometer?: number | string };
type TireDmgIn = { id?: number; at?: string; odometer?: number | string; note?: string; images?: unknown };

async function saveTireParts(tireId: number, b: Body) {
  // trail: replace in order
  const trail = (Array.isArray(b.trail) ? b.trail : []) as TrailIn[];
  await db.delete(tireTrail).where(eq(tireTrail.tireId, tireId));
  let seq = 1;
  let prevOdo = -1;
  for (const t of trail) {
    if (!t.vehicleId) throw new HttpError(400, `Trail entry ${seq}: choose a vehicle`);
    if (!t.fitDate) throw new HttpError(400, `Trail entry ${seq}: fitting date is required`);
    const fitOdo = optNum(t as Body, "fitOdometer");
    if (fitOdo === null) throw new HttpError(400, `Trail entry ${seq}: odometer at fitting is required`);
    const remOdo = optNum(t as Body, "removeOdometer");
    if (remOdo !== null && remOdo < fitOdo)
      throw new HttpError(400, `Trail entry ${seq}: removal odometer cannot be below fitting odometer`);
    void prevOdo;
    prevOdo = fitOdo;
    await db.insert(tireTrail).values({
      tireId,
      seq: seq++,
      vehicleId: Number(t.vehicleId),
      fitDate: t.fitDate,
      fitOdometer: fitOdo,
      removeDate: t.removeDate || null,
      removeOdometer: remOdo,
    });
  }
  // damages: keep ids, update, insert, and delete the rest
  const dm = (Array.isArray(b.damages) ? b.damages : []) as TireDmgIn[];
  const keep = dm.filter((d) => d.id).map((d) => d.id as number);
  const existing = await db.select({ id: tireDamages.id }).from(tireDamages).where(eq(tireDamages.tireId, tireId));
  const drop = existing.map((e) => e.id).filter((i) => !keep.includes(i));
  if (drop.length) {
    await deleteImagesOf("tire_damage", drop);
    await db.delete(tireDamages).where(inArray(tireDamages.id, drop));
  }
  for (const d of dm) {
    const at = reqDate(d as Body, "at", "Damage date");
    const vals = { tireId, at, odometer: optNum(d as Body, "odometer"), note: optStr(d as Body, "note") };
    let did = d.id;
    if (did) await db.update(tireDamages).set(vals).where(eq(tireDamages.id, did));
    else did = (await db.insert(tireDamages).values(vals).returning({ id: tireDamages.id }))[0].id;
    await syncImages("tire_damage", did, d.images);
  }
}

const tireRes: Resource = {
  async list() {
    const rows = await db.select().from(tires).orderBy(asc(tires.code));
    const imgs = await imagesFor("tire", ids(rows));
    const trail = rows.length
      ? await db
          .select({
            tireId: tireTrail.tireId,
            seq: tireTrail.seq,
            vehicleId: tireTrail.vehicleId,
            removeDate: tireTrail.removeDate,
            vehicleName: vehicles.name,
            plate: vehicles.plate,
          })
          .from(tireTrail)
          .innerJoin(vehicles, eq(vehicles.id, tireTrail.vehicleId))
          .orderBy(asc(tireTrail.seq))
      : [];
    const dmg = rows.length ? await db.select().from(tireDamages) : [];
    return rows.map((r) => {
      const t = trail.filter((x) => x.tireId === r.id);
      const last = t[t.length - 1];
      return {
        ...r,
        images: imgs.get(r.id) ?? [],
        currentVehicle: last && !last.removeDate ? `${last.vehicleName} (${last.plate})` : null,
        currentVehicleId: last && !last.removeDate ? last.vehicleId : null,
        lastVehicle: last ? last.vehicleName : null,
        trailCount: t.length,
        damageCount: dmg.filter((d) => d.tireId === r.id).length,
        status: dmg.some((d) => d.tireId === r.id) ? "Damaged" : "Active",
      };
    });
  },
  async get(id) {
    const [t] = await db.select().from(tires).where(eq(tires.id, id));
    if (!t) throw notFound();
    const imgs = await imagesFor("tire", [id]);
    const dm = await db.select().from(tireDamages).where(eq(tireDamages.tireId, id)).orderBy(desc(tireDamages.at));
    const dmImgs = await imagesFor("tire_damage", ids(dm));
    const trail = await db.select().from(tireTrail).where(eq(tireTrail.tireId, id)).orderBy(asc(tireTrail.seq));
    return {
      ...t,
      images: imgs.get(id) ?? [],
      damages: dm.map((d) => ({ ...d, images: dmImgs.get(d.id) ?? [] })),
      trail,
    };
  },
  async create(b) {
    const code = reqStr(b, "code", "Tire code");
    await ensureTireCodeFree(code);
    const [row] = await db.insert(tires).values({ code }).returning({ id: tires.id });
    await syncImages("tire", row.id, b.images);
    await saveTireParts(row.id, b);
    return row;
  },
  async update(id, b) {
    const code = reqStr(b, "code", "Tire code");
    await ensureTireCodeFree(code, id);
    await db.update(tires).set({ code }).where(eq(tires.id, id));
    await syncImages("tire", id, b.images);
    await saveTireParts(id, b);
    return { id };
  },
  async remove(id) {
    const dm = await db.select({ id: tireDamages.id }).from(tireDamages).where(eq(tireDamages.tireId, id));
    await deleteImagesOf("tire_damage", ids(dm));
    await deleteImagesOf("tire", [id]);
    await db.delete(tires).where(eq(tires.id, id));
    return { ok: true };
  },
};

export const resources: Record<string, Resource> = {
  vehicles: vehicleRes,
  drivers: driverRes,
  odometer: odometerRes,
  fuel: fuelRes,
  damages: damageRes,
  tires: tireRes,
  repairs: repairRes,
  payments: paymentRes,
};

// keep unused imports referenced for tree-shaking clarity
void notInArray;
void images;
void diffDays;
