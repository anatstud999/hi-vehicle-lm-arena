import { and, eq, inArray, asc } from "drizzle-orm";
import { db } from "@/db";
import { images } from "@/db/schema";

export class HttpError extends Error {
  constructor(
    public status: number,
    message: string,
  ) {
    super(message);
  }
}

/** Wraps a handler so thrown HttpErrors become friendly JSON responses. */
export async function handle(fn: () => Promise<unknown>): Promise<Response> {
  try {
    const out = await fn();
    return Response.json(out ?? { ok: true });
  } catch (e) {
    if (e instanceof HttpError) return Response.json({ error: e.message }, { status: e.status });
    console.error(e);
    return Response.json({ error: "Something went wrong. Please try again." }, { status: 500 });
  }
}

type Body = Record<string, unknown>;

export function reqStr(b: Body, k: string, label: string): string {
  const v = typeof b[k] === "string" ? (b[k] as string).trim() : "";
  if (!v) throw new HttpError(400, `${label} is required`);
  return v;
}
export function optStr(b: Body, k: string): string | null {
  const v = typeof b[k] === "string" ? (b[k] as string).trim() : "";
  return v || null;
}
export function reqNum(b: Body, k: string, label: string): number {
  const raw = b[k];
  const v = typeof raw === "number" ? raw : typeof raw === "string" && raw.trim() !== "" ? Number(raw) : NaN;
  if (!Number.isFinite(v)) throw new HttpError(400, `${label} is required`);
  return v;
}
export function optNum(b: Body, k: string): number | null {
  const raw = b[k];
  if (raw === null || raw === undefined || raw === "") return null;
  const v = Number(raw);
  return Number.isFinite(v) ? v : null;
}
export function reqDate(b: Body, k: string, label: string): Date {
  const raw = b[k];
  const d = typeof raw === "string" ? new Date(raw) : null;
  if (!d || Number.isNaN(d.getTime())) throw new HttpError(400, `${label} is required`);
  return d;
}
export function optDay(b: Body, k: string): string | null {
  const v = optStr(b, k);
  return v && /^\d{4}-\d{2}-\d{2}$/.test(v) ? v : null;
}

/* ───────── images ───────── */
export type ImgIn = { id?: number; title?: string; thumb?: string; data?: string; isCover?: boolean };
export type ImgMeta = { id: number; title: string | null; thumb: string; isCover: boolean };

export async function imagesFor(ownerType: string, ownerIds: number[]): Promise<Map<number, ImgMeta[]>> {
  const map = new Map<number, ImgMeta[]>();
  if (!ownerIds.length) return map;
  const rows = await db
    .select({
      id: images.id,
      ownerId: images.ownerId,
      title: images.title,
      thumb: images.thumb,
      isCover: images.isCover,
    })
    .from(images)
    .where(and(eq(images.ownerType, ownerType), inArray(images.ownerId, ownerIds)))
    .orderBy(asc(images.sort), asc(images.id));
  for (const r of rows) {
    const arr = map.get(r.ownerId) ?? [];
    arr.push({ id: r.id, title: r.title, thumb: r.thumb, isCover: r.isCover });
    map.set(r.ownerId, arr);
  }
  return map;
}

/** Keeps images listed with an id, uploads new ones, removes the rest, stores order and cover flag. */
export async function syncImages(ownerType: string, ownerId: number, list: unknown) {
  const items = (Array.isArray(list) ? list : []) as ImgIn[];
  const keep = items.filter((i) => i.id).map((i) => i.id as number);
  const existing = await db
    .select({ id: images.id })
    .from(images)
    .where(and(eq(images.ownerType, ownerType), eq(images.ownerId, ownerId)));
  const drop = existing.map((e) => e.id).filter((id) => !keep.includes(id));
  if (drop.length) await db.delete(images).where(inArray(images.id, drop));
  for (let i = 0; i < items.length; i++) {
    const it = items[i];
    const title = (it.title ?? "").trim() || null;
    if (it.id) {
      await db
        .update(images)
        .set({ title, sort: i, isCover: !!it.isCover })
        .where(and(eq(images.id, it.id), eq(images.ownerType, ownerType), eq(images.ownerId, ownerId)));
    } else if (typeof it.data === "string" && it.data.startsWith("data:image/")) {
      await db.insert(images).values({
        ownerType,
        ownerId,
        title,
        thumb: it.thumb || it.data,
        data: it.data,
        sort: i,
        isCover: !!it.isCover,
      });
    }
  }
}

export async function deleteImagesOf(ownerType: string, ownerIds: number[]) {
  if (!ownerIds.length) return;
  await db.delete(images).where(and(eq(images.ownerType, ownerType), inArray(images.ownerId, ownerIds)));
}
