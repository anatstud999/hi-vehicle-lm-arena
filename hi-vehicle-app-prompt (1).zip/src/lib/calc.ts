// Fuel maths shared by lists, forms, reports and data sheets.
export type FuelBase = {
  id: number;
  vehicleId: number;
  at: Date | string;
  odometer: number;
  litres: number;
  fullTank: boolean;
};

export type FuelComputed<T extends FuelBase> = T & {
  prevId: number | null;
  prevAt: string | null;
  prevOdometer: number | null;
  prevLitres: number | null;
  distance: number | null;
  mileage: number | null; // km/L
  estimated: boolean; // true when tank was not filled to full
  prevMileage: number | null; // last non-estimated mileage before this refill
};

/** Computes distance and km/L for each refill against the previous refill of the same vehicle. */
export function computeFuel<T extends FuelBase>(rows: T[]): FuelComputed<T>[] {
  const byVehicle = new Map<number, T[]>();
  for (const r of rows) {
    const arr = byVehicle.get(r.vehicleId) ?? [];
    arr.push(r);
    byVehicle.set(r.vehicleId, arr);
  }
  const out: FuelComputed<T>[] = [];
  for (const list of byVehicle.values()) {
    list.sort((a, b) => new Date(a.at).getTime() - new Date(b.at).getTime() || a.id - b.id);
    let prev: T | null = null;
    let lastGood: number | null = null;
    for (const r of list) {
      const distance = prev ? r.odometer - prev.odometer : null;
      const mileage = distance !== null && distance > 0 && r.litres > 0 ? distance / r.litres : null;
      out.push({
        ...r,
        prevId: prev?.id ?? null,
        prevAt: prev ? new Date(prev.at).toISOString() : null,
        prevOdometer: prev?.odometer ?? null,
        prevLitres: prev?.litres ?? null,
        distance,
        mileage,
        estimated: !r.fullTank,
        prevMileage: lastGood,
      });
      if (mileage !== null && r.fullTank) lastGood = mileage;
      prev = r;
    }
  }
  return out;
}
