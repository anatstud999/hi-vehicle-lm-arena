// Shared formatting helpers (client + server). All calendar logic uses India Standard Time.
export const TZ = "Asia/Kolkata";

const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

/** ₹1,23,456.50 */
export function inr(n: number | null | undefined): string {
  if (n === null || n === undefined || Number.isNaN(n)) return "—";
  return new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    minimumFractionDigits: Number.isInteger(n) ? 0 : 2,
    maximumFractionDigits: 2,
  }).format(n);
}

/** Indian digit grouping for plain numbers */
export function num(n: number | null | undefined, digits = 0): string {
  if (n === null || n === undefined || Number.isNaN(n)) return "—";
  return new Intl.NumberFormat("en-IN", { minimumFractionDigits: 0, maximumFractionDigits: digits }).format(n);
}

/** yyyy-mm-dd in IST */
export function istDay(d: Date | string | number): string {
  return new Date(d).toLocaleDateString("en-CA", { timeZone: TZ });
}

/** 08 Nov 2026 */
export function fmtDate(d: Date | string | null | undefined): string {
  if (!d) return "—";
  const day = typeof d === "string" && /^\d{4}-\d{2}-\d{2}$/.test(d) ? d : istDay(d);
  const [y, m, dd] = day.split("-");
  return `${dd} ${MONTHS[Number(m) - 1]} ${y}`;
}

/** 10:30 AM */
export function fmtTime(d: Date | string | null | undefined): string {
  if (!d) return "—";
  return new Date(d)
    .toLocaleTimeString("en-US", { timeZone: TZ, hour: "numeric", minute: "2-digit", hour12: true })
    .replace(/\u202f/g, " ");
}

export function fmtDateTime(d: Date | string | null | undefined): string {
  if (!d) return "—";
  return `${fmtDate(d)}, ${fmtTime(d)}`;
}

/** Value for <input type="datetime-local"> in IST */
export function toInputValue(d: Date | string | number = new Date()): string {
  const dt = new Date(d);
  const day = istDay(dt);
  const t = dt.toLocaleTimeString("en-GB", { timeZone: TZ, hour: "2-digit", minute: "2-digit", hour12: false });
  return `${day}T${t === "24:00" ? "00:00" : t}`;
}

export function fromInputValue(v: string): string {
  return new Date(`${v}:00+05:30`).toISOString();
}

export function addDays(day: string, n: number): string {
  const d = new Date(`${day}T00:00:00Z`);
  d.setUTCDate(d.getUTCDate() + n);
  return d.toISOString().slice(0, 10);
}

export function diffDays(a: string, b: string): number {
  return Math.round((new Date(`${b}T00:00:00Z`).getTime() - new Date(`${a}T00:00:00Z`).getTime()) / 86400000);
}

export function monthLabel(ym: string): string {
  const [y, m] = ym.split("-");
  return `${MONTHS[Number(m) - 1]} ${y}`;
}

export function today(): string {
  return istDay(new Date());
}

export function pct(n: number, digits = 0): string {
  return `${n.toFixed(digits)}%`;
}

export function cn(...parts: (string | false | null | undefined)[]): string {
  return parts.filter(Boolean).join(" ");
}
