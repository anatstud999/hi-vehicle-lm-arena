import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { AppShell } from "@/components/AppShell";
import { Splash } from "@/components/Splash";
import { ToastProvider } from "@/components/ui";
import { ViewerProvider } from "@/components/ImageViewer";

export const metadata: Metadata = {
  title: "HI VEHICLE — Fleet ledger",
  description: "Track vehicles, odometer, fuel, damages, tires, repairs and drivers in one calm ledger.",
  applicationName: "HI VEHICLE",
  appleWebApp: { capable: true, title: "HI VEHICLE", statusBarStyle: "default" },
};
export const viewport: Viewport = {
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#F6F1E7" },
    { media: "(prefers-color-scheme: dark)", color: "#121C18" },
  ],
  width: "device-width",
  initialScale: 1,
};

// Applies the saved theme before first paint to avoid a flash.
const themeScript = `try{var t=localStorage.getItem('hv-theme');if(t==='light'||t==='dark')document.documentElement.dataset.theme=t;}catch(e){}`;

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: themeScript }} />
      </head>
      <body className="antialiased">
        <ToastProvider>
          <ViewerProvider>
            <Splash />
            <AppShell>{children}</AppShell>
          </ViewerProvider>
        </ToastProvider>
      </body>
    </html>
  );
}
