import { db } from "@/db";
import {
  damageDrivers, damages, dayStatuses, driverPayments, drivers, fuelRefills, images, odometerEntries,
  repairs, tireDamages, tireTrail, tires, vehicles,
} from "@/db/schema";

export const dynamic = "force-dynamic";

/** Full JSON backup. Add ?images=1 to include original image data. */
export async function GET(req: Request) {
  const withImages = new URL(req.url).searchParams.get("images") === "1";
  const imgs = await db.select().from(images);
  const data = {
    app: "HI VEHICLE",
    exportedAt: new Date().toISOString(),
    vehicles: await db.select().from(vehicles),
    drivers: await db.select().from(drivers),
    odometerEntries: await db.select().from(odometerEntries),
    dayStatuses: await db.select().from(dayStatuses),
    fuelRefills: await db.select().from(fuelRefills),
    damages: await db.select().from(damages),
    damageDrivers: await db.select().from(damageDrivers),
    tires: await db.select().from(tires),
    tireDamages: await db.select().from(tireDamages),
    tireTrail: await db.select().from(tireTrail),
    repairs: await db.select().from(repairs),
    driverPayments: await db.select().from(driverPayments),
    images: imgs.map((i) => (withImages ? i : { ...i, data: undefined })),
  };
  return new Response(JSON.stringify(data, null, 2), {
    headers: {
      "Content-Type": "application/json",
      "Content-Disposition": `attachment; filename="hi-vehicle-backup-${new Date().toISOString().slice(0, 10)}.json"`,
    },
  });
}
