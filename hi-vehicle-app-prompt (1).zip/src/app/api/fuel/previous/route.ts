import { handle, HttpError } from "@/lib/server/http";
import { fuelPrevious } from "@/lib/server/resources";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  return handle(async () => {
    const sp = new URL(req.url).searchParams;
    const vehicleId = Number(sp.get("vehicleId"));
    const at = new Date(sp.get("at") ?? "");
    if (!vehicleId || Number.isNaN(at.getTime())) throw new HttpError(400, "vehicleId and at are required");
    return fuelPrevious(vehicleId, at, Number(sp.get("excludeId")) || undefined);
  });
}
