import { handle, HttpError } from "@/lib/server/http";
import { resources } from "@/lib/server/resources";

export const dynamic = "force-dynamic";
type Ctx = { params: Promise<{ resource: string }> };

async function pick(ctx: Ctx) {
  const { resource } = await ctx.params;
  const r = resources[resource];
  if (!r) throw new HttpError(404, "Unknown resource");
  return r;
}

export async function GET(req: Request, ctx: Ctx) {
  return handle(async () => (await pick(ctx)).list(new URL(req.url).searchParams));
}
export async function POST(req: Request, ctx: Ctx) {
  return handle(async () => (await pick(ctx)).create(await req.json()));
}
