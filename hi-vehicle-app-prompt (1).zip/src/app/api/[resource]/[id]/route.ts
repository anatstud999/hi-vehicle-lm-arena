import { handle, HttpError } from "@/lib/server/http";
import { resources } from "@/lib/server/resources";

export const dynamic = "force-dynamic";
type Ctx = { params: Promise<{ resource: string; id: string }> };

async function pick(ctx: Ctx) {
  const { resource, id } = await ctx.params;
  const r = resources[resource];
  const n = Number(id);
  if (!r || !Number.isInteger(n)) throw new HttpError(404, "Unknown record");
  return { r, id: n };
}

export async function GET(_req: Request, ctx: Ctx) {
  return handle(async () => {
    const { r, id } = await pick(ctx);
    return r.get(id);
  });
}
export async function PUT(req: Request, ctx: Ctx) {
  return handle(async () => {
    const { r, id } = await pick(ctx);
    return r.update(id, await req.json());
  });
}
export async function DELETE(_req: Request, ctx: Ctx) {
  return handle(async () => {
    const { r, id } = await pick(ctx);
    return r.remove(id);
  });
}
