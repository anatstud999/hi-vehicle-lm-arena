import { db } from "@/db";
import { dayStatuses, fuelRefills, odometerEntries, vehicles } from "@/db/schema";
import { addDays, istDay, today } from "@/lib/format";
import { handle } from "@/lib/server/http";
import { listDamages, listOdometer, listRepairs } from "@/lib/server/resources";

export const dynamic = "force-dynamic";

export async function GET() {
  return handle(async () => {
    const day = today();
    const monthStart = `${day.slice(0, 7)}-01`;
    const [vs, odo, fuel, dmg, rep, st] = await Promise.all([
      db.select().from(vehicles),
      db.select().from(odometerEntries),
      db.select().from(fuelRefills),
      listDamages(),
      listRepairs(),
      db.select().from(dayStatuses),
    ]);
    const inMonth = (at: Date | string) => istDay(at) >= monthStart;
    const kmMonth = odo.filter((o) => o.day >= monthStart).reduce((s, o) => s + (o.stopKm - o.startKm), 0);
    const fuelM = fuel.filter((f) => inMonth(f.at));
    const litres = fuelM.reduce((s, f) => s + f.litres, 0);
    const fuelCost = fuelM.reduce((s, f) => s + (f.amount ?? 0), 0);
    const spend =
      fuelCost +
      dmg.filter((d) => inMonth(d.at)).reduce((s, d) => s + d.amount, 0) +
      rep.filter((r) => inMonth(r.at)).reduce((s, r) => s + r.amount, 0);

    // missing odometer days in the last 7 days (before today), per vehicle
    const alerts: { vehicleId: number; name: string; plate: string; days: number }[] = [];
    for (const v of vs) {
      const created = istDay(v.createdAt);
      const filled = new Set(odo.filter((o) => o.vehicleId === v.id).map((o) => o.day));
      const marked = new Set(st.filter((s) => s.vehicleId === v.id).map((s) => s.day));
      let n = 0;
      for (let i = 1; i <= 7; i++) {
        const d = addDays(day, -i);
        if (d >= created && !filled.has(d) && !marked.has(d)) n++;
      }
      if (n > 0) alerts.push({ vehicleId: v.id, name: v.name, plate: v.plate, days: n });
    }

    const recentOdo = (await listOdometer()).slice(0, 5).map((o) => ({
      type: "odometer",
      at: o.at,
      title: `${o.vehicleName} · ${Math.round(o.km)} km`,
      sub: o.driverName ?? "No driver",
    }));
    return {
      vehicles: vs.length,
      kmMonth,
      litres,
      fuelCost,
      spend,
      alerts,
      recent: [
        ...recentOdo,
        ...dmg.slice(0, 3).map((d) => ({ type: "damage", at: d.at, title: `${d.vehicleName} · damage`, sub: d.description ?? "" })),
        ...rep.slice(0, 3).map((r) => ({
          type: r.kind,
          at: r.at,
          title: `${r.vehicleName} · ${r.kind === "part" ? "new part" : "repair"}`,
          sub: r.description ?? r.place ?? "",
        })),
      ]
        .sort((a, b) => new Date(b.at).getTime() - new Date(a.at).getTime())
        .slice(0, 6),
    };
  });
}
