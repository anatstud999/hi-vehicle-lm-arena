import { handle, HttpError } from "@/lib/server/http";
import { buildReport } from "@/lib/server/reports";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  return handle(async () => {
    const sp = new URL(req.url).searchParams;
    const from = sp.get("from") ?? "";
    const to = sp.get("to") ?? "";
    if (!/^\d{4}-\d{2}-\d{2}$/.test(from) || !/^\d{4}-\d{2}-\d{2}$/.test(to) || from > to)
      throw new HttpError(400, "Choose a valid period");
    const ids = (sp.get("vehicleIds") ?? "").split(",").map(Number).filter(Boolean);
    return buildReport(ids, from, to);
  });
}
