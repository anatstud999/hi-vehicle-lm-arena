import { eq } from "drizzle-orm";
import { db } from "@/db";
import { images } from "@/db/schema";

export const dynamic = "force-dynamic";

/** Serves the full-resolution original of an image (thumbnails travel with list responses). */
export async function GET(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const [img] = await db.select({ data: images.data }).from(images).where(eq(images.id, Number(id)));
  if (!img) return new Response("Not found", { status: 404 });
  const m = img.data.match(/^data:([^;]+);base64,([\s\S]*)$/);
  if (!m) return new Response("Bad image", { status: 500 });
  return new Response(Buffer.from(m[2], "base64"), {
    headers: { "Content-Type": m[1], "Cache-Control": "private, max-age=31536000, immutable" },
  });
}
