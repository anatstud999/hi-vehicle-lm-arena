import { handle } from "@/lib/server/http";
import { lockAction, lockStatus } from "@/lib/server/lock";

export const dynamic = "force-dynamic";

export async function GET() {
  return handle(() => lockStatus());
}
export async function POST(req: Request) {
  return handle(async () => lockAction(await req.json()));
}
