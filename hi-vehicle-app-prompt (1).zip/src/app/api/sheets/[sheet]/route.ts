import { handle, HttpError } from "@/lib/server/http";
import { requireUnlocked } from "@/lib/server/lock";
import { deleteSheetRows, isSheet, sheetData } from "@/lib/server/sheets";

export const dynamic = "force-dynamic";
type Ctx = { params: Promise<{ sheet: string }> };

async function key(ctx: Ctx) {
  const { sheet } = await ctx.params;
  if (!isSheet(sheet)) throw new HttpError(404, "Unknown sheet");
  await requireUnlocked();
  return sheet;
}

export async function GET(_req: Request, ctx: Ctx) {
  return handle(async () => sheetData(await key(ctx)));
}
export async function DELETE(req: Request, ctx: Ctx) {
  return handle(async () => {
    const k = await key(ctx);
    const body = (await req.json()) as { ids?: number[] };
    await deleteSheetRows(k, (body.ids ?? []).map(Number).filter(Boolean));
    return { ok: true };
  });
}
