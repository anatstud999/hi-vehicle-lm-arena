import { handle, HttpError } from "@/lib/server/http";
import { requireUnlocked } from "@/lib/server/lock";
import { importRows, isSheet } from "@/lib/server/sheets";

export const dynamic = "force-dynamic";

export async function POST(req: Request, ctx: { params: Promise<{ sheet: string }> }) {
  return handle(async () => {
    const { sheet } = await ctx.params;
    if (!isSheet(sheet)) throw new HttpError(404, "Unknown sheet");
    await requireUnlocked();
    const body = (await req.json()) as { rows?: Record<string, string>[]; commit?: boolean };
    return importRows(sheet, body.rows ?? [], !!body.commit);
  });
}
