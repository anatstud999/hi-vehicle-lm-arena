import type { MetadataRoute } from "next";

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "HI VEHICLE",
    short_name: "HI VEHICLE",
    description: "Fleet ledger for vehicle owners",
    start_url: "/",
    display: "standalone",
    background_color: "#F6F1E7",
    theme_color: "#3F6B5B",
    icons: [
      { src: "/icon.svg", sizes: "any", type: "image/svg+xml", purpose: "any" },
      { src: "/icon.svg", sizes: "any", type: "image/svg+xml", purpose: "maskable" },
    ],
  };
}
