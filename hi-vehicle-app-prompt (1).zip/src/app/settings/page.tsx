"use client";
import { useEffect, useState } from "react";
import { api, useFetch } from "@/lib/client";
import { Group, TextField } from "@/components/fields";
import { Icon, PageTitle, Segmented, Switch, useToast } from "@/components/ui";

type Theme = "system" | "light" | "dark";

export default function SettingsPage() {
  const toast = useToast();
  const [theme, setTheme] = useState<Theme>("system");
  const lock = useFetch<{ configured: boolean }>("/api/lock");
  const [old, setOld] = useState("");
  const [next, setNext] = useState("");
  const [conf, setConf] = useState("");
  const [err, setErr] = useState<string | null>(null);
  const [withImages, setWithImages] = useState(false);

  useEffect(() => {
    const t = localStorage.getItem("hv-theme");
    setTheme(t === "light" || t === "dark" ? t : "system");
  }, []);

  function applyTheme(t: Theme) {
    setTheme(t);
    if (t === "system") {
      localStorage.removeItem("hv-theme");
      delete document.documentElement.dataset.theme;
    } else {
      localStorage.setItem("hv-theme", t);
      document.documentElement.dataset.theme = t;
    }
  }

  async function changePw() {
    setErr(null);
    try {
      await api("/api/lock", { body: { action: "change", old, next, confirm: conf } });
      toast.show("Master password changed");
      setOld("");
      setNext("");
      setConf("");
    } catch (e) {
      setErr((e as Error).message);
    }
  }

  return (
    <div className="space-y-4 pb-4">
      <PageTitle title="Settings" />

      <Group title="Profile" index={0}>
        <div className="flex items-center gap-4">
          <div className="serif flex h-16 w-16 items-center justify-center rounded-full border border-gold bg-primary text-2xl font-bold text-onp">HV</div>
          <div>
            <div className="serif text-2xl font-semibold">Fleet owner</div>
            <div className="text-sm text-muted">Data is stored securely in this app&apos;s database.</div>
          </div>
        </div>
      </Group>

      <Group title="Theme" index={1}>
        <Segmented<Theme>
          value={theme}
          onChange={applyTheme}
          options={[
            { value: "light", label: "Light" },
            { value: "dark", label: "Dark" },
            { value: "system", label: "System" },
          ]}
        />
      </Group>

      <Group title="Master password" index={2}>
        {lock.data?.configured ? (
          <>
            <p className="-mt-1 text-sm text-muted">Protects the Data Sheets. Changing it needs the current password.</p>
            <TextField label="Current password" type="password" value={old} onChange={setOld} />
            <TextField label="New password" type="password" value={next} onChange={setNext} />
            <TextField label="Confirm new password" type="password" value={conf} onChange={setConf} error={err} />
            <button className="btn btn-primary w-full" onClick={changePw}>
              <Icon name="lock" size={18} /> Change password
            </button>
          </>
        ) : (
          <p className="text-sm text-muted">No master password yet. You&apos;ll create one the first time you open Data Sheets.</p>
        )}
      </Group>

      <Group title="Backup" index={3}>
        <div className="flex items-center justify-between gap-3">
          <span className="text-sm">Include full-size images</span>
          <Switch checked={withImages} onChange={setWithImages} label="Include full-size images" />
        </div>
        <a className="btn btn-soft w-full" href={`/api/backup${withImages ? "?images=1" : ""}`} download>
          <Icon name="download" size={18} /> Export JSON backup
        </a>
      </Group>

      <Group title="About" index={4}>
        <p className="text-sm text-muted">
          <b className="serif text-lg text-ink">HI VEHICLE</b> — a calm ledger for bus and vehicle owners. Amounts in ₹ with Indian digit grouping; dates in IST.
        </p>
        <p className="text-xs text-muted">Install it on your phone from the browser menu (&ldquo;Add to Home screen&rdquo;) for a full-screen app experience.</p>
      </Group>
    </div>
  );
}
