import { SheetsView } from "@/components/SheetsView";

export default function Page() {
  return <SheetsView />;
}
