import { notFound } from "next/navigation";
import { PaymentForm } from "@/components/forms/basic";

export default async function Page({ params }: { params: Promise<{ module: string; id: string }> }) {
  const { module, id } = await params;
  if (module !== "drivers") notFound();
  return <PaymentForm driverId={Number(id)} />;
}
