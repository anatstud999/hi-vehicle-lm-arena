import { ModuleForm } from "@/components/forms/registry";

export default async function Page({ params }: { params: Promise<{ module: string; id: string }> }) {
  const { module, id } = await params;
  return <ModuleForm module={module} id={Number(id)} />;
}
