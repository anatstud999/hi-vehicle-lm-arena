import { notFound, redirect } from "next/navigation";
import { VehicleDetail } from "@/components/details/VehicleDetail";
import { DriverDetail } from "@/components/details/DriverDetail";

export default async function Page({ params }: { params: Promise<{ module: string; id: string }> }) {
  const { module, id } = await params;
  const n = Number(id);
  if (!Number.isInteger(n)) notFound();
  if (module === "vehicles") return <VehicleDetail id={n} />;
  if (module === "drivers") return <DriverDetail id={n} />;
  redirect(`/${module}/${n}/edit`);
}
