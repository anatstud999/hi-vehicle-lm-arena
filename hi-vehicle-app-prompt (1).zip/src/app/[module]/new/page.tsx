import { ModuleForm } from "@/components/forms/registry";

export default async function Page({ params }: { params: Promise<{ module: string }> }) {
  const { module } = await params;
  return <ModuleForm module={module} />;
}
