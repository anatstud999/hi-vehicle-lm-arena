import { notFound } from "next/navigation";
import { ModuleList } from "@/components/lists";

const LISTED = ["vehicles", "odometer", "fuel", "damages", "tires", "repairs", "drivers"];

export default async function Page({ params }: { params: Promise<{ module: string }> }) {
  const { module } = await params;
  if (!LISTED.includes(module)) notFound();
  return <ModuleList module={module} />;
}
