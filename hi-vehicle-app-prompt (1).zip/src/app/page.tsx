"use client";
import Link from "next/link";
import { useFetch } from "@/lib/client";
import { fmtDateTime, inr, num } from "@/lib/format";
import { Card, EmptyState, ErrorBox, Icon, Skeleton, StatCard } from "@/components/ui";

type Dash = {
  vehicles: number;
  kmMonth: number;
  litres: number;
  fuelCost: number;
  spend: number;
  alerts: { vehicleId: number; name: string; plate: string; days: number }[];
  recent: { type: string; at: string; title: string; sub: string }[];
};

const MODULES = [
  { href: "/vehicles", label: "Vehicles", icon: "bus" },
  { href: "/odometer", label: "Odometer", icon: "gauge" },
  { href: "/fuel", label: "Fuel", icon: "fuel" },
  { href: "/damages", label: "Damages", icon: "alert" },
  { href: "/tires", label: "Tires", icon: "tire" },
  { href: "/repairs", label: "Repairs & Parts", icon: "wrench" },
  { href: "/reports", label: "Reports", icon: "chart" },
  { href: "/drivers", label: "Drivers", icon: "users" },
  { href: "/sheets", label: "Data Sheets", icon: "table" },
];
const ICON: Record<string, string> = { odometer: "gauge", damage: "alert", repair: "wrench", part: "wrench" };

function greeting() {
  const h = Number(new Date().toLocaleString("en-GB", { timeZone: "Asia/Kolkata", hour: "2-digit", hour12: false }));
  return h < 12 ? "Good morning" : h < 17 ? "Good afternoon" : "Good evening";
}

export default function Home() {
  const { data, error, loading, reload } = useFetch<Dash>("/api/dashboard");
  return (
    <div>
      <div className="rise mb-6 flex items-center gap-4">
        <div className="serif flex h-14 w-14 items-center justify-center rounded-full border border-gold bg-primary text-xl font-bold text-onp">HV</div>
        <div>
          <p className="text-sm text-muted">{greeting()}</p>
          <h1 className="text-[32px] font-semibold leading-none">Your fleet today</h1>
          <div className="gold-rule mt-2" />
        </div>
      </div>

      {loading && !data && <Skeleton rows={3} />}
      {error && <ErrorBox message={error} retry={reload} />}
      {data && (
        <>
          <div className="grid grid-cols-2 gap-3">
            <StatCard index={0} label="Vehicles" value={data.vehicles} icon="bus" />
            <StatCard index={1} label="Km this month" value={data.kmMonth} format={(n) => num(n, 0)} icon="gauge" />
            <StatCard index={2} label="Fuel this month" value={data.litres} format={(n) => `${num(n, 1)} L`} icon="fuel" hint={data.fuelCost ? inr(data.fuelCost) : undefined} />
            <StatCard index={3} label="Spend this month" value={data.spend} format={(n) => inr(Math.round(n))} icon="coin" gold />
          </div>

          {data.alerts.length > 0 && (
            <Card className="rise mt-4 border-warn/60 p-4" style={{ ["--i" as string]: 4 }}>
              <div className="flex items-center gap-2 font-semibold text-warn">
                <Icon name="alert" size={20} /> Odometer readings missing
              </div>
              <ul className="mt-2 space-y-1.5">
                {data.alerts.slice(0, 4).map((a) => (
                  <li key={a.vehicleId}>
                    <Link href="/odometer/new" className="flex items-center justify-between rounded-xl px-1 py-1 text-sm">
                      <span><b>{a.name}</b> <span className="text-muted">· {a.plate}</span></span>
                      <span className="text-muted">{a.days} day{a.days > 1 ? "s" : ""} in the last week</span>
                    </Link>
                  </li>
                ))}
              </ul>
            </Card>
          )}
        </>
      )}

      <h2 className="mb-3 mt-8 text-2xl font-semibold">Modules</h2>
      <div className="grid grid-cols-3 gap-3">
        {MODULES.map((m, i) => (
          <Link key={m.href} href={m.href} className="card rise flex aspect-square flex-col items-center justify-center gap-2 p-2 text-center transition active:scale-95" style={{ ["--i" as string]: i + 4 }}>
            <span className="flex h-12 w-12 items-center justify-center rounded-full bg-pc text-primary">
              <Icon name={m.icon} size={24} />
            </span>
            <span className="text-[13px] font-semibold leading-tight">{m.label}</span>
          </Link>
        ))}
      </div>

      {data && (
        <>
          <h2 className="mb-3 mt-8 text-2xl font-semibold">Recent activity</h2>
          {!data.recent.length ? (
            <EmptyState text="Your ledger is blank. Add a vehicle and log its first trip." action={<Link href="/vehicles/new" className="btn btn-primary">Add vehicle</Link>} />
          ) : (
            <div className="space-y-2">
              {data.recent.map((r, i) => (
                <Card key={i} className="rise flex items-center gap-3 p-3.5" style={{ ["--i" as string]: i }}>
                  <span className="flex h-10 w-10 items-center justify-center rounded-full bg-pc text-primary">
                    <Icon name={ICON[r.type] ?? "dots"} size={18} />
                  </span>
                  <div className="min-w-0">
                    <div className="truncate font-semibold">{r.title}</div>
                    <div className="truncate text-xs text-muted">{fmtDateTime(r.at)}{r.sub ? ` · ${r.sub}` : ""}</div>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </>
      )}
    </div>
  );
}
