# HI VEHICLE

A calm, "Sage & Parchment" fleet ledger for bus and vehicle owners — vehicles, odometer logs, fuel refills,
damages, tires, repairs & parts, drivers & payments, deep reports with PDF export, and password-protected
data sheets.

> **Platform note.** This project was built in a Next.js + PostgreSQL (Drizzle) environment, so it ships as a
> mobile-first **installable web app (PWA)** rather than a native Android `.apk`. Open it on a phone and use
> *Add to Home screen* for a full-screen app. To produce a real APK from it later, wrap the deployed URL with
> a Trusted Web Activity (Bubblewrap) or Capacitor.

## Run

```bash
npm install
npx drizzle-kit push      # creates the tables in DATABASE_URL (see .env)
npm run build && npm start
```

## What is implemented

| Area | Notes |
| --- | --- |
| Design | Sage & Parchment tokens (light + dark, system default), serif headings, tabular numerals, paper grain, reduced-motion support, splash animation, staggered entrances, spring sheets, count-ups, chart draw-ins, shimmer skeletons, success check |
| Home | Greeting, 4 fleet tiles, missing-odometer alert, 9 module cards, recent activity, bottom nav with quick-add speed dial |
| Vehicles | List (search / type filter / sort), detail with carousel, stats and timeline, form with cover image, unique upper-cased plate, custom types |
| Odometer | Vehicle + date, last-15 missing days with Holiday / Non-working / No information (persisted as day-status), driver, start auto-fill + warning, live trip and running total |
| Fuel | Previous-refill card, distance, km/L (full-tank method, “estimated” when not full and excluded from averages), up/down delta, odometer validation |
| Damages | Multi-driver, unlimited titled images, location text + GPS pin |
| Tires | Unique code, images, **Damage / Trail** map with animated fitment timeline and km-per-vehicle / tire life |
| Repairs & Parts | Repair (clay) vs New Part (sage) chips |
| Reports | Multi-vehicle select, 6 periods, every metric in the brief, line / donut / stacked-bar charts, insights, comparison table + fleet total, **Export PDF** (print-to-PDF with branded cover, page numbers, include-images switch) |
| Drivers | Profile with Overview / Payments / Activity, payment form (reason, month, mode, images), month-wise due / paid / balance |
| Data Sheets | Master password (scrypt hash + salt, hint), 2-minute auto-lock, change & reset, 4 spreadsheet tables with sticky header + first column, sort, filter, search, long-press multi-select, copy all / selected / cell (TSV), CSV export, **paste import** with column mapping, per-row validation, duplicate flags and inline fixes |
| Settings | Theme, change master password, JSON backup (optionally with images) |
| Shared | Titled image picker (camera / gallery, reorder, cover), pinch / double-tap / swipe full-screen viewer that loads the original on demand, searchable vehicle & driver selectors, confirm dialogs, undo snackbar on deletes |

Money is shown as ₹ with Indian grouping (₹1,23,456.50), dates as `08 Nov 2026`, times in 12-hour format, all in IST.

## Assumptions & deviations (please read)

1. **No Google sign-in / Drive sync.** Those need OAuth credentials and a native Android shell that are not
   available here. The app is single-owner with no login; data lives in PostgreSQL. The `/api/[resource]`
   layer is the seam where a different store could be plugged in.
2. **Forgot master password** asks the owner to confirm ownership (no Google re-authentication is possible);
   no data is deleted. **Biometric unlock** is not included.
3. **PDF export** uses the browser's “Save as PDF” via the print dialog on a print-styled report; charts are
   SVG so they print crisply.
4. Images are compressed in the browser (1600 px original + 240 px thumbnail) and stored in the database;
   lists only ever load thumbnails and originals are fetched from `/api/images/:id` on demand.
5. Lists filter/sort in the client for speed on typical fleet sizes rather than using server paging.
6. “Odometer entry compliance %” = days in the period that have a trip or a Holiday / Non-working mark ÷ days
   elapsed in the period.
7. Salary balance = monthly salary − fines − (Salary + Advance paid); bonuses are tracked separately.
